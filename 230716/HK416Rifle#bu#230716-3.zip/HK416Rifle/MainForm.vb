﻿Imports System
Imports System.Drawing
Imports System.Xml
Imports System.Windows.Forms
Imports System.Collections.Generic
Imports System.Text
Imports System.Linq
Imports System.Collections.Specialized
Imports System.IO

Public NotInheritable Class MainForm
    Public Sub New()
        ' 디자이너에서 이 호출이 필요합니다.
        InitializeComponent()

        ' InitializeComponent() 호출 뒤에 초기화 코드를 추가하세요.

    End Sub


    ''' <summary>
    ''' 한번만 로드
    ''' </summary>
    ''' <param name="e"></param>
    Protected Overrides Sub OnLoad(e As EventArgs)
        MyBase.OnLoad(e)


        '모니터다 듀얼 이상일때
        Dim tcs As Screen = Screen.FromPoint(Cursor.Position)
        Dim tsb As Rectangle = tcs.WorkingArea
        Dim tlp As Point = New Point(tsb.Right, tsb.Bottom)
        Dim tws As Size = Size
        tlp.Offset(-(tws.Width + 10), -(tws.Height + 10))
        Location = tlp

        Text = [GetType]().Namespace


        prLoadStartData()
        prControlsSetting()
        prOutputText()
    End Sub



    Private m_body As String

    Private m_queryBuffer As New StringBuilder()
    Private m_params As New NameValueCollection()



    ''' <summary>
    ''' XmlData 로드하기
    ''' </summary>
    Private Sub prLoadStartData()
        m_queryBuffer.Clear()
        m_params.Clear()

        Try
            Dim txd As New XmlDocument()
            txd.Load(".\StartData.xml")

            Dim qr As String = txd.SelectSingleNode("Root/DeleteQuery/QueryText").InnerText
            m_body = qr
            m_queryBuffer.AppendLine(qr.Trim())

            Dim xnl1 As XmlNodeList = txd.SelectNodes("Root/DeleteQuery/ParamInfo")
            For Each xn1 As XmlNode In xnl1
                Dim prop As String = xn1.Attributes("Property").InnerText
                Dim val As String = xn1.InnerText
                m_params.Add(prop, val)
            Next
        Catch ex As Exception
            m_txbResult.Text = ex.ToString()
        End Try
    End Sub



    ''' <summary>
    ''' 컨트롤들 설정
    ''' </summary>
    Private Sub prControlsSetting()
        AddHandler m_btn1a.Click, AddressOf pr_btn1a__Click
        AddHandler m_btn1b.Click, AddressOf pr_btn1b__Click
        AddHandler m_btn1c.Click, AddressOf pr_btn1c__Click
        AddHandler m_btnFly.Click, AddressOf pr_btnFly__Click

        m_cbb1.DataSource = m_params.AllKeys
        AddHandler m_cbb1.SelectedIndexChanged, AddressOf pr_cbb1_SelectedIndexChanged
        pr_cbb1_SelectedIndexChanged(Nothing, Nothing)

        AddHandler m_txb1.TextChanged, AddressOf pr_txb1_TextChanged
    End Sub


    ''' <summary>
    ''' 클립보드 넣기
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    Private Sub pr_btn1a__Click(sender As Object, e As EventArgs)
        If Clipboard.ContainsText() Then
            Dim tcs As String = Clipboard.GetText()

            Try
                Dim key As String = m_cbb1.SelectedItem.ToString()
                Dim tv As String = m_params(key)

                If tv.StartsWith("LIKE ", StringComparison.OrdinalIgnoreCase) Then
                    tv = String.Format("LIKE '{0}%'", tcs)
                ElseIf tv.StartsWith("= ", StringComparison.OrdinalIgnoreCase) Then
                    tv = String.Format("= '{0}'", tcs)
                ElseIf tv.StartsWith("IN ", StringComparison.OrdinalIgnoreCase) Then
                    tv = String.Format("IN ({0})", tcs)
                End If

                m_txb1.Text = tv
            Catch
            End Try
        End If
    End Sub


    ''' <summary>
    ''' 적용하기
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    Private Sub pr_btn1b__Click(sender As Object, e As EventArgs)
        prOutputText()
    End Sub


    ''' <summary>
    ''' 저장하기
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    Private Sub pr_btn1c__Click(sender As Object, e As EventArgs)
        Try
            Dim tsrs As String = "
<Root>
  <DeleteQuery>
    <QueryText>
      <![CDATA[
{0}
      ]]>
    </QueryText>    
{1}
  </DeleteQuery>
</Root>
        "
            Dim tsb As New StringBuilder()
            For Each tk As String In m_params
                tsb.AppendLine($"
    <ParamInfo Property=""{tk}"">
      <![CDATA[{m_params(tk)}]]>
    </ParamInfo>")
            Next

            Dim body As String = m_body
            Dim prs As String = tsb.ToString()
            tsrs = String.Format(tsrs.Trim(), body.Trim(), prs)
            File.WriteAllText(".\StartData.xml", tsrs)

            Dim x1 = ""
        Catch
        End Try
    End Sub


    ''' <summary>
    ''' 쿼리 날리기
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    Private Sub pr_btnFly__Click(sender As Object, e As EventArgs)
        m_txbResult.Text = Date.Now.ToString("yyMMddHHmmssfff")
    End Sub


    ''' <summary>
    ''' ???
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    Private Sub pr_txb1_TextChanged(sender As Object, e As EventArgs)
        Dim key As String = m_cbb1.SelectedItem.ToString()
        Dim tv As String = m_txb1.Text
        m_params(key) = tv
        prAutoApply()
    End Sub


    ''' <summary>
    ''' ParamInfo 변경시
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    Private Sub pr_cbb1_SelectedIndexChanged(sender As Object, e As EventArgs)
        Dim key As String = m_cbb1.SelectedItem.ToString()
        Dim tv As String = m_params(key)
        m_txb1.Text = tv
    End Sub



    ''' <summary>
    ''' 텍스트 출력
    ''' </summary>
    Private Sub prOutputText()
        Dim tsa() As String = DirectCast(m_cbb1.DataSource, String())
        Dim l As Integer = tsa.Length
        If l > 0 Then
            Dim tos As String = m_queryBuffer.ToString()
            If (Not String.IsNullOrWhiteSpace(tos)) Then
                Dim tta(0 To l - 1) As String
                Dim i As Integer = 0
                For Each key As String In tsa
                    Dim tv As String = m_params(key)
                    tta(i) = tv
                    i += 1
                Next
                tos = String.Format(tos, tta)
                m_txbOutput.Text = tos
            End If
        End If
    End Sub




    ''' <summary>
    ''' 자동적용
    ''' </summary>
    Private Sub prAutoApply()
        pr_btn1b__Click(Nothing, Nothing)
        m_txb1.Select()
    End Sub


    ''' <summary>
    ''' 상위선택
    ''' </summary>
    Private Sub prSelectUp()
        Dim si As Integer = m_cbb1.SelectedIndex
        Try
            m_cbb1.SelectedIndex = si - 1
        Catch
            m_cbb1.SelectedIndex = si
        End Try
        prAutoApply()
    End Sub


    ''' <summary>
    ''' 하위선택
    ''' </summary>
    Private Sub prSelectDown()
        Dim si As Integer = m_cbb1.SelectedIndex
        Try
            m_cbb1.SelectedIndex = si + 1
        Catch
            m_cbb1.SelectedIndex = si
        End Try
        prAutoApply()
    End Sub


    ''' <summary>
    ''' 전역 단축키
    ''' </summary>
    ''' <param name="msg"></param>
    ''' <param name="keyData"></param>
    ''' <returns></returns>
    Protected Overrides Function ProcessCmdKey(ByRef msg As Message, keyData As Keys) As Boolean
        Select Case keyData
            Case Keys.Up
                prSelectUp()
                Return True

            Case Keys.Down
                prSelectDown()
                Return True

            Case Keys.F3
                pr_btn1a__Click(Nothing, Nothing)
                prAutoApply()
                Return True

            Case Keys.F4, Keys.Enter
                prAutoApply()
                Return True

            Case Keys.F5
                pr_btnFly__Click(Nothing, Nothing)
                Return True

        End Select

        Return MyBase.ProcessCmdKey(msg, keyData)
    End Function



    Protected Overrides Sub OnMouseWheel(e As MouseEventArgs)
        MyBase.OnMouseWheel(e)

        If e.Delta > 0 Then
            prSelectUp()
        Else
            prSelectDown()
        End If
    End Sub


End Class
