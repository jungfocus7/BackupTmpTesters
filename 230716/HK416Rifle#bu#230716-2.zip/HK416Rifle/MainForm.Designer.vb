﻿Imports System.Windows.Forms

<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class MainForm
    Inherits System.Windows.Forms.Form

    'Form은 Dispose를 재정의하여 구성 요소 목록을 정리합니다.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Windows Form 디자이너에 필요합니다.
    Private components As System.ComponentModel.IContainer

    '참고: 다음 프로시저는 Windows Form 디자이너에 필요합니다.
    '수정하려면 Windows Form 디자이너를 사용하십시오.  
    '코드 편집기에서는 수정하지 마세요.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(MainForm))
        Me.m_txbOutput = New System.Windows.Forms.TextBox()
        Me.m_txbResult = New System.Windows.Forms.TextBox()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.m_btn1c = New System.Windows.Forms.Button()
        Me.m_btnFly = New System.Windows.Forms.Button()
        Me.m_cbb1 = New System.Windows.Forms.ComboBox()
        Me.m_btn1a = New System.Windows.Forms.Button()
        Me.m_txb1 = New System.Windows.Forms.TextBox()
        Me.m_btn1b = New System.Windows.Forms.Button()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.GroupBox1.SuspendLayout()
        Me.SuspendLayout()
        '
        'm_txbOutput
        '
        Me.m_txbOutput.Location = New System.Drawing.Point(9, 9)
        Me.m_txbOutput.Margin = New System.Windows.Forms.Padding(0)
        Me.m_txbOutput.Multiline = True
        Me.m_txbOutput.Name = "m_txbOutput"
        Me.m_txbOutput.ReadOnly = True
        Me.m_txbOutput.ScrollBars = System.Windows.Forms.ScrollBars.Both
        Me.m_txbOutput.Size = New System.Drawing.Size(782, 150)
        Me.m_txbOutput.TabIndex = 0
        Me.m_txbOutput.WordWrap = False
        '
        'm_txbResult
        '
        Me.m_txbResult.Location = New System.Drawing.Point(9, 169)
        Me.m_txbResult.Margin = New System.Windows.Forms.Padding(0)
        Me.m_txbResult.Multiline = True
        Me.m_txbResult.Name = "m_txbResult"
        Me.m_txbResult.ReadOnly = True
        Me.m_txbResult.ScrollBars = System.Windows.Forms.ScrollBars.Both
        Me.m_txbResult.Size = New System.Drawing.Size(782, 120)
        Me.m_txbResult.TabIndex = 1
        Me.m_txbResult.WordWrap = False
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.m_btn1c)
        Me.GroupBox1.Controls.Add(Me.m_btnFly)
        Me.GroupBox1.Controls.Add(Me.m_cbb1)
        Me.GroupBox1.Controls.Add(Me.m_btn1a)
        Me.GroupBox1.Controls.Add(Me.m_txb1)
        Me.GroupBox1.Controls.Add(Me.m_btn1b)
        Me.GroupBox1.Location = New System.Drawing.Point(12, 331)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(776, 60)
        Me.GroupBox1.TabIndex = 2
        Me.GroupBox1.TabStop = False
        '
        'm_btn1c
        '
        Me.m_btn1c.Cursor = System.Windows.Forms.Cursors.Hand
        Me.m_btn1c.Location = New System.Drawing.Point(516, 22)
        Me.m_btn1c.Margin = New System.Windows.Forms.Padding(0)
        Me.m_btn1c.Name = "m_btn1c"
        Me.m_btn1c.Size = New System.Drawing.Size(82, 23)
        Me.m_btn1c.TabIndex = 5
        Me.m_btn1c.Text = "저장 (F6)"
        Me.m_btn1c.UseVisualStyleBackColor = True
        '
        'm_btnFly
        '
        Me.m_btnFly.Cursor = System.Windows.Forms.Cursors.Hand
        Me.m_btnFly.Location = New System.Drawing.Point(649, 22)
        Me.m_btnFly.Margin = New System.Windows.Forms.Padding(0)
        Me.m_btnFly.Name = "m_btnFly"
        Me.m_btnFly.Size = New System.Drawing.Size(118, 23)
        Me.m_btnFly.TabIndex = 4
        Me.m_btnFly.Text = "쿼리 날리기 (F5)"
        Me.m_btnFly.UseVisualStyleBackColor = True
        '
        'm_cbb1
        '
        Me.m_cbb1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.m_cbb1.FormattingEnabled = True
        Me.m_cbb1.Location = New System.Drawing.Point(6, 22)
        Me.m_cbb1.Name = "m_cbb1"
        Me.m_cbb1.Size = New System.Drawing.Size(121, 23)
        Me.m_cbb1.TabIndex = 0
        '
        'm_btn1a
        '
        Me.m_btn1a.Cursor = System.Windows.Forms.Cursors.Hand
        Me.m_btn1a.Location = New System.Drawing.Point(286, 22)
        Me.m_btn1a.Margin = New System.Windows.Forms.Padding(0)
        Me.m_btn1a.Name = "m_btn1a"
        Me.m_btn1a.Size = New System.Drawing.Size(130, 23)
        Me.m_btn1a.TabIndex = 2
        Me.m_btn1a.Text = "클립보드 넣기 (F3)"
        Me.m_btn1a.UseVisualStyleBackColor = True
        '
        'm_txb1
        '
        Me.m_txb1.Location = New System.Drawing.Point(133, 22)
        Me.m_txb1.Name = "m_txb1"
        Me.m_txb1.Size = New System.Drawing.Size(150, 23)
        Me.m_txb1.TabIndex = 1
        '
        'm_btn1b
        '
        Me.m_btn1b.Cursor = System.Windows.Forms.Cursors.Hand
        Me.m_btn1b.Location = New System.Drawing.Point(416, 22)
        Me.m_btn1b.Margin = New System.Windows.Forms.Padding(0)
        Me.m_btn1b.Name = "m_btn1b"
        Me.m_btn1b.Size = New System.Drawing.Size(100, 23)
        Me.m_btn1b.TabIndex = 3
        Me.m_btn1b.Text = "적용하기 (F4)"
        Me.m_btn1b.UseVisualStyleBackColor = True
        '
        'Label1
        '
        Me.Label1.Location = New System.Drawing.Point(15, 309)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(513, 23)
        Me.Label1.TabIndex = 4
        Me.Label1.Text = "##  (PAGEUP: 상위선택), (PAGEDOWN: 하위선택), (ENTER: 적용)" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10)
        '
        'MainForm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 15.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(800, 400)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.m_txbResult)
        Me.Controls.Add(Me.m_txbOutput)
        Me.Font = New System.Drawing.Font("맑은 고딕", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Location = New System.Drawing.Point(100, 40)
        Me.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.MaximizeBox = False
        Me.Name = "MainForm"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.Manual
        Me.Text = "Form1"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents m_txbOutput As TextBox
    Friend WithEvents m_txbResult As TextBox
    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents m_btn1a As Button
    Friend WithEvents m_txb1 As TextBox
    Friend WithEvents m_btn1b As Button
    Friend WithEvents m_cbb1 As ComboBox
    Friend WithEvents Label1 As Label
    Friend WithEvents m_btnFly As Button
    Friend WithEvents m_btn1c As Button
End Class
