﻿Imports System
Imports System.Configuration
Imports System.Diagnostics
Imports System.Drawing
Imports System.IO
Imports System.Windows.Forms
Imports Microsoft.Web.WebView2.Core
Imports Microsoft.Web.WebView2.WinForms




Public NotInheritable Class MainForm
#Region "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ 1"
    ''' <summary>
    ''' 생성자
    ''' </summary>
    Public Sub New()
        ' 디자이너에서 이 호출이 필요합니다.
        InitializeComponent()

        ' InitializeComponent() 호출 뒤에 초기화 코드를 추가하세요.

    End Sub



    ''' <summary>
    ''' Load 이벤트
    ''' </summary>
    ''' <param name="ea"></param>
    Protected Overrides Sub OnLoad(ea As EventArgs)
        MyBase.OnLoad(ea)

        Text = [GetType]().Namespace
        'MinimumSize = Size
        AllowDrop = True


        '모니터다 듀얼 이상일때
        Dim tcs As Screen = Screen.FromPoint(Cursor.Position)
        Dim tsb As Rectangle = tcs.WorkingArea
        Dim tlp As Point = New Point(tsb.Right, tsb.Bottom)
        Dim tws As Size = Size
        tlp.Offset(-(tws.Width + 10), -(tws.Height + 10))
        Location = tlp


        m_clas = Environment.GetCommandLineArgs()
        m_cdp = Path.GetDirectoryName(m_clas(0))


        m_wv2 = WebView21
        m_wv2.AllowExternalDrop = False
        prWebView2EnsureCoreWebView2Async()
        AddHandler m_wv2.CoreWebView2InitializationCompleted, AddressOf prCoreWebView2InitializationCompleted


        prFooterGroupSettings()
    End Sub


    ''' <summary>
    ''' OnResizeBegin
    ''' </summary>
    ''' <param name="e"></param>
    Protected Overrides Sub OnResizeBegin(e As EventArgs)
        MyBase.OnResizeBegin(e)
        SuspendLayout()
    End Sub


    ''' <summary>
    ''' OnResizeEnd
    ''' </summary>
    ''' <param name="e"></param>
    Protected Overrides Sub OnResizeEnd(e As EventArgs)
        MyBase.OnResizeEnd(e)
        ResumeLayout(True)
    End Sub



    ''' <summary>
    ''' Environment.GetCommandLineArgs
    ''' </summary>
    Private m_clas() As String

    ''' <summary>
    ''' CurrentDirectoryPath
    ''' </summary>
    Private m_cdp As String

    ''' <summary>
    ''' WebView2
    ''' </summary>
    Private m_wv2 As WebView2

    ''' <summary>
    ''' CoreWebView2
    ''' </summary>
    Private m_cwv2 As CoreWebView2



    ''' <summary>
    ''' EnvironmentOptions 설정
    ''' </summary>
    Private Async Sub prWebView2EnsureCoreWebView2Async()
        Dim cweo As New CoreWebView2EnvironmentOptions("--disable-web-security")
        Dim env As CoreWebView2Environment = Await CoreWebView2Environment.CreateAsync(Nothing, Nothing, cweo)
        Await m_wv2.EnsureCoreWebView2Async(env)
    End Sub


    ''' <summary>
    ''' Completed 이벤트
    ''' </summary>
    ''' <param name="sd"></param>
    ''' <param name="ea"></param>
    Private Sub prCoreWebView2InitializationCompleted(sd As Object, ea As CoreWebView2InitializationCompletedEventArgs)
        If ea.IsSuccess Then
            m_cwv2 = m_wv2.CoreWebView2
            m_cwv2.Settings.IsZoomControlEnabled = False
            'm_cwv2.Settings.IsPinchZoomEnabled = False
            AddHandler m_cwv2.ContextMenuRequested, AddressOf prContextMenuRequested
            AddHandler m_cwv2.ProcessFailed, Sub(tx As Object, ty As EventArgs)
                                                 Close()
                                             End Sub
            'm_cwv2.Navigate("https://www.youtube.com/watch?v=u1OG20oYUGA")
            'm_cwv2.Navigate("https://js.devexpress.com/Demos/WidgetsGallery/")
            'm_cwv2.Navigate("https://editor.method.ac/")
            'm_cwv2.Navigate("https://www.youtube.com/watch?v=wmvFTrCFmJ4")
            'm_cwv2.Navigate("https://vscode.dev/")

            Dim epp As String
            If (m_clas.Length = 1) Then
                epp = ConfigurationManager.AppSettings("EntryPoint")
            Else
                epp = m_clas(1)
            End If
            Dim hfp As String = Path.Combine(m_cdp, epp)
            hfp = Path.GetFullPath(hfp)
            prLoadCore(hfp)

            'If ThRuntime.IsDebugMode Then
            '    m_cwv2.OpenDevToolsWindow()
            '    'm_cwb2.OpenTaskManagerWindow()
            'End If

            AddHandler m_wv2.WebMessageReceived, AddressOf prWebMessageReceived
        End If
    End Sub


    ''' <summary>
    ''' 
    ''' </summary>
    ''' <param name="sd"></param>
    ''' <param name="ea"></param>
    Private Sub prContextMenuRequested(sd As Object, ea As CoreWebView2ContextMenuRequestedEventArgs)
        ea.Handled = True
    End Sub


    ''' <summary>
    ''' 
    ''' </summary>
    ''' <param name="sd"></param>
    ''' <param name="ea"></param>
    Private Sub prWebMessageReceived(sd As Object, ea As CoreWebView2WebMessageReceivedEventArgs)
        Dim msg As String = ea.TryGetWebMessageAsString()
        'MsgBox(msg)

        Dim mda() As String = msg.Split(";"c)

        Select Case mda(0)
            Case "LoadSubContent"
                prLoadSubContent(mda(1))

        End Select

        '_cwb2.ExecuteScriptAsync("alert('xxxx');")
    End Sub


    ''' <summary>
    ''' 
    ''' </summary>
    ''' <param name="fnm"></param>
    Private Sub prLoadSubContent(fnm As String)
        Dim fp As String = Path.Combine(m_cdp & "\HtmlRoot", fnm)
        If File.Exists(fp) Then
            Dim ta As String = File.ReadAllText(fp)
            'MsgBox(tta)
            Dim cfs As String = $"__fn_loadSub(`" & ta & "`);"
            'MsgBox(tcfs)
            m_cwv2.ExecuteScriptAsync(cfs)
            '_cwb2.ExecuteScriptAsync("alert('xxxxxxxx');")
        End If
    End Sub

#End Region



    Private _cms71 As ContextMenuStrip


    Private Sub pr_cms71__call(sender As Object, e As EventArgs)
        Try
            Dim hfp As String = m_txb71.Text
            Dim dp As String = Path.GetDirectoryName(hfp)
            Process.Start(dp)

            'Dim hfp As String = m_txb71.Text
            ''Process.Start(hfp)
            'Dim args As String = $"/e, /select, {hfp}"
            'Process.Start("explorer", args)
        Catch
        End Try
    End Sub


    Private Sub pr_cms72__call(sender As Object, e As EventArgs)
        Try
            Dim dp As String = Path.Combine(m_cdp, "..\HtmlRoot")
            dp = Path.GetFullPath(dp)
            If Directory.Exists(dp) Then
                Dim psi As New ProcessStartInfo() With {
                    .FileName = "code",
                    .WorkingDirectory = dp,
                    .Arguments = $"""{dp}""",
                    .UseShellExecute = True,
                    .CreateNoWindow = False,
                    .WindowStyle = ProcessWindowStyle.Hidden
                }
                Process.Start(psi)


                'Dim psi As New ProcessStartInfo() With {
                '    .FileName = "code",
                '    .WorkingDirectory = dp,
                '    .Arguments = $"""{dp}""",
                '    .UseShellExecute = True,
                '    .CreateNoWindow = False,
                '    .WindowStyle = ProcessWindowStyle.Hidden
                '}
                'Process.Start(psi)

                'Dim cdp As String = $"""{dp}"""
                'Debug.WriteLine(cdp)
                'Process.Start("code", cdp)
            Else
                Throw New Exception()
            End If
        Catch
            MsgBox("실패")
        End Try
    End Sub


    Private Sub pr_cms73__call(sender As Object, e As EventArgs)
        Try
            m_cwv2.Reload()
        Catch
        End Try
    End Sub


    Private Sub pr_cms74__call(sender As Object, e As EventArgs)
        Try
            m_cwv2.OpenDevToolsWindow()
        Catch
        End Try
    End Sub


    Private Sub pr_cms75__call(sender As Object, e As EventArgs)
        Try
            m_cwv2.OpenTaskManagerWindow()
        Catch
        End Try
    End Sub


    Private Sub pr_cms76__call(sender As Object, e As EventArgs)
        Try
            'Dim tbmp As New Bitmap(_rctrt.Width, _rctrt.Height, PixelFormat.Format32bppArgb)
            'Using tg As Graphics = Graphics.FromImage(tbmp)
            '    tg.CopyFromScreen(_rctrt.Left, _rctrt.Top, 0, 0, _rctrt.Size)
            'End Using
        Catch
        End Try
    End Sub



    Private Sub pr_btn71__Click(sender As Object, e As EventArgs)
        Dim gpt As Point = MousePosition
        Dim rct As Rectangle = _cms71.DisplayRectangle
        Dim pt As New Point(gpt.X - rct.Width, gpt.Y - (rct.Height + 10))
        _cms71.Show(pt, ToolStripDropDownDirection.Default)
    End Sub


    ''' <summary>
    ''' 아래그룹세팅스
    ''' </summary>
    Private Sub prFooterGroupSettings()
        _cms71 = New ContextMenuStrip()
        Dim tsia() As ToolStripItem = {
            New ToolStripMenuItem("1) 폴더위치 열기", Nothing, AddressOf pr_cms71__call),
            New ToolStripMenuItem("2) VSCode 열기", Nothing, AddressOf pr_cms72__call),
            New ToolStripSeparator(),
            New ToolStripMenuItem("3) 새로 고침", Nothing, AddressOf pr_cms73__call),
            New ToolStripMenuItem("4) 개발자도구 열기", Nothing, AddressOf pr_cms74__call),
            New ToolStripMenuItem("5) 작업관리자 열기", Nothing, AddressOf pr_cms75__call),
            New ToolStripSeparator(),
            New ToolStripMenuItem("6) 이미지 캡처", Nothing, AddressOf pr_cms76__call)
        }
        _cms71.Cursor = Cursors.Hand
        _cms71.Items.AddRange(tsia)
        'm_btn71.ContextMenuStrip = _cms71

        AddHandler m_btn71.Click, AddressOf pr_btn71__Click
    End Sub


    ''' <summary>
    ''' 
    ''' </summary>
    Private Sub prLoadCore(hfp As String)
        If File.Exists(hfp) Then
            If Path.GetExtension(hfp).ToLower() = ".html" Then
                'm_wv2.Source = New Uri(hfp)
                m_cwv2.Navigate(hfp)
                m_txb71.Text = hfp
            End If
        End If
    End Sub


    ''' <summary>
    ''' 
    ''' </summary>
    ''' <param name="ea"></param>
    Protected Overrides Sub OnDragEnter(ea As DragEventArgs)
        MyBase.OnDragEnter(ea)

        ea.Effect = DragDropEffects.All
    End Sub


    ''' <summary>
    ''' 
    ''' </summary>
    ''' <param name="ea"></param>
    Protected Overrides Sub OnDragDrop(ea As DragEventArgs)
        MyBase.OnDragDrop(ea)

        Dim tdo As IDataObject = ea.Data
        Dim fpa As String() = TryCast(tdo.GetData(DataFormats.FileDrop), String())
        If fpa.Length = 1 Then
            Dim fp As String = fpa(0)
            prLoadCore(fp)
        End If
    End Sub

End Class






