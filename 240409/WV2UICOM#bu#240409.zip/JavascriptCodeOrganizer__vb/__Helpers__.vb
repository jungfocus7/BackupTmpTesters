﻿Imports System
Imports System.IO
Imports System.Runtime.CompilerServices




Public NotInheritable Class FileSystemHelper
    Private Sub New()
    End Sub

    'Public Shared Function GetOutputFilePath(ifp As String) As String
    '    If String.IsNullOrWhiteSpace(ifp) OrElse Not File.Exists(ifp) Then
    '        Return String.Empty
    '    Else
    '        Dim cdp As String = Path.GetDirectoryName(ifp)
    '        Dim ffnm As String = Path.GetFileNameWithoutExtension(ifp)
    '        Dim ofp As String = Path.Combine(cdp, ffnm & "-mx.js")
    '        Return ofp
    '    End If
    'End Function

    Public Shared Function GetInputFilePath(bdp As String, ifp As String) As String
        'Console.WriteLine("bdp >>> " & bdp)
        'Console.WriteLine("ifp >>> " & ifp)
        Dim rp As String = Path.Combine(bdp, ifp)
        rp = Path.GetFullPath(rp)
        'Console.WriteLine("rp >>> " & rp)
        If File.Exists(rp) Then
            Return rp
        Else
            Return String.Empty
        End If
    End Function

    Public Shared Function GetOutputFilePath(bdp As String, odp As String, ifp As String) As String
        'Console.WriteLine("bdp >>> " & bdp)
        'Console.WriteLine("odp >>> " & odp)
        'Console.WriteLine("ifp >>> " & ifp)
        Dim rp As String = Path.Combine(bdp, odp,
            Path.GetFileNameWithoutExtension(ifp) & "-min.js")
        rp = Path.GetFullPath(rp)
        Console.WriteLine("rp >>> " & rp)
        Return rp
    End Function

End Class



Public Module ClearObject
    <Extension()>
    Public Sub Clear(obj As IDisposable)
        If Not obj Is Nothing Then
            obj.Dispose()
        End If
    End Sub
End Module
