import { hfEventTypes } from "../base/hfEventTypes.js";
import { fn_applyRectToElement } from "../base/hfStyleFunctions.js";



const hfViewBox = Object.freeze(class {
    //////////////////////////////////////////////////////////////////////
    /**
     * 생성자
     * @param {DOMRect} rctViewport Viewport영역
     * @param {DOMRect} rctBody Body영역
     * @param {function} cbf 콜백함수
     */
    constructor(rctViewport, rctBody, cbf=null) {
        this.#rctViewport = rctViewport;
        this.#rctBody = rctBody;
        this.#rctBody.x = this.#rctViewport.left;
        this.#rctBody.y = this.#rctViewport.top;
        // console.log(this.#rctViewport, this.#rctBody);
        this.#cbf = cbf;

        this.#fn_updateScrollSizeWidth();
        this.#fn_updateScrollSizeHeight();
        this.#fn_updateScrollPositionRatioX();
        this.#fn_updateScrollPositionX();
        this.#fn_updateScrollPositionRatioY();
        this.#fn_updateScrollPositionY();
    }

    /** @type {DOMRect} Viewport영역 */
    #rctViewport = null;

    /** @type {DOMRect} Body영역 */
    #rctBody = null;

    /** @type {function} */
    #cbf = null;
    /**
     * 콜백함수 호출
     * @param {string} cbt
     * @returns {void}
     */
    #fn_callback(cbt) {
        if (this.#cbf === null) return;
        this.#cbf(cbt);
    }


    //////////////////////////////////////////////////////////////////////
    /** @type {number} */
    #scrollSizeWidth = NaN;
    /** @type {number} */
    #scrollSizeRatioX = NaN;

    /**
     * 스크롤사이즈 넓이 업데이트
     * @returns {void}
     */
    #fn_updateScrollSizeWidth() {
        let scv = this.#rctBody.width - this.#rctViewport.width;
        if (scv === this.#scrollSizeWidth) return;
        if (scv > 0.0) {
            this.#scrollSizeWidth = scv;
            let sr = this.#scrollSizeWidth / this.#rctBody.width;
            if (isFinite(sr) === false) {
                sr = 0.0;
                this.#scrollSizeRatioX = sr;
            }
            else {
                if (sr < 0.0) sr = 0.0;
                else if (sr > 1.0) sr = 1.0;
                this.#scrollSizeRatioX = sr;
            }
        }
        else {
            this.#scrollSizeWidth = 0.0;
            this.#scrollSizeRatioX = 0.0;
        }
    }

    /**
     * 스크롤사이즈 넓이 가져오기
     * @param {boolean} bu
     * @returns {number}
     */
    fn_getScrollSizeWidth(bu=false) {
        if (bu === true) this.#fn_updateScrollSizeWidth();
        return this.#scrollSizeWidth;
    }

    /**
     * 스크롤사이즈 X축비율 가져오기
     * @param {boolean} bu
     * @returns {number}
     */
    fn_getScrollSizeRatioX(bu=false) {
        if (bu === true) this.#fn_updateScrollSizeWidth();
        return this.#scrollSizeRatioX;
    }


    //////////////////////////////////////////////////////////////////////
    /** @type {number} */
    #scrollSizeHeight = NaN;
    /** @type {number} */
    #scrollSizeRatioY = NaN;

    /**
     * 스크롤사이즈 높이 업데이트
     * @returns {void}
     */
    #fn_updateScrollSizeHeight() {
        let scv = this.#rctBody.height - this.#rctViewport.height;
        if (scv === this.#scrollSizeHeight) return;
        if (scv > 0.0) {
            this.#scrollSizeHeight = scv;
            let sr = this.#scrollSizeHeight / this.#rctBody.height;
            if (isFinite(sr) === false) {
                sr = 0.0;
                this.#scrollSizeRatioY = sr;
            }
            else {
                if (sr < 0.0) sr = 0.0;
                else if (sr > 1.0) sr = 1.0;
                this.#scrollSizeRatioY = sr;
            }
        }
        else {
            this.#scrollSizeHeight = 0.0;
            this.#scrollSizeRatioY = 0.0;
        }
    }

    /**
     * 스크롤사이즈 높이 가져오기
     * @param {boolean} bu
     * @returns {number}
     */
    fn_getScrollSizeHeight(bu=false) {
        if (bu === true) this.#fn_updateScrollSizeHeight();
        return this.#scrollSizeHeight;
    }

    /**
     * 스크롤사이즈 Y축비율 가져오기
     * @param {boolean} bu
     * @returns {number}
     */
    fn_getScrollSizeRatioY(bu=false) {
        if (bu === true) this.#fn_updateScrollSizeHeight();
        return this.#scrollSizeRatioY;
    }


    //////////////////////////////////////////////////////////////////////
    /** @type {number} */
    #scrollPositionRatioX = NaN;

    /**
     * 스크롤포지션 X축비율 업데이트
     * @returns {void}
     */
    #fn_updateScrollPositionRatioX() {
        const scv = this.fn_getScrollSizeWidth(true);
        let sp = this.#rctViewport.left - this.#rctBody.left;
        if (sp < 0.0) sp = 0.0;
        let sr = sp / scv;
        if (isFinite(sr) === true) {
            if (sr < 0.0) sr = 0.0;
            else if (sr > 1.0) sr = 1.0;
            this.#scrollPositionRatioX = sr;
        }
        else {
            sr = 0.0;
            this.#scrollPositionRatioX = sr;
        }
    }

    /**
     * 스크롤포지션 X축비율 가져오기
     * @param {boolean} bu
     * @returns {number}
     */
    fn_getScrollPositionRatioX(bu=false) {
        if (bu === true) this.#fn_updateScrollPositionRatioX();
        return this.#scrollPositionRatioX;
    }

    /**
     * 스크롤포지션 X축비율 설정하기
     * @param {number} val
     * @returns {void}
     */
    fn_setScrollPositionRatioX(val) {
        let sr = val;
        if (sr !== this.#scrollPositionRatioX) {
            if (sr < 0.0) sr = 0.0;
            else if (sr > 1.0) sr = 1.0;
            this.#scrollPositionRatioX = sr;
            this.#fn_updateScrollPositionX(false);
            this.#fn_calcRctBodyX();
        }
    }


    //////////////////////////////////////////////////////////////////////
    /** @type {number} */
    #scrollPositionX = NaN;

    /**
     * 스크롤포지션 X축 업데이트
     * @param {boolean} br
     * @returns {void}
     */
    #fn_updateScrollPositionX(br=true) {
        if (br === true) {
            let sp = this.#rctViewport.left - this.#rctBody.left;
            if (sp < 0.0) sp = 0.0;
            this.#scrollPositionX = sp;
        }
        else {
            const scv = this.fn_getScrollSizeWidth();
            const sr = this.fn_getScrollPositionRatioX();
            let sp = scv * sr;
            this.#scrollPositionX = sp;
        }
    }

    /**
     * 스크롤포지션 X축 가져오기
     * @param {boolean} bu
     * @returns {number}
     */
    #fn_getScrollPositionX(bu=false) {
        if (bu === true) this.#fn_updateScrollPositionX();
        return this.#scrollPositionX;
    }

    /**
     * 보디렉트 X축 계산하기
     * @returns {void}
     */
    #fn_calcRctBodyX() {
        const scv = this.fn_getScrollSizeWidth();
        const gjv = this.#rctViewport.left;
        if (scv > 0.0) {
            const bv = gjv - scv;
            const ev = gjv;
            let rp = gjv - this.#scrollPositionX;
            if (rp < bv) rp = bv;
            else if (rp > ev) rp = ev;
            this.#rctBody.x = rp;
        }
        else {
            let rp = (this.#rctViewport.right - (this.#rctViewport.width / 2)) -
                (this.#rctBody.width / 2);
            this.#rctBody.x = rp;
        }
    }

    /**
     * 스크롤포지션 X축 설정하기
     * @param {number} val
     * @returns {void}
     */
    #fn_setScrollPositionX(val) {
        const bv = 0.0;
        const ev = this.fn_getScrollSizeWidth();
        if (bv === ev) return;
        let sp = val;
        if (sp !== this.#scrollPositionX) {
            if (sp < bv) sp = bv;
            else if (sp > ev) sp = ev;
            this.#scrollPositionX = sp;
            this.#fn_calcRctBodyX();
            this.#fn_updateScrollPositionRatioX();
        }
    }


    //////////////////////////////////////////////////////////////////////
    /** @type {number} */
    #scrollPositionRatioY = NaN;

    /**
     * 스크롤포지션 Y축비율 업데이트
     * @returns {void}
     **/
    #fn_updateScrollPositionRatioY() {
        const scv = this.fn_getScrollSizeHeight(true);
        let sp = this.#rctViewport.top - this.#rctBody.top;
        if (sp < 0.0) sp = 0.0;
        let sr = sp / scv;
        if (isFinite(sr) === true) {
            if (sr < 0.0) sr = 0.0;
            else if (sr > 1.0) sr = 1.0;
            this.#scrollPositionRatioY = sr;
        }
        else {
            sr = 0.0;
            this.#scrollPositionRatioY = sr;
        }
    }

    /**
     * 스크롤포지션 Y축비율 가져오기
     * @param {boolean} bu
     * @returns {number}
     */
    fn_getScrollPositionRatioY(bu=false) {
        if (bu === true) this.#fn_updateScrollPositionRatioY();
        return this.#scrollPositionRatioY;
    }

    /**
     * 스크롤포지션 Y축비율 설정하기
     * @param {number} val
     * @returns {void}
     */
    fn_setScrollPositionRatioY(val) {
        let sr = val;
        if (sr !== this.#scrollPositionRatioY) {
            if (sr < 0.0) sr = 0.0;
            else if (sr > 1.0) sr = 1.0;
            this.#scrollPositionRatioY = sr;
            this.#fn_updateScrollPositionY(false);
            this.#fn_calcRctBodyY();
        }
    }


    //////////////////////////////////////////////////////////////////////
    /** @type {number} */
    #scrollPositionY = NaN;

    /**
     * 스크롤포지션 Y축 업데이트
     * @param {boolean} br
     * @returns {void}
     */
    #fn_updateScrollPositionY(br=true) {
        if (br === true) {
            let sp = this.#rctViewport.top - this.#rctBody.top;
            if (sp < 0.0) sp = 0.0;
            this.#scrollPositionY = sp;
        }
        else {
            const scv = this.fn_getScrollSizeHeight();
            const sr = this.fn_getScrollPositionRatioY();
            let sp = scv * sr;
            this.#scrollPositionY = sp;
        }
    }

    /**
     * 스크롤포지션 Y축 가져오기
     * @param {boolean} bu
     * @returns {number}
     */
    #fn_getScrollPositionY(bu=false) {
        if (bu === true) this.#fn_updateScrollPositionY();
        return this.#scrollPositionY;
    }

    /**
     * 보디렉트 Y축 계산하기
     * @returns {void}
     */
    #fn_calcRctBodyY() {
        const scv = this.fn_getScrollSizeHeight();
        const gjv = this.#rctViewport.top;
        if (scv > 0.0) {
            const bv = gjv - scv;
            const ev = gjv;
            let rp = gjv - this.#scrollPositionY;
            if (rp < bv) rp = bv;
            else if (rp > ev) rp = ev;
            this.#rctBody.y = rp;
        }
        else {
            let rp = (this.#rctViewport.bottom - (this.#rctViewport.height / 2)) -
                (this.#rctBody.height / 2);
            this.#rctBody.y = rp;
        }
    }

    /**
     * 스크롤포지션 Y축 설정하기
     * @param {number} val
     * @returns {void}
     */
    #fn_setScrollPositionY(val) {
        const bv = 0.0;
        const ev = this.fn_getScrollSizeHeight();
        if (bv === ev) return;
        let sp = val;
        if (sp !== this.#scrollPositionY) {
            if (sp < bv) sp = bv;
            else if (sp > ev) sp = ev;
            this.#scrollPositionY = sp;
            this.#fn_calcRctBodyY();
            this.#fn_updateScrollPositionRatioY();
        }
    }


    //////////////////////////////////////////////////////////////////////
    /** @type {string} */
    static RN_VIEW_BOX = 'rctViewBox';
    /** @type {string} */
    static RN_BODY = 'rctBody';

    /**
     * 렉트를 엘리먼트에 적용하기
     * @param {HTMLElement} el
     * @param {string} rn
     * @returns {void}
     */
    fn_applyRectToElement(el, rn) {
        let rct = null;
        if (rn === hfViewBox.RN_VIEW_BOX) {
            rct = this.#rctViewport;
        }
        else if (rn === hfViewBox.RN_BODY) {
            rct = this.#rctBody;
        }
        // console.log(rn, rct);

        if ((rct !== null) && (el !== null)) {
            fn_applyRectToElement(el, rct);
        }
    }


    //////////////////////////////////////////////////////////////////////
    /** @type {number} */
    static #MIN_W = 10.0;

    /**
     * 뷰영역 넓이 가져오기
     * @returns {number}
     */
    fn_getViewWidth() {
        return this.#rctViewport.width;
    }

    /**
     * 뷰영역 넓이 설정하기
     * @param {number} val
     * @returns {void}
     */
    fn_setViewWidth(val) {
        if (val === this.#rctViewport.width) return;
        if (val < hfViewBox.#MIN_W) val = hfViewBox.#MIN_W;
        this.#rctViewport.width = val;
        this.#fn_updateScrollSizeWidth();
        this.#fn_updateScrollPositionX(false);
        this.#fn_calcRctBodyX();
    }

    /**
     * 보디영역 넓이 가져오기
     * @returns {number}
     */
    fn_getBodyWidth() {
        return this.#rctBody.width;
    }

    /**
     * 보디영역 넓이 설정하기
     * @param {number} val
     * @returns {void}
     */
    fn_setBodyWidth(val) {
        if (val === this.#rctBody.width) return;
        if (val < hfViewBox.#MIN_W) val = hfViewBox.#MIN_W;
        this.#rctBody.width = val;
        this.#fn_updateScrollSizeWidth();
        this.#fn_updateScrollPositionX(false);
        this.#fn_calcRctBodyX();
    }


    //////////////////////////////////////////////////////////////////////
    static #MIN_H = 10.0;

    /**
     * 뷰영역 높이 가져오기
     * @returns {number}
     */
    fn_getViewHeight() {
        return this.#rctViewport.height;
    }

    /**
     * 뷰영역 높이 설정하기
     * @param {number} val
     * @returns {void}
     */
    fn_setViewHeight(val) {
        if (val === this.#rctViewport.height) return;
        if (val < hfViewBox.#MIN_H) val = hfViewBox.#MIN_H;
        this.#rctViewport.height = val;
        this.#fn_updateScrollSizeHeight();
        this.#fn_updateScrollPositionY(false);
        this.#fn_calcRctBodyY();
    }

    /**
     * 보디영역 높이 가져오기
     * @returns {number}
     */
    fn_getBodyHeight() {
        return this.#rctBody.height;
    }

    /**
     * 보디영역 높이 설정하기
     * @param {number} val
     * @returns {void}
     */
    fn_setBodyHeight(val) {
        if (val === this.#rctBody.height) return;
        if (val < hfViewBox.#MIN_H) val = hfViewBox.#MIN_H;
        this.#rctBody.height = val;
        this.#fn_updateScrollSizeHeight();
        this.#fn_updateScrollPositionY(false);
        this.#fn_calcRctBodyY();
    }



    // //////////////////////////////////////////////////////////////////////
    /** @type {HTMLElement} */
    #elViewBox = null;
    /** @type {HTMLElement} */
    #elBody = null;

    /** @type {boolean} */
    #bmd = false;
    /** @type {DOMPoint} */
    #mdp = new DOMPoint(0, 0);


    /**
     * ??
     * @param {MouseEvent} e
     * @returns {void}
     */
    #fn_mouseMove = (e) => {
        if (this.#bmd === false) return;

        const cx = (this.#mdp.x - e.clientX) + this.#rctViewport.left;
        const cy = (this.#mdp.y - e.clientY) + this.#rctViewport.top;
        this.#fn_setScrollPositionX(cx);
        this.#fn_setScrollPositionY(cy);
        this.fn_applyRectToElement(this.#elBody, hfViewBox.RN_BODY);
        // console.log('체낄아웃');

        this.#fn_callback(hfEventTypes.Scroll);
    }

    /**
     * ??
     * @param {MouseEvent} e
     * @returns {void}
     */
    #fn_mouseUp = (e) => {
        if (this.#bmd === false) return;

        window.removeEventListener(hfEventTypes.MouseMove, this.#fn_mouseMove);
        window.removeEventListener(hfEventTypes.Blur, this.#fn_mouseUp);
        window.removeEventListener(hfEventTypes.MouseUp, this.#fn_mouseUp);
        this.#bmd = false;
    };

    /**
     * ??
     * @param {MouseEvent} e
     * @returns {void}
     */
    #fn_mouseDown = (e) => {
        if (this.#bmd === true) return;

        window.addEventListener(hfEventTypes.MouseMove, this.#fn_mouseMove);
        window.addEventListener(hfEventTypes.Blur, this.#fn_mouseUp);
        window.addEventListener(hfEventTypes.MouseUp, this.#fn_mouseUp);
        this.#bmd = true;

        this.#mdp.x = e.clientX - this.#rctBody.left;
        this.#mdp.y = e.clientY - this.#rctBody.top;

        this.#fn_mouseMove(e);
    };


    /**
     *
     * @param {MouseEvent} e
     * @returns
     */
    #fn_stageMouseWheel = (e) => {
        if (e === null) return;

        let bdw = this.fn_getBodyWidth();
        let bdh = this.fn_getBodyHeight();
        let dw, dh;
        let dg = (e.ctrlKey === true) ? 0.1 : 0.01;
        if (e.deltaY < 0) {
            dw = this.fn_getBodyWidth() * dg;
            dh = this.fn_getBodyHeight() * dg;
            bdw = bdw + dw;
            bdh = bdh + dh;
        }
        else {
            dw = this.fn_getBodyWidth() * dg;
            dh = this.fn_getBodyHeight() * dg;
            bdw = bdw - dw;
            bdh = bdh - dh;
        }
        // console.log(bdw, bdh);

        this.fn_setBodyWidth(bdw);
        this.fn_setBodyHeight(bdh);
        //this.fn_applyRectToElement(hfViewBox.RN_VIEW_BOX);
        this.fn_applyRectToElement(this.#elBody, hfViewBox.RN_BODY);

        this.#fn_callback('normal');
    }


    /**
     * @returns {void}
     */
    fn_applyDragMove(elViewBox, elBody) {
        this.#elViewBox = elViewBox;
        this.#elBody = elBody;

        this.#elViewBox.addEventListener(hfEventTypes.MouseDown, this.#fn_mouseDown);
        this.#elViewBox.addEventListener(hfEventTypes.MouseWheel, this.#fn_stageMouseWheel
            , {passive: false});
        // this.#fn_stageMouseWheel(null);
    }


    /**
     * ??
     * @returns {DOMRectReadOnly}
     */
    fn_getViewRect() {
        let tw = Math.min(this.#rctViewport.width, this.#rctBody.width);
        let th = Math.min(this.#rctViewport.height, this.#rctBody.height);
        let tx = this.#rctViewport.left - this.#rctBody.left;
        let ty = this.#rctViewport.top - this.#rctBody.top;
        let rct = new DOMRectReadOnly(tx, ty, tw, th);
        // console.log('xxxx');
        return rct;
    }

});


export { hfViewBox };
