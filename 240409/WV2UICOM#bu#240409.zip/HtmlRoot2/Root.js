import { hfEventTypes } from "./hfjs/base/hfEventTypes.js";
import { fn_getRect, fn_getWidth, fn_getHeight } from "./hfjs/base/hfStyleFunctions.js";
import { hfViewBox } from "./hfjs/controls/hfViewBox.js";
import { hfHScroll } from "./hfjs/controls/hfHScroll.js";
import { hfVScroll } from "./hfjs/controls/hfVScroll.js";



const _elViewBox = document.getElementById('viewBox');
const _elBody = document.getElementById('body');
// console.log(_elViewBox, _elBody);




const _lotInfo = document.querySelector('div.lot-info>span');
_lotInfo.innerText = '';


const _rowCont = document.querySelector('div.lot-info>.row-cont');
// console.log(_rowCont);
_rowCont.innerHTML = '';


const _allRows = [];

const fn_rowCellsUpdate = (bResize=false) => {
    try {
        const rct = _viewBox.fn_getViewRect();
        _lotInfo.innerText =
            `w: ${rct.width}, h: ${rct.height}, x: ${rct.left}, y: ${rct.top}`;


        if (bResize === true) {
            // console.log(rct.height / 50, Math.ceil(rct.height / 50));
            const arc = Math.ceil(rct.height / 30) + 6;
            if (arc > _allRows.length) {
                console.log(arc);
                _allRows.length = arc;
            }
            // _rowCont.innerHTML = `<div style="absolute: static; display: block; width: 300px; height: 30px;
            //         background-color: cadetblue; left: 0px; top: 0px;"></div>`;
        }
    }
    catch { }


    // const lst = [];
    // for (let i = 0; i < 999; ++i) {
    //     lst.push(`<div style="position: static; display: block; width: 300px; height: 50px;
    //         background-color: cadetblue;"></div>`);
    // }
    // _rowCont.innerHTML = lst.join('');
};



const rctViewport = fn_getRect(_elViewBox);
const rctBody = fn_getRect(_elBody);
// console.log(rctViewport, rctBody);
const fn_viewBox_cbf = (cbt = '') => {
    if (cbt === hfEventTypes.Scroll) {
        const prx = _viewBox.fn_getScrollPositionRatioX();
        const pry = _viewBox.fn_getScrollPositionRatioY();
        _hscr.fn_setScrollPositionRatio(prx);
        _vscr.fn_setScrollPositionRatio(pry);

        fn_rowCellsUpdate();
    }
    else if (cbt === 'normal') {
        _hscr.fn_setScrollSizeRatio(1 - _viewBox.fn_getScrollSizeRatioX());
        _vscr.fn_setScrollSizeRatio(1 - _viewBox.fn_getScrollSizeRatioY());

        fn_rowCellsUpdate(true);
    }
};
const _viewBox = new hfViewBox(rctViewport, rctBody, fn_viewBox_cbf);
// console.log(_viewBox.fn_getScrollSizeRatioX(), _viewBox.fn_getScrollSizeRatioY());
_viewBox.fn_applyDragMove(_elViewBox, _elBody);


const _hscr = new hfHScroll('hscr');
_hscr.addEventListener(hfEventTypes.Scroll, (e) => {
    const prx = _hscr.fn_getScrollPositionRatio();
    // console.log(prx);
    _viewBox.fn_setScrollPositionRatioX(prx);

    // _viewBox.fn_applyRectToElement(_elViewBox, hfViewBox.RN_VIEW_BOX);
    _viewBox.fn_applyRectToElement(_elBody, hfViewBox.RN_BODY);


    fn_rowCellsUpdate();
});


const _vscr = new hfVScroll('vscr');
_vscr.addEventListener(hfEventTypes.Scroll, (e) => {
    const pry = _vscr.fn_getScrollPositionRatio();
    // console.log(prx);
    _viewBox.fn_setScrollPositionRatioY(pry);

    // _viewBox.fn_applyRectToElement(_elViewBox, hfViewBox.RN_VIEW_BOX);
    _viewBox.fn_applyRectToElement(_elBody, hfViewBox.RN_BODY);


    fn_rowCellsUpdate();
});



const fn_resize = (e) => {
    const vbw = fn_getWidth(_elViewBox);
    const vbh = fn_getHeight(_elViewBox);
    _viewBox.fn_setViewWidth(vbw);
    _viewBox.fn_setViewHeight(vbh);

    const bdw = fn_getWidth(_elBody);
    const bdh = fn_getHeight(_elBody);
    _viewBox.fn_setBodyWidth(bdw);
    _viewBox.fn_setBodyHeight(bdh);

    // _viewBox.fn_applyRectToElement(_elViewBox, hfViewBox.RN_VIEW_BOX);
    _viewBox.fn_applyRectToElement(_elBody, hfViewBox.RN_BODY);


    const srx = 1 - _viewBox.fn_getScrollSizeRatioX();
    const sry = 1 - _viewBox.fn_getScrollSizeRatioY();
    // console.log(srx, sry);
    _hscr.fn_setScrollSizeRatio(srx);
    _vscr.fn_setScrollSizeRatio(sry);


    fn_rowCellsUpdate(true);
};
window.addEventListener(hfEventTypes.Resize, fn_resize);
fn_resize();















// const _naraSvg = document.getElementById('naraSvg');
// console.log(_naraSvg);

// _naraSvg.insertAdjacentHTML(
//     'beforeend', `<line x1="0" y1="0" x2="0" y2="200" style="stroke:red;stroke-width:14" />`);

// // _elViewBox.addEventListener(hfEventTypes.MouseDown, (e) => {
// //     _naraSvg.insertAdjacentHTML(
// //         'beforeend', `<rect width="200" height="100" x="${e.clientX}" y="${e.clientY}" rx="20" ry="20" fill="blue" />`);
// // });

// let _mdp = null;
// window.addEventListener(hfEventTypes.MouseMove, (e) => {
//     if (_mdp === null) _mdp = new DOMPoint();
//     _mdp.x = e.clientX;
//     _mdp.y = e.clientY;
// });
// const fn_frameLoop = () => {
//     if (_mdp !== null) {
//         _naraSvg.insertAdjacentHTML(
//             'beforeend', `<rect width="200" height="100" x="${_mdp.x}" y="${_mdp.y}" rx="20" ry="20" fill="blue" />`);
//     }
//     requestAnimationFrame(fn_frameLoop);
// };
// requestAnimationFrame(fn_frameLoop);
// window.addEventListener('keydown', (e) => {
//     // console.log(e.key==='d');
//     if (e.key === 'd') {
//         // let i = _naraSvg.childElementCount;
//         // while (i > 0) {
//         //     _naraSvg.removeChild()
//         //     --i;
//         // }
//         // console.log(_naraSvg.hasChildNodes());
//         // while (_naraSvg.hasChildNodes()) {
//         //     _naraSvg.firstChild
//         // }
//         _naraSvg.innerHTML = '';
//     }
// });









// const _rvo = Object.seal({x: 0, y: 0});
// const fn_loopFrame = () => {
//     // console.log(typeof arguments[0], arguments[0]);
//     // requestAnimationFrame(fn_loopFrame);

//     const sts = _elBody.style;
//     _rvo.x += 0.5;
//     _rvo.y += 2.0;
//     // console.log(_rvo.x);
//     sts.setProperty('transform', `rotateX(${_rvo.x}deg) rotateY(${_rvo.y}deg)`);
//     requestAnimationFrame(fn_loopFrame);

//     console.log(fn_getRect(_elBody));
// };
// requestAnimationFrame(fn_loopFrame);








// const _mySpan = document.getElementById('mySpan');
// _mySpan.style = `
// position: absolute; background-color: brown;
// color: whitesmoke; font-size: 12px;
// width: 100px; height: 30px;
// left: 100px; top: 20px;
// `.trim();
// window.addEventListener('mousemove', (e) => {
//     const sts = _mySpan.style;
//     const tx = e.clientX;
//     const ty = e.clientY;
//     sts.setProperty('left', `${tx - 100}px`);
//     sts.setProperty('top', `${ty - 30}px`);

//     // console.log(_mySpan.innerText);
//     _mySpan.innerText = `X: ${tx}, Y: ${ty}`;

//     // const rr = getComputedStyle(_mySpan);
//     // console.log(rr.display, rr.getPropertyValue('display'));
// });


/*
const fn_pad = (num) => {
    let rstr = num.toString().padStart(2, '0');
    return rstr;
};
const fn_timestamp = () => {
    const now = new Date();
    const rs = now.getFullYear().toString().substring(2, 4) + '/' +
        fn_pad(now.getMonth() + 1) + '/' +
        fn_pad(now.getDate()) + ' ' +
        fn_pad(now.getHours()) + ':' +
        fn_pad(now.getMinutes()) + ':' +
        fn_pad(now.getSeconds()) + '.' +
        fn_pad(now.getMilliseconds());
    return rs;
};
*/


const fn_pad = (num, cn=2) => {
    let rstr = num.toString().padStart(cn, '0');
    return rstr;
};
const fn_timestamp = () => {
    const now = new Date();
    const rs = 
		fn_pad(now.getFullYear(), 4) + '-' +
        fn_pad(now.getMonth() + 1) + '-' +
        fn_pad(now.getDate()) + ' ' +
        fn_pad(now.getHours()) + ':' +
        fn_pad(now.getMinutes()) + ':' +
        fn_pad(now.getSeconds()) + '.' +
        fn_pad(now.getMilliseconds(), 3);
    return rs;
};

