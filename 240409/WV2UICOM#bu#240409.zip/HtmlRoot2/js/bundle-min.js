const hfnum = Object.seal({
isNum: (tv) => {
return typeof tv === 'number';
},
notNum: (tv) => {
return typeof tv !== 'number';
},
isFloat: (tv) => {
return (tv % 1) !== 0;
},
isMinus: (tv) => {
return tv < 0;
},
random: (tv) => {
return Math.round(Math.random() * (tv - 1));
},
randRange: (min, max) => {
return min + Math.round(Math.random() * (max - min));
},
isOdd: (tv) => {
return (tv % 2) > 0;
},
isEven: (tv) => {
return (tv % 2) === 0;
}
});
const hfstr = Object.seal({
isStr: (str) => {
if (typeof str === 'string')
return str.trim() !== '';
else
return false;
},
getLastNum: (str, token = '_') => {
const ti = str.lastIndexOf(token) + 1;
return ~~str.substring(ti);
},
str2Ab: (str) => {
const l = str.length;
let tab = new Uint16Array(new ArrayBuffer(l * 2));
for (let i = 0; i < l; i++) {
tab[i] = str.charCodeAt(i);
}
return tab;
},
ab2Str: (ab) => {
return String.fromCharCode.apply(null, ab);
}
});
const hfarr = Object.seal({
notEmpty: (arr) => {
return Array.isArray(arr) && (arr.length > 0);
},
contains: (arr, te) => {
if (hfarr.notEmpty(arr) === false) return false;
let tb = false;
const l = arr.length;
for (let i = 0; i < l; i++) {
if (arr[i] === te) {
tb = true;
break;
}
}
return tb;
},
shuffle: (arr) => {
if (hfarr.notEmpty(arr) === false) return;
const l = arr.length;
for (let i = 0; i < l; i++) {
let te = arr[i];
let ti = hfnum.randRange(0, l - 1);
arr[i] = arr[ti];
arr[ti] = te;
}
},
copy: (arr) => {
if (hfarr.notEmpty(arr) === false) return null;
return arr.slice();
}
});
const hfdtime = Object.seal({
timeStamp: (td) => {
const df1 = td.getFullYear().toString().substring(2);
const df2 = (td.getMonth() + 1).toString().padStart(2, '0');
const df3 = td.getDate().toString().padStart(2, '0');
const df4 = td.getHours().toString().padStart(2, '0');
const df5 = td.getMinutes().toString().padStart(2, '0');
const df6 = td.getSeconds().toString().padStart(2, '0');
const df7 = td.getMilliseconds().toString().padStart(3, '0');
return `${df1}/${df2}/${df3} ${df4}:${df5}:${df6}.${df7}`;
},
format: (fs1, td) => {
const re1 = /\\./g;
const mc1 = Array.from(fs1.matchAll(re1));
const len = fs1.length - mc1.length;
const buf1 = new Uint16Array(new ArrayBuffer(len * 2));
let i = 0;
for (const m1 of mc1) {
const fi = m1.index - i;
const tv = m1[0];
const li = tv.length - 1;
buf1[fi] = tv[li].charCodeAt(0);
++i;
}
const buf2 = new Uint16Array(new ArrayBuffer(len * 2));
const ke = fs1.length - 1; i = 0;
let bp = false;
for (let k = 0; k <= ke; ++k) {
const tc = fs1[k];
if (bp) {
bp = false;
buf2[i++] = '\0'.charCodeAt(0);
}
else {
bp = tc === '\\';
if (bp && (k < ke))
continue;
else
buf2[i++] = tc.charCodeAt(0);
}
}
let mrs = String.fromCharCode.apply(null, buf2);
const re2 = /y+|M+|d+|H+|m+|s+|f+/g;
const fn_r = (tx, l1) => {
const l2 = tx.length;
if (l1 < l2)
return tx.substring(l2 - l1);
else if (l1 > l2)
return tx.padStart(l1, '0');
return tx;
};
const fn_me = (tx, td) => {
const l1 = tx.length;
if (tx[0] === 'y')
return fn_r(td.getFullYear().toString(), l1);
else if (tx[0] === 'M')
return fn_r((td.getMonth() + 1).toString(), l1);
else if (tx[0] === 'd')
return fn_r(td.getDate().toString(), l1);
else if (tx[0] === 'H')
return fn_r(td.getHours().toString(), l1);
else if (tx[0] === 'm')
return fn_r(td.getMinutes().toString(), l1);
else if (tx[0] === 's')
return fn_r(td.getSeconds().toString(), l1);
else if (tx[0] === 'f')
return fn_r(td.getMilliseconds().toString(), l1);
return tx;
};
mrs = mrs.replace(re2, (tx) => {
return fn_me(tx, td);
});
for (i = 0; i < len; ++i) {
const tc = String.fromCharCode(buf1[i]);
if (tc === '\0')
buf1[i] = mrs[i].charCodeAt(0);
}
const res = String.fromCharCode.apply(null, buf1);
return res;
}
});
const hfEventTypes = Object.freeze({
MouseMove: 'mousemove',
Blur: 'blur',
MouseUp: 'mouseup',
MouseDown: 'mousedown',
Scroll: 'scroll',
Resize: 'resize',
Click: 'click',
MouseWheel: 'mousewheel'
});
const fn_getStyles = (to, bw=false) => {
if (to instanceof CSSStyleDeclaration)
return to;
else if (to instanceof HTMLElement) {
if (bw === true)
return to.style;
else
return getComputedStyle(to);
}
else return null;
};
const fn_checkNumber = (tv, dv=0) => {
let rv = NaN;
if (typeof tv === 'number')
rv = tv;
else if (typeof tv === 'string')
rv = parseFloat(tv);
if (isFinite(rv) === true)
return rv;
else
return dv;
};
const fn_getWidth = (to) => {
const sts = fn_getStyles(to);
if (sts !== null) {
let tv = sts.getPropertyValue('width');
return fn_checkNumber(tv);
}
else return 0.0;
};
const fn_setWidth = (to, tv) => {
const sts = fn_getStyles(to, true);
if (sts !== null) {
tv = fn_checkNumber(tv);
sts.setProperty('width', `${tv}px`);
}
};
const fn_getHeight = (to) => {
const sts = fn_getStyles(to);
if (sts !== null) {
let tv = sts.getPropertyValue('height');
return fn_checkNumber(tv);
}
else return 0.0;
};
const fn_setHeight = (to, tv) => {
const sts = fn_getStyles(to, true);
if (sts !== null) {
tv = fn_checkNumber(tv);
sts.setProperty('height', `${tv}px`);
}
};
const fn_getLeft = (to) => {
const sts = fn_getStyles(to);
if (sts !== null) {
let tv = sts.getPropertyValue('left');
return fn_checkNumber(tv);
}
else return 0.0;
};
const fn_setLeft = (to, tv) => {
const sts = fn_getStyles(to, true);
if (sts !== null) {
tv = fn_checkNumber(tv);
sts.setProperty('left', `${tv}px`);
}
};
const fn_getTop = (to) => {
const sts = fn_getStyles(to);
if (sts !== null) {
let tv = sts.getPropertyValue('top');
return fn_checkNumber(tv);
}
else return 0.0;
};
const fn_setTop = (to, tv) => {
const sts = fn_getStyles(to, true);
if (sts !== null) {
tv = fn_checkNumber(tv);
sts.setProperty('top', `${tv}px`);
}
};
const fn_getRect = (to) => {
const sts = fn_getStyles(to);
if (sts !== null) {
let tx = fn_getLeft(sts);
let ty = fn_getTop(sts);
let tw = fn_getWidth(sts);
let th = fn_getHeight(sts);
let rct = new DOMRect(tx, ty, tw, th);
return rct;
}
else return null;
};
const fn_updateRect = (to, rct) => {
const sts = fn_getStyles(to);
if (sts !== null) {
let tw = fn_getWidth(sts);
let th = fn_getHeight(sts);
fn_getLeft(sts);
fn_getTop(sts);
rct.width = tw;
rct.height = th;
}
};
const fn_containsRect = (rct, tx, ty) => {
const rb = ((rct.left <= tx) && (rct.right >= tx)) &&
((rct.top <= ty) && (rct.bottom >= ty));
return rb;
};
const fn_applyRectToElement = (to, rct) => {
const sts = fn_getStyles(to, true);
if ((sts !== null) && (rct instanceof DOMRect)) {
fn_setLeft(sts, rct.left);
fn_setTop(sts, rct.top);
fn_setWidth(sts, rct.width);
fn_setHeight(sts, rct.height);
}
};
const hfViewBox = Object.freeze(class {
constructor(rctViewport, rctBody, cbf=null) {
this.#rctViewport = rctViewport;
this.#rctBody = rctBody;
this.#rctBody.x = this.#rctViewport.left;
this.#rctBody.y = this.#rctViewport.top;
this.#cbf = cbf;
this.#fn_updateScrollSizeWidth();
this.#fn_updateScrollSizeHeight();
this.#fn_updateScrollPositionRatioX();
this.#fn_updateScrollPositionX();
this.#fn_updateScrollPositionRatioY();
this.#fn_updateScrollPositionY();
}
#rctViewport = null;
#rctBody = null;
#cbf = null;
#fn_callback(cbt) {
if (this.#cbf === null) return;
this.#cbf(cbt);
}
#scrollSizeWidth = NaN;
#scrollSizeRatioX = NaN;
#fn_updateScrollSizeWidth() {
let scv = this.#rctBody.width - this.#rctViewport.width;
if (scv === this.#scrollSizeWidth) return;
if (scv > 0.0) {
this.#scrollSizeWidth = scv;
let sr = this.#scrollSizeWidth / this.#rctBody.width;
if (isFinite(sr) === false) {
sr = 0.0;
this.#scrollSizeRatioX = sr;
}
else {
if (sr < 0.0) sr = 0.0;
else if (sr > 1.0) sr = 1.0;
this.#scrollSizeRatioX = sr;
}
}
else {
this.#scrollSizeWidth = 0.0;
this.#scrollSizeRatioX = 0.0;
}
}
fn_getScrollSizeWidth(bu=false) {
if (bu === true) this.#fn_updateScrollSizeWidth();
return this.#scrollSizeWidth;
}
fn_getScrollSizeRatioX(bu=false) {
if (bu === true) this.#fn_updateScrollSizeWidth();
return this.#scrollSizeRatioX;
}
#scrollSizeHeight = NaN;
#scrollSizeRatioY = NaN;
#fn_updateScrollSizeHeight() {
let scv = this.#rctBody.height - this.#rctViewport.height;
if (scv === this.#scrollSizeHeight) return;
if (scv > 0.0) {
this.#scrollSizeHeight = scv;
let sr = this.#scrollSizeHeight / this.#rctBody.height;
if (isFinite(sr) === false) {
sr = 0.0;
this.#scrollSizeRatioY = sr;
}
else {
if (sr < 0.0) sr = 0.0;
else if (sr > 1.0) sr = 1.0;
this.#scrollSizeRatioY = sr;
}
}
else {
this.#scrollSizeHeight = 0.0;
this.#scrollSizeRatioY = 0.0;
}
}
fn_getScrollSizeHeight(bu=false) {
if (bu === true) this.#fn_updateScrollSizeHeight();
return this.#scrollSizeHeight;
}
fn_getScrollSizeRatioY(bu=false) {
if (bu === true) this.#fn_updateScrollSizeHeight();
return this.#scrollSizeRatioY;
}
#scrollPositionRatioX = NaN;
#fn_updateScrollPositionRatioX() {
const scv = this.fn_getScrollSizeWidth(true);
let sp = this.#rctViewport.left - this.#rctBody.left;
if (sp < 0.0) sp = 0.0;
let sr = sp / scv;
if (isFinite(sr) === true) {
if (sr < 0.0) sr = 0.0;
else if (sr > 1.0) sr = 1.0;
this.#scrollPositionRatioX = sr;
}
else {
sr = 0.0;
this.#scrollPositionRatioX = sr;
}
}
fn_getScrollPositionRatioX(bu=false) {
if (bu === true) this.#fn_updateScrollPositionRatioX();
return this.#scrollPositionRatioX;
}
fn_setScrollPositionRatioX(val) {
let sr = val;
if (sr !== this.#scrollPositionRatioX) {
if (sr < 0.0) sr = 0.0;
else if (sr > 1.0) sr = 1.0;
this.#scrollPositionRatioX = sr;
this.#fn_updateScrollPositionX(false);
this.#fn_calcRctBodyX();
}
}
#scrollPositionX = NaN;
#fn_updateScrollPositionX(br=true) {
if (br === true) {
let sp = this.#rctViewport.left - this.#rctBody.left;
if (sp < 0.0) sp = 0.0;
this.#scrollPositionX = sp;
}
else {
const scv = this.fn_getScrollSizeWidth();
const sr = this.fn_getScrollPositionRatioX();
let sp = scv * sr;
this.#scrollPositionX = sp;
}
}
#fn_getScrollPositionX(bu=false) {
if (bu === true) this.#fn_updateScrollPositionX();
return this.#scrollPositionX;
}
#fn_calcRctBodyX() {
const scv = this.fn_getScrollSizeWidth();
const gjv = this.#rctViewport.left;
if (scv > 0.0) {
const bv = gjv - scv;
const ev = gjv;
let rp = gjv - this.#scrollPositionX;
if (rp < bv) rp = bv;
else if (rp > ev) rp = ev;
this.#rctBody.x = rp;
}
else {
let rp = (this.#rctViewport.right - (this.#rctViewport.width / 2)) -
(this.#rctBody.width / 2);
this.#rctBody.x = rp;
}
}
#fn_setScrollPositionX(val) {
const bv = 0.0;
const ev = this.fn_getScrollSizeWidth();
if (bv === ev) return;
let sp = val;
if (sp !== this.#scrollPositionX) {
if (sp < bv) sp = bv;
else if (sp > ev) sp = ev;
this.#scrollPositionX = sp;
this.#fn_calcRctBodyX();
this.#fn_updateScrollPositionRatioX();
}
}
#scrollPositionRatioY = NaN;
#fn_updateScrollPositionRatioY() {
const scv = this.fn_getScrollSizeHeight(true);
let sp = this.#rctViewport.top - this.#rctBody.top;
if (sp < 0.0) sp = 0.0;
let sr = sp / scv;
if (isFinite(sr) === true) {
if (sr < 0.0) sr = 0.0;
else if (sr > 1.0) sr = 1.0;
this.#scrollPositionRatioY = sr;
}
else {
sr = 0.0;
this.#scrollPositionRatioY = sr;
}
}
fn_getScrollPositionRatioY(bu=false) {
if (bu === true) this.#fn_updateScrollPositionRatioY();
return this.#scrollPositionRatioY;
}
fn_setScrollPositionRatioY(val) {
let sr = val;
if (sr !== this.#scrollPositionRatioY) {
if (sr < 0.0) sr = 0.0;
else if (sr > 1.0) sr = 1.0;
this.#scrollPositionRatioY = sr;
this.#fn_updateScrollPositionY(false);
this.#fn_calcRctBodyY();
}
}
#scrollPositionY = NaN;
#fn_updateScrollPositionY(br=true) {
if (br === true) {
let sp = this.#rctViewport.top - this.#rctBody.top;
if (sp < 0.0) sp = 0.0;
this.#scrollPositionY = sp;
}
else {
const scv = this.fn_getScrollSizeHeight();
const sr = this.fn_getScrollPositionRatioY();
let sp = scv * sr;
this.#scrollPositionY = sp;
}
}
#fn_getScrollPositionY(bu=false) {
if (bu === true) this.#fn_updateScrollPositionY();
return this.#scrollPositionY;
}
#fn_calcRctBodyY() {
const scv = this.fn_getScrollSizeHeight();
const gjv = this.#rctViewport.top;
if (scv > 0.0) {
const bv = gjv - scv;
const ev = gjv;
let rp = gjv - this.#scrollPositionY;
if (rp < bv) rp = bv;
else if (rp > ev) rp = ev;
this.#rctBody.y = rp;
}
else {
let rp = (this.#rctViewport.bottom - (this.#rctViewport.height / 2)) -
(this.#rctBody.height / 2);
this.#rctBody.y = rp;
}
}
#fn_setScrollPositionY(val) {
const bv = 0.0;
const ev = this.fn_getScrollSizeHeight();
if (bv === ev) return;
let sp = val;
if (sp !== this.#scrollPositionY) {
if (sp < bv) sp = bv;
else if (sp > ev) sp = ev;
this.#scrollPositionY = sp;
this.#fn_calcRctBodyY();
this.#fn_updateScrollPositionRatioY();
}
}
static RN_VIEW_BOX = 'rctViewBox';
static RN_BODY = 'rctBody';
fn_applyRectToElement(el, rn) {
let rct = null;
if (rn === hfViewBox.RN_VIEW_BOX) {
rct = this.#rctViewport;
}
else if (rn === hfViewBox.RN_BODY) {
rct = this.#rctBody;
}
if ((rct !== null) && (el !== null)) {
fn_applyRectToElement(el, rct);
}
}
static #MIN_W = 10.0;
fn_getViewWidth() {
return this.#rctViewport.width;
}
fn_setViewWidth(val) {
if (val === this.#rctViewport.width) return;
if (val < hfViewBox.#MIN_W) val = hfViewBox.#MIN_W;
this.#rctViewport.width = val;
this.#fn_updateScrollSizeWidth();
this.#fn_updateScrollPositionX(false);
this.#fn_calcRctBodyX();
}
fn_getBodyWidth() {
return this.#rctBody.width;
}
fn_setBodyWidth(val) {
if (val === this.#rctBody.width) return;
if (val < hfViewBox.#MIN_W) val = hfViewBox.#MIN_W;
this.#rctBody.width = val;
this.#fn_updateScrollSizeWidth();
this.#fn_updateScrollPositionX(false);
this.#fn_calcRctBodyX();
}
static #MIN_H = 10.0;
fn_getViewHeight() {
return this.#rctViewport.height;
}
fn_setViewHeight(val) {
if (val === this.#rctViewport.height) return;
if (val < hfViewBox.#MIN_H) val = hfViewBox.#MIN_H;
this.#rctViewport.height = val;
this.#fn_updateScrollSizeHeight();
this.#fn_updateScrollPositionY(false);
this.#fn_calcRctBodyY();
}
fn_getBodyHeight() {
return this.#rctBody.height;
}
fn_setBodyHeight(val) {
if (val === this.#rctBody.height) return;
if (val < hfViewBox.#MIN_H) val = hfViewBox.#MIN_H;
this.#rctBody.height = val;
this.#fn_updateScrollSizeHeight();
this.#fn_updateScrollPositionY(false);
this.#fn_calcRctBodyY();
}
#elViewBox = null;
#elBody = null;
#bmd = false;
#mdp = new DOMPoint(0, 0);
#fn_mouseMove = (e) => {
if (this.#bmd === false) return;
const cx = (this.#mdp.x - e.clientX) + this.#rctViewport.left;
const cy = (this.#mdp.y - e.clientY) + this.#rctViewport.top;
this.#fn_setScrollPositionX(cx);
this.#fn_setScrollPositionY(cy);
this.fn_applyRectToElement(this.#elBody, hfViewBox.RN_BODY);
this.#fn_callback(hfEventTypes.Scroll);
}
#fn_mouseUp = (e) => {
if (this.#bmd === false) return;
window.removeEventListener(hfEventTypes.MouseMove, this.#fn_mouseMove);
window.removeEventListener(hfEventTypes.Blur, this.#fn_mouseUp);
window.removeEventListener(hfEventTypes.MouseUp, this.#fn_mouseUp);
this.#bmd = false;
};
#fn_mouseDown = (e) => {
if (this.#bmd === true) return;
window.addEventListener(hfEventTypes.MouseMove, this.#fn_mouseMove);
window.addEventListener(hfEventTypes.Blur, this.#fn_mouseUp);
window.addEventListener(hfEventTypes.MouseUp, this.#fn_mouseUp);
this.#bmd = true;
this.#mdp.x = e.clientX - this.#rctBody.left;
this.#mdp.y = e.clientY - this.#rctBody.top;
this.#fn_mouseMove(e);
};
#fn_stageMouseWheel = (e) => {
if (e === null) return;
let bdw = this.fn_getBodyWidth();
let bdh = this.fn_getBodyHeight();
let dw, dh;
let dg = (e.ctrlKey === true) ? 0.1 : 0.01;
if (e.deltaY < 0) {
dw = this.fn_getBodyWidth() * dg;
dh = this.fn_getBodyHeight() * dg;
bdw = bdw + dw;
bdh = bdh + dh;
}
else {
dw = this.fn_getBodyWidth() * dg;
dh = this.fn_getBodyHeight() * dg;
bdw = bdw - dw;
bdh = bdh - dh;
}
this.fn_setBodyWidth(bdw);
this.fn_setBodyHeight(bdh);
this.fn_applyRectToElement(this.#elBody, hfViewBox.RN_BODY);
this.#fn_callback('normal');
}
fn_applyDragMove(elViewBox, elBody) {
this.#elViewBox = elViewBox;
this.#elBody = elBody;
this.#elViewBox.addEventListener(hfEventTypes.MouseDown, this.#fn_mouseDown);
this.#elViewBox.addEventListener(hfEventTypes.MouseWheel, this.#fn_stageMouseWheel
, {passive: false});
}
});
const hfHScroll = Object.freeze(class extends EventTarget {
constructor(elId='hscr') {
super();
this.#elGround = document.getElementById(elId);
this.#elGround.setAttribute('style', `
width: 100%; height: 20px;
background-color: #595959;
position: static; display: inline-block;
overflow-x: hidden; overflow-y: hidden;
font-size: 0px; cursor: pointer;
`.trim());
this.#elGround.innerHTML = `
<div style="background-color: #748B96;
position: relative;
width: 100%; height: 100%;
left: 0px; top: 0px;
pointer-events: none; overflow: visible;
box-sizing: border-box; font-size: 0px;
border: 3px solid #595959;">
<span style="
position: relative;
display: inline-block;
width: auto; height: auto;
left: 50%; top: 50%;
transform: translate(-50%, -50%);
user-select: none; white-space: nowrap;
font-size: 11px; color: #ffffff66;"></span>
</div>
`.trim();
this.#elThumb = this.#elGround.children[0];
this.#elSpan = this.#elThumb.children[0];
this.#elSpan.innerText = '';
this.#rctGround = fn_getRect(this.#elGround);
this.#rctThumb = fn_getRect(this.#elThumb);
this.#elGround.addEventListener(hfEventTypes.MouseDown, this.#fn_mouseDown);
window.addEventListener(hfEventTypes.Resize, this.#fn_resize);
}
static #MINV = 30.0;
#elGround = null;
#elThumb = null;
#elSpan = null;
#rctGround = null;
#rctThumb = null;
#scrollSizeRatio = 1.0;
#scrollPositionRatio = 0.0;
#bmd = false;
#mdp = NaN;
#fn_printSpanLog() {
{
const ssr = (100 * this.#scrollSizeRatio).toFixed(1);
const spr = (100 * this.#scrollPositionRatio).toFixed(1);
this.#elSpan.innerText = `${ssr}% / ${spr}%`;
}
}
#fn_getScrollSize() {
let ss = this.#rctGround.width - this.#rctThumb.width;
if (ss < 0.0) ss = 0.0;
return ss;
}
#fn_setThumbSize(val, bApply=true) {
if (val === this.#rctThumb.width) return;
const bv = hfHScroll.#MINV;
const ev = this.#rctGround.width;
let cv = val;
if (cv < bv) cv = bv;
else if (cv > ev) cv = ev;
this.#rctThumb.width = cv;
const sv = this.#fn_getScrollSize() * this.#scrollPositionRatio;
this.#rctThumb.x = sv;
if (bApply === true) {
fn_setWidth(this.#elThumb, this.#rctThumb.width);
fn_setLeft(this.#elThumb, this.#rctThumb.left);
}
}
#fn_setThumbPosition(val, bApply=true) {
if (val === this.#rctThumb.left) return;
const bv = 0.0;
const ev = this.#fn_getScrollSize();
let cv = val;
if (cv < bv) cv = bv;
else if (cv > ev) cv = ev;
this.#rctThumb.x = cv;
let vr = (cv - bv) / (ev - bv);
if (isFinite(vr) === true) {
this.#scrollPositionRatio = vr;
}
if (bApply === true) {
fn_setLeft(this.#elThumb, this.#rctThumb.left);
}
}
fn_getScrollSizeRatio() {
return this.#scrollSizeRatio;
}
fn_setScrollSizeRatio(val, bApply=true) {
if (val < 0.0) val = 0.0;
else if (val > 1.0) val = 1.0;
this.#scrollSizeRatio = val;
const sz = this.#rctGround.width * this.#scrollSizeRatio;
this.#fn_setThumbSize(sz, bApply);
this.#fn_printSpanLog();
}
fn_getScrollPositionRatio() {
return this.#scrollPositionRatio;
}
fn_setScrollPositionRatio(val, bApply=true) {
if (val === this.#scrollPositionRatio) return;
if (val < 0.0) val = 0.0;
else if (val > 1.0) val = 1.0;
this.#scrollPositionRatio = val;
const bv = 0.0;
const ev = this.#fn_getScrollSize();
let cv = ev * this.#scrollPositionRatio;
if (cv < bv) cv = bv;
else if (cv > ev) cv = ev;
this.#rctThumb.x = cv;
this.#fn_printSpanLog();
if (bApply === true) {
fn_setLeft(this.#elThumb, this.#rctThumb.left);
}
}
#fn_updateAfterResized(bApply=true) {
const bv = hfHScroll.#MINV;
const ev = this.#rctGround.width;
let cv = ev * this.#scrollSizeRatio;
if (cv < bv) cv = bv;
else if (cv > ev) cv = ev;
this.#rctThumb.width = cv;
const cp = this.#fn_getScrollSize() * this.#scrollPositionRatio;
this.#rctThumb.x = cp;
if (bApply === true) {
fn_setWidth(this.#elThumb, this.#rctThumb.width);
fn_setLeft(this.#elThumb, this.#rctThumb.left);
}
this.#fn_printSpanLog();
}
#fn_mouseMove = (e) => {
if (this.#bmd === false) return;
const cv = e.clientX - this.#mdp;
this.#fn_setThumbPosition(cv);
this.#fn_printSpanLog();
this.dispatchEvent(new Event(hfEventTypes.Scroll));
}
#fn_mouseUp = (e) => {
if (this.#bmd === false) return;
window.removeEventListener(hfEventTypes.MouseMove, this.#fn_mouseMove);
window.removeEventListener(hfEventTypes.MouseUp, this.#fn_mouseUp);
window.removeEventListener(hfEventTypes.Blur, this.#fn_mouseUp);
this.#bmd = false;
}
#fn_mouseDown = (e) => {
if (this.#bmd === true) return;
window.addEventListener(hfEventTypes.MouseMove, this.#fn_mouseMove);
window.addEventListener(hfEventTypes.MouseUp, this.#fn_mouseUp);
window.addEventListener(hfEventTypes.Blur, this.#fn_mouseUp);
this.#bmd = true;
if (fn_containsRect(this.#rctThumb, e.offsetX, e.offsetY) === true) {
this.#mdp = e.clientX - this.#rctThumb.left;
this.#fn_mouseMove(e);
}
else {
const cv = e.clientX - (this.#rctThumb.width / 2);
this.#fn_setThumbPosition(cv);
this.#fn_printSpanLog();
this.#mdp = e.clientX - this.#rctThumb.left;
this.dispatchEvent(new Event(hfEventTypes.Scroll));
}
}
#fn_resize = (e) => {
fn_updateRect(this.#elGround, this.#rctGround);
fn_updateRect(this.#rctThumb, this.#rctThumb);
this.#fn_updateAfterResized();
}
});
const hfVScroll = Object.freeze(class extends EventTarget {
constructor(elId='vscr') {
super();
this.#elGround = document.getElementById(elId);
this.#elGround.setAttribute('style', `
width: 20px; height: 100%;
background-color: #595959;
position: static; display: inline-block;
overflow-x: hidden; overflow-y: hidden;
font-size: 0px; cursor: pointer;
`.trim());
this.#elGround.innerHTML = `
<div style="background-color: #748B96;
position: relative;
width: 100%; height: 100%;
left: 0px; top: 0px;
pointer-events: none; overflow: visible;
box-sizing: border-box; font-size: 0px;
border: 3px solid #595959;">
<span style="
position: relative;
display: inline-block;
width: auto; height: auto;
left: 50%; top: 50%;
transform: translate(-50%, -50%) rotate(-90deg);
user-select: none; white-space: nowrap;
font-size: 11px; color: #ffffff66;"></span>
</div>
`.trim();
this.#elThumb = this.#elGround.children[0];
this.#elSpan = this.#elThumb.children[0];
this.#elSpan.innerText = '';
this.#rctGround = fn_getRect(this.#elGround);
this.#rctThumb = fn_getRect(this.#elThumb);
this.#elGround.addEventListener(hfEventTypes.MouseDown, this.#fn_mouseDown);
window.addEventListener(hfEventTypes.Resize, this.#fn_resize);
}
static #MINV = 30.0;
#elGround = null;
#elThumb = null;
#elSpan = null;
#rctGround = null;
#rctThumb = null;
#scrollSizeRatio = 1.0;
#scrollPositionRatio = 0.0;
#bmd = false;
#mdp = NaN;
#fn_printSpanLog() {
{
const ssr = (100 * this.#scrollSizeRatio).toFixed(1);
const spr = (100 * this.#scrollPositionRatio).toFixed(1);
this.#elSpan.innerText = `${ssr}% / ${spr}%`;
}
}
#fn_getScrollSize() {
let ss = this.#rctGround.height - this.#rctThumb.height;
if (ss < 0.0) ss = 0.0;
return ss;
}
#fn_setThumbSize(val, bApply=true) {
if (val === this.#rctThumb.height) return;
const bv = hfVScroll.#MINV;
const ev = this.#rctGround.height;
let cv = val;
if (cv < bv) cv = bv;
else if (cv > ev) cv = ev;
this.#rctThumb.height = cv;
const sv = this.#fn_getScrollSize() * this.#scrollPositionRatio;
this.#rctThumb.y = sv;
if (bApply === true) {
fn_setHeight(this.#elThumb, this.#rctThumb.height);
fn_setTop(this.#elThumb, this.#rctThumb.top);
}
}
#fn_setThumbPosition(val, bApply=true) {
if (val === this.#rctThumb.top) return;
const bv = 0.0;
const ev = this.#fn_getScrollSize();
let cv = val;
if (cv < bv) cv = bv;
else if (cv > ev) cv = ev;
this.#rctThumb.y = cv;
let vr = (cv - bv) / (ev - bv);
if (isFinite(vr) === true) {
this.#scrollPositionRatio = vr;
}
if (bApply === true) {
fn_setTop(this.#elThumb, this.#rctThumb.top);
}
}
fn_getScrollSizeRatio() {
return this.#scrollSizeRatio;
}
fn_setScrollSizeRatio(val, bApply=true) {
if (val < 0.0) val = 0.0;
else if (val > 1.0) val = 1.0;
this.#scrollSizeRatio = val;
const sz = this.#rctGround.height * this.#scrollSizeRatio;
this.#fn_setThumbSize(sz, bApply);
this.#fn_printSpanLog();
}
fn_getScrollPositionRatio() {
return this.#scrollPositionRatio;
}
fn_setScrollPositionRatio(val, bApply=true) {
if (val === this.#scrollPositionRatio) return;
if (val < 0.0) val = 0.0;
else if (val > 1.0) val = 1.0;
this.#scrollPositionRatio = val;
const bv = 0.0;
const ev = this.#fn_getScrollSize();
let cv = ev * this.#scrollPositionRatio;
if (cv < bv) cv = bv;
else if (cv > ev) cv = ev;
this.#rctThumb.y = cv;
this.#fn_printSpanLog();
if (bApply === true) {
fn_setTop(this.#elThumb, this.#rctThumb.top);
}
}
#fn_updateAfterResized(bApply=true) {
const bv = hfVScroll.#MINV;
const ev = this.#rctGround.height;
let cv = ev * this.#scrollSizeRatio;
if (cv < bv) cv = bv;
else if (cv > ev) cv = ev;
this.#rctThumb.height = cv;
const cp = this.#fn_getScrollSize() * this.#scrollPositionRatio;
this.#rctThumb.y = cp;
if (bApply === true) {
fn_setHeight(this.#elThumb, this.#rctThumb.height);
fn_setTop(this.#elThumb, this.#rctThumb.top);
}
this.#fn_printSpanLog();
}
#fn_mouseMove = (e) => {
if (this.#bmd === false) return;
const cv = e.clientY - this.#mdp;
this.#fn_setThumbPosition(cv);
this.#fn_printSpanLog();
this.dispatchEvent(new Event(hfEventTypes.Scroll));
}
#fn_mouseUp = (e) => {
if (this.#bmd === false) return;
window.removeEventListener(hfEventTypes.MouseMove, this.#fn_mouseMove);
window.removeEventListener(hfEventTypes.MouseUp, this.#fn_mouseUp);
window.removeEventListener(hfEventTypes.Blur, this.#fn_mouseUp);
this.#bmd = false;
}
#fn_mouseDown = (e) => {
if (this.#bmd === true) return;
window.addEventListener(hfEventTypes.MouseMove, this.#fn_mouseMove);
window.addEventListener(hfEventTypes.MouseUp, this.#fn_mouseUp);
window.addEventListener(hfEventTypes.Blur, this.#fn_mouseUp);
this.#bmd = true;
if (fn_containsRect(this.#rctThumb, e.offsetX, e.offsetY) === true) {
this.#mdp = e.clientY - this.#rctThumb.top;
this.#fn_mouseMove(e);
}
else {
const cv = e.clientY - (this.#rctThumb.height / 2);
this.#fn_setThumbPosition(cv);
this.#fn_printSpanLog();
this.#mdp = e.clientY - this.#rctThumb.top;
this.dispatchEvent(new Event(hfEventTypes.Scroll));
}
}
#fn_resize = (e) => {
fn_updateRect(this.#elGround, this.#rctGround);
fn_updateRect(this.#rctThumb, this.#rctThumb);
this.#fn_updateAfterResized();
}
});
class hfCountTask {
constructor(countStart = 1, countEnd = 10, plusValue = 1) {
this.#countStart = countStart;
this.#countEnd = countEnd;
this.#plusValue = plusValue;
this.#count = countStart;
}
#countStart = 0;
get CountStart() {
return this.#countStart;
}
#countEnd = 0;
get CountEnd() {
return this.#countEnd;
}
#plusValue = 0;
get PlusValue() {
return this.#plusValue;
}
#count = 0;
get Count() {
return this.#count;
}
Prev() {
const tc = this.#count - this.#plusValue;
if (tc < this.#countStart)
return false;
else {
this.#count = tc;
return true;
}
}
Next() {
const tc = this.#count + this.#plusValue;
if (tc > this.#countEnd)
return false;
else {
this.#count = tc;
return true;
}
}
Reset() {
this.#count = this.#countStart;
}
ResetEnd() {
this.#count = this.#countEnd;
}
}
const hfEaseBack = Object.seal({
easeIn(t, b, c, d, s = 1.70158) {
return c * (t /= d) * t * ((s + 1) * t - s) + b;
},
easeOut(t, b, c, d, s = 1.70158) {
return c * ((t = t / d - 1) * t * ((s + 1) * t + s) + 1) + b;
},
easeInOut(t, b, c, d, s = 1.70158) {
if ((t /= d / 2) < 1)
return c / 2 * (t * t * (((s *= (1.525)) + 1) * t - s)) + b;
return c / 2 * ((t -= 2) * t * (((s *= (1.525)) + 1) * t + s) + 2) + b;
}
});
const hfEaseBounce = Object.seal({
easeIn(t, b, c, d) {
return c - this.easeOut(d - t, 0, c, d) + b;
},
easeOut(t, b, c, d) {
if ((t /= d) < (1 / 2.75))
return c * (7.5625 * t * t) + b;
else if (t < (2 / 2.75))
return c * (7.5625 * (t -= (1.5 / 2.75)) * t + 0.75) + b;
else if (t < (2.5 / 2.75))
return c * (7.5625 * (t -= (2.25 / 2.75)) * t + 0.9375) + b;
else
return c * (7.5625 * (t -= (2.625 / 2.75)) * t + 0.984375) + b;
},
easeInOut(t, b, c, d) {
if (t < d/2)
return this.easeIn(t * 2, 0, c, d) * 0.5 + b;
else
return this.easeOut(t * 2 - d, 0, c, d) * 0.5 + c * 0.5 + b;
}
});
const hfEaseCircular = Object.seal({
easeIn(t, b, c, d) {
return -c * (Math.sqrt(1 - (t /= d) * t) - 1) + b;
},
easeOut(t, b, c, d) {
return c * Math.sqrt(1 - (t = t/d - 1) * t) + b;
},
easeInOut(t, b, c, d) {
if ((t /= d / 2) < 1)
return -c / 2 * (Math.sqrt(1 - t * t) - 1) + b;
return c / 2 * (Math.sqrt(1 - (t -= 2) * t) + 1) + b;
}
});
const hfEaseElastic = Object.seal({
easeIn(t, b, c, d, a = 0, p = 0) {
if (t == 0) return b;
if ((t /= d) == 1) return b + c;
if (!p) p = d * 0.3;
let s;
if (!a || a < Math.abs(c)) {
a = c;
s = p / 4;
}
else {
s = p / (2 * Math.PI) * Math.asin(c / a);
}
return -(a * Math.pow(2, 10 * (t -= 1)) *
Math.sin((t * d - s) * (2 * Math.PI) / p)) + b;
},
easeOut(t, b, c, d, a = 0, p = 0) {
if (t == 0) return b;
if ((t /= d) == 1) return b + c;
if (!p) p = d * 0.3;
let s;
if (!a || a < Math.abs(c)) {
a = c;
s = p / 4;
}
else {
s = p / (2 * Math.PI) * Math.asin(c / a);
}
return a * Math.pow(2, -10 * t) *
Math.sin((t * d - s) * (2 * Math.PI) / p) + c + b;
},
easeInOut(t, b, c, d, a = 0, p = 0) {
if (t == 0) return b;
if ((t /= d / 2) == 2) return b + c;
if (!p) p = d * (0.3 * 1.5);
let s;
if (!a || a < Math.abs(c)) {
a = c;
s = p / 4;
}
else {
s = p / (2 * Math.PI) * Math.asin(c / a);
}
if (t < 1) {
return -0.5 * (a * Math.pow(2, 10 * (t -= 1)) *
Math.sin((t * d - s) * (2 * Math.PI) /p)) + b;
}
return a * Math.pow(2, -10 * (t -= 1)) *
Math.sin((t * d - s) * (2 * Math.PI) / p ) * 0.5 + c + b;
}
});
const hfEaseExponential = Object.seal({
easeIn(t, b, c, d) {
return t == 0 ? b : c * Math.pow(2, 10 * (t / d - 1)) + b;
},
easeOut(t, b, c, d) {
return t == d ? b + c : c * (-Math.pow(2, -10 * t / d) + 1) + b;
},
easeInOut(t, b, c, d) {
if (t == 0) return b;
if (t == d) return b + c;
if ((t /= d / 2) < 1)
return c / 2 * Math.pow(2, 10 * (t - 1)) + b;
return c / 2 * (-Math.pow(2, -10 * --t) + 2) + b;
}
});
class hfTween extends EventTarget {
static ET_UPDATE = 'update';
static ET_END = 'end';
constructor(current = 0, duration = 36, ease = null) {
super();
this.#running = false;
this.#begin = current;
this.#end = current;
this.#current = current;
this.#time = 0;
this.#duration = duration;
const fx = ease ?? hfEaseBack.easeInOut;
this.#ease = fx.bind(hfEaseBack);
Object.seal(this);
}
#running = false;
get Running() {
return this.#running;
}
#begin = 0.0;
get Begin() {
return this.#begin;
}
#end = 0.0;
get End() {
return this.#end;
}
#current = 0.0;
get Current() {
return this.#current;
}
#time = 0;
get Time() {
return this.#time;
}
#duration = 0;
get Duration() {
return this.#duration;
}
#ease = 0;
get Ease() {
return this.#ease;
}
#fid = -1;
#ClearFrame = () => {
if (this.#fid === -1) return;
cancelAnimationFrame(this.#fid);
this.#fid = -1;
}
#LoopFrame = (t) => {
if (this.#running === false) return;
if (this.#time < this.#duration) {
++this.#time;
this.#current = this.#ease(this.#time, this.#begin, this.#end, this.#duration);
this.dispatchEvent(new Event(hfTween.ET_UPDATE));
if (this.#time >= this.#duration) {
this.dispatchEvent(new Event(hfTween.ET_END));
this.Stop();
}
}
this.#fid = requestAnimationFrame(this.#LoopFrame);
}
Stop() {
if (this.#running === true) {
this.#ClearFrame();
this.#running = false;
}
}
FromTo(begin, change) {
if (this.#running === true)
this.Stop();
this.#time = 0;
this.#begin = begin;
this.#end = change - begin;
this.#current = begin;
this.#running = true;
this.#fid = requestAnimationFrame(this.#LoopFrame);
}
To(change) {
this.FromTo(this.#current, change);
}
}
class hfWeich extends EventTarget {
static ET_UPDATE = 'update';
static ET_END = 'end';
constructor(now, speed = 0.3) {
super();
this.#running = false;
this.#end = now;
this.#now = now;
this.#speed = speed;
Object.seal(this);
}
#running = false;
get Running() {
return this.#running;
}
#end = 0.0;
get End() {
return this.#end;
}
#now = 0.0;
get Now() {
return this.#now;
}
#speed = 0.0;
get Speed() {
return this.#speed;
}
#fid = -1;
#ClearFrame = () => {
if (this.#fid === -1) return;
cancelAnimationFrame(this.#fid);
this.#fid = -1;
}
#LoopFrame = (t) => {
if (this.#running === false) return;
const dst = this.#end - this.#now;
if (Math.abs(dst) < 1) {
this.#now = this.#end;
this.dispatchEvent(new Event(hfWeich.ET_END));
this.Stop();
}
else {
this.#now = this.#now + (dst * this.#speed);
this.dispatchEvent(new Event(hfWeich.ET_UPDATE));
}
this.#fid = requestAnimationFrame(this.#LoopFrame);
}
Stop() {
if (this.#running === true) {
this.#ClearFrame();
this.#running = false;
}
}
FromTo(end, now, speed = NaN) {
if (this.#running === true)
this.Stop();
this.#end = end;
this.#now = now;
if (isNaN(speed) === false)
this.#speed = speed;
this.#running = true;
this.#fid = requestAnimationFrame(this.#LoopFrame);
}
To(end, speed = NaN) {
this.FromTo(end, this.#now, speed);
}
}
export { fn_applyRectToElement, fn_checkNumber, fn_containsRect, fn_getHeight, fn_getLeft, fn_getRect, fn_getStyles, fn_getTop, fn_getWidth, fn_setHeight, fn_setLeft, fn_setTop, fn_setWidth, fn_updateRect, hfCountTask, hfEaseBack, hfEaseBounce, hfEaseCircular, hfEaseElastic, hfEaseExponential, hfEventTypes, hfHScroll, hfTween, hfVScroll, hfViewBox, hfWeich, hfarr, hfdtime, hfnum, hfstr };
