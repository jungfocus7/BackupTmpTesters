import { hfEventTypes } from "./hfjs/hfEventTypes.js";
import { fn_getRect, fn_getWidth, fn_getHeight } from "./hfjs/hfStyleFunctions.js";
import { hfViewBox } from "./hfjs/hfViewBox.js";
import { hfHScroll } from "./hfjs/hfHScroll.js";
import { hfVScroll } from "./hfjs/hfVScroll.js";



const _elViewBox = document.getElementById('viewBox');
const _elBody = document.getElementById('body');
// console.log(_elViewBox, _elBody);

const rctViewport = fn_getRect(_elViewBox);
const rctBody = fn_getRect(_elBody);
// console.log(rctViewport, rctBody);
const fn_viewBox_cbf = (cbt = '') => {
    if (cbt === hfEventTypes.Scroll) {
        const prx = _viewBox.fn_getScrollPositionRatioX();
        const pry = _viewBox.fn_getScrollPositionRatioY();
        _hscr.fn_setScrollPositionRatio(prx);
        _vscr.fn_setScrollPositionRatio(pry);
    }
    else if (cbt === 'normal') {
        _hscr.fn_setScrollSizeRatio(1 - _viewBox.fn_getScrollSizeRatioX());
        _vscr.fn_setScrollSizeRatio(1 - _viewBox.fn_getScrollSizeRatioY());
    }
};
const _viewBox = new hfViewBox(rctViewport, rctBody, fn_viewBox_cbf);
// console.log(_viewBox.fn_getScrollSizeRatioX(), _viewBox.fn_getScrollSizeRatioY());
_viewBox.fn_applyDragMove(_elViewBox, _elBody);


const _hscr = new hfHScroll('hscr');
_hscr.addEventListener(hfEventTypes.Scroll, (e) => {
    const prx = _hscr.fn_getScrollPositionRatio();
    // console.log(prx);
    _viewBox.fn_setScrollPositionRatioX(prx);

    // _viewBox.fn_applyRectToElement(_elViewBox, hfViewBox.RN_VIEW_BOX);
    _viewBox.fn_applyRectToElement(_elBody, hfViewBox.RN_BODY);
});


const _vscr = new hfVScroll('vscr');
_vscr.addEventListener(hfEventTypes.Scroll, (e) => {
    const pry = _vscr.fn_getScrollPositionRatio();
    // console.log(prx);
    _viewBox.fn_setScrollPositionRatioY(pry);

    // _viewBox.fn_applyRectToElement(_elViewBox, hfViewBox.RN_VIEW_BOX);
    _viewBox.fn_applyRectToElement(_elBody, hfViewBox.RN_BODY);
});


const fn_resize = (e) => {
    if (e !== null) {
        const vbw = fn_getWidth(_elViewBox);
        const vbh = fn_getHeight(_elViewBox);
        _viewBox.fn_setViewWidth(vbw);
        _viewBox.fn_setViewHeight(vbh);

        const bdw = fn_getWidth(_elBody);
        const bdh = fn_getHeight(_elBody);
        _viewBox.fn_setBodyWidth(bdw);
        _viewBox.fn_setBodyHeight(bdh);

        // _viewBox.fn_applyRectToElement(_elViewBox, hfViewBox.RN_VIEW_BOX);
        _viewBox.fn_applyRectToElement(_elBody, hfViewBox.RN_BODY);
    }
    else {
        _viewBox.fn_calcRctBody();

        // _viewBox.fn_applyRectToElement(_elViewBox, hfViewBox.RN_VIEW_BOX);
        _viewBox.fn_applyRectToElement(_elBody, hfViewBox.RN_BODY);
    }

    const srx = 1 - _viewBox.fn_getScrollSizeRatioX();
    const sry = 1 - _viewBox.fn_getScrollSizeRatioY();
    // console.log(srx, sry);
    _hscr.fn_setScrollSizeRatio(srx);
    _vscr.fn_setScrollSizeRatio(sry);
};
window.addEventListener(hfEventTypes.Resize, fn_resize);
fn_resize(null);




// setTimeout(() => {
//     console.log('[#출발]');
//     window.addEventListener('keydown', (/** @type {KeyboardEvent} */e) => {
//         if ((e.ctrlKey === true) && (e.code === 'KeyQ')) {
//             const bd = document.getElementById('body');
//             bd.style.setProperty('pointer-events', 'none');
//             console.log('pointer-events: none;');
//         }
//         else
//         if ((e.ctrlKey === true) && (e.code === 'KeyW')) {
//             const bd = document.getElementById('body');
//             bd.style.setProperty('pointer-events', 'auto');
//             console.log('pointer-events: auto;');
//         }
//         else
//         if ((e.ctrlKey === true) && (e.code === 'KeyZ')) {
//             // const bd = document.getElementById('body');
//             // const x1 = bd.children[0];
//             // console.log(x1);
//             // bd.removeChild(x1);
//             const bd = document.getElementById('body');
//             bd.insertAdjacentHTML('afterbegin', `
// <iframe style="position: absolute; display: block; left: 0px; top: 0px;
//     width: 100%; height: 100%;
//     box-sizing: border-box; border: 40px solid whitesmoke;"
//     src="https://chzzk.naver.com/live/b8263cd74372864eacb2d5bd16551882"></iframe>
//             `.trim());
//         }
//         // console.log(e);
//     });


// }, 3000);






































// setInterval(() => { fn_resize(); }, 1000);
// _viewBox.fn_calcRctBody();

// setTimeout(() => {
//     fn_resize();
//     // _viewBox.fn_calcRctBody();
// }, 300);




// const _rvo = Object.seal({x: 0, y: 0});
// const fn_loopFrame = () => {
//     // console.log(typeof arguments[0], arguments[0]);
//     // requestAnimationFrame(fn_loopFrame);

//     const sts = _elBody.style;
//     _rvo.x += 0.5;
//     _rvo.y += 2.0;
//     // console.log(_rvo.x);
//     sts.setProperty('transform', `rotateX(${_rvo.x}deg) rotateY(${_rvo.y}deg)`);
//     requestAnimationFrame(fn_loopFrame);

//     console.log(fn_getRect(_elBody));
// };
// requestAnimationFrame(fn_loopFrame);








// const _mySpan = document.getElementById('mySpan');
// _mySpan.style = `
// position: absolute; background-color: brown;
// color: whitesmoke; font-size: 12px;
// width: 100px; height: 30px;
// left: 100px; top: 20px;
// `.trim();
// window.addEventListener('mousemove', (e) => {
//     const sts = _mySpan.style;
//     const tx = e.clientX;
//     const ty = e.clientY;
//     sts.setProperty('left', `${tx - 100}px`);
//     sts.setProperty('top', `${ty - 30}px`);

//     // console.log(_mySpan.innerText);
//     _mySpan.innerText = `X: ${tx}, Y: ${ty}`;

//     // const rr = getComputedStyle(_mySpan);
//     // console.log(rr.display, rr.getPropertyValue('display'));
// });