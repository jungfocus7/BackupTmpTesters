//#region '~~~~~~~~~~ 00) 공통 코드'
/**
 * 이벤트 타입들
 */
const hfEventTypes = Object.freeze({
    MouseMove: 'mousemove',
    Blur: 'blur',
    MouseUp: 'mouseup',
    MouseDown: 'mousedown',
    Resize: 'resize',
    Scroll: 'scroll',
    Click: 'click',
    Resize: 'resize'
});


/**
 * Element 스타일 객체 반환
 * @param {CSSStyleDeclaration | HTMLElement} to
 * @param {Boolean} bw writeable
 * @returns CSSStyleDeclaration
 */
const fn_getStyles = (to, bw=false) => {
    if (to instanceof CSSStyleDeclaration)
        return to;
    else if (to instanceof HTMLElement) {
        if (bw === true)
            return to.style;
        else
            return getComputedStyle(to);
    }
    else return null;
};

/**
 * 넘버인지 확인후 반환
 * @param {Number} tv
 * @param {Number} dv
 * @returns Number
 */
const fn_checkNumber = (tv, dv=0) => {
    if (typeof tv === 'number') {
        if (isNaN(tv))
            return dv;
        else
            return tv;
    }
    else return dv;
};


/**
 * Element left(Number) 가져오기
 * @param {CSSStyleDeclaration | HTMLElement} to
 * @returns Number
 */
const fn_getLeft = (to) => {
    const sts = fn_getStyles(to);
    if (sts !== null) {
        let tv = sts.getPropertyValue('left');
        return fn_checkNumber(parseFloat(tv));
    }
};

/**
 * Element left(Number) 설정하기
 * @param {CSSStyleDeclaration | HTMLElement} to
 * @param {Number} tv
 */
const fn_setLeft = (to, tv) => {
    const sts = fn_getStyles(to, true);
    if (sts !== null) {
        tv = fn_checkNumber(tv);
        sts.setProperty('left', `${tv}px`);
    }
};


/**
 * Element top(Number) 반환
 * @param {CSSStyleDeclaration | HTMLElement} to
 * @returns Number
 */
const fn_getTop = (to) => {
    const sts = fn_getStyles(to);
    if (sts !== null) {
        let tv = sts.getPropertyValue('top');
        return fn_checkNumber(parseFloat(tv));
    }
};

/**
 * Element top(Number) 설정
 * @param {CSSStyleDeclaration | HTMLElement} to
 * @param {Number} tv
 */
const fn_setTop = (to, tv) => {
    const sts = fn_getStyles(to, true);
    if (sts !== null) {
        tv = fn_checkNumber(tv);
        sts.setProperty('top', `${tv}px`);
    }
};


/**
 * Element width(Number) 반환
 * @param {CSSStyleDeclaration | HTMLElement} to
 * @returns Number
 */
const fn_getWidth = (to) => {
    const sts = fn_getStyles(to);
    if (sts !== null) {
        let tv = sts.getPropertyValue('width');
        return fn_checkNumber(parseFloat(tv));
    }
};

/**
 * Element width(Number) 설정
 * @param {CSSStyleDeclaration | HTMLElement} to
 * @param {Number} tv
 */
const fn_setWidth = (to, tv) => {
    const sts = fn_getStyles(to, true);
    if (sts !== null) {
        tv = fn_checkNumber(tv);
        sts.setProperty('width', `${tv}px`);
    }
};


/**
 * Element height(Number) 반환
 * @param {CSSStyleDeclaration | HTMLElement} to
 * @returns Number
 */
const fn_getHeight = (to) => {
    const sts = fn_getStyles(to);
    if (sts !== null) {
        let tv = sts.getPropertyValue('height');
        return fn_checkNumber(parseFloat(tv));
    }
};

/**
 * Element height(Number) 설정
 * @param {CSSStyleDeclaration | HTMLElement} to
 * @param {Number} tv
 */
const fn_setHeight = (to, tv) => {
    const sts = fn_getStyles(to, true);
    if (sts !== null) {
        tv = fn_checkNumber(tv);
        sts.setProperty('height', `${tv}px`);
    }
};


/**
 * Element Rect 반환
 * @param {CSSStyleDeclaration | HTMLElement} to
 * @returns DOMRect
 */
const fn_getRect = (to) => {
    const sts = fn_getStyles(to);
    if (sts !== null) {
        let tx = fn_getLeft(sts);
        let ty = fn_getTop(sts);
        let tw = fn_getWidth(sts);
        let th = fn_getHeight(sts);
        let rct = new DOMRect(tx, ty, tw, th);
        return rct;
    }
    else null;
};


/**
 * Element에 Rect 적용하기
 * @param {CSSStyleDeclaration | HTMLElement} to
 * @param {DOMRect} rct
 */
const fn_applyRectToElement = (to, rct) => {
    const sts = fn_getStyles(to, true);
    if ((sts !== null) && (rct instanceof DOMRect)) {
        fn_setLeft(sts, rct.left);
        fn_setTop(sts, rct.top);
        fn_setWidth(sts, rct.width);
        fn_setHeight(sts, rct.height);
    }
};
//#endregion


// //#region '~~~~~~~~~~ 01) hfViewInfo'
// const hfViewInfo = Object.freeze(class {
//     //////////////////////////////////////////////////////////////////////
//     /**
//      * 생성자
//      * @param {DOMRect} rctViewport Viewport영역
//      * @param {DOMRect} rctBody Body영역
//      */
//     constructor(rctViewport, rctBody) {
//         this.#rctViewport = rctViewport;
//         this.#rctBody = rctBody;
//         this.#rctBody.x = this.#rctViewport.left;
//         this.#rctBody.y = this.#rctViewport.top;
//         // console.log(this.#rctViewport, this.#rctBody);

//         this.#fn_updateScrollWidth();
//         this.#fn_updateScrollHeight();
//     }

//     /** @type {DOMRect} Viewport영역 */
//     #rctViewport = null;

//     /** @type {DOMRect} Body영역 */
//     #rctBody = null;


//     //////////////////////////////////////////////////////////////////////
//     /** @type {number} 스크롤 넓이 */
//     #scrollWidth = 0.0;

//     /**
//      * 스크롤 넓이 업데이트
//      * @returns {void}
//      */
//     #fn_updateScrollWidth() {
//         let scv = this.#rctBody.width - this.#rctViewport.width;
//         if (scv < 0.0) scv = 0.0;
//         this.#scrollWidth = scv;
//     };

//     /**
//      * 스크롤 넓이 가져오기
//      * @param {boolean} bu 업데이트 여부
//      * @returns {number}
//      */
//     fn_getScrollWidth(bu=false) {
//         if (bu === true) this.#fn_updateScrollWidth();
//         return this.#scrollWidth;
//     }


//     //////////////////////////////////////////////////////////////////////
//     /** @type {number} 스크롤 Y축 */
//     #scrollHeight = 0.0;

//     /**
//      * 스크롤 높이 업데이트
//      * @returns {void}
//      */
//     #fn_updateScrollHeight() {
//         let scv = this.#rctBody.height - this.#rctViewport.height;
//         if (scv < 0.0) scv = 0.0;
//         this.#scrollHeight = scv;
//     }

//     /**
//      * 스크롤 높이 가져오기
//      * @param {boolean} bu 업데이트 여부
//      * @returns {number}
//      */
//     fn_getScrollHeight(bu=false) {
//         if (bu === true) this.#fn_updateScrollHeight();
//         return this.#scrollHeight;
//     }


//     //////////////////////////////////////////////////////////////////////
//     /** @type {number} 스크롤 X축 */
//     #scrollX = 0.0;

//     /**
//      * 스크롤 X축 업데이트
//      * @param {boolean} br 기본계산(false는 비율계산)
//      */
//     #fn_updateScrollX(br=true) {
//         let sp = 0;
//         if (br === true) {
//             sp = this.#rctViewport.left - this.#rctBody.left;
//             if (sp < 0.0) sp = 0.0;
//             this.#scrollX = sp;
//         }
//         else {
//             const scv = this.fn_getScrollWidth();
//             const sr = this.fn_getScrollRatioX();
//             sp = scv * sr;
//             this.#scrollX = sp;
//         }
//     }

//     /**
//      * 스크롤 X축 가져오기
//      * @param {boolean} bu 업데이트 여부
//      * @returns {number}
//      */
//     fn_getScrollX(bu=false) {
//         if (bu === true) this.#fn_updateScrollX();
//         return this.#scrollX;
//     }

//     /**
//      * Body영역 X축 계산하기
//      * @returns {void}
//      */
//     #fn_calcRctBodyX() {
//         const scv = this.fn_getScrollWidth();
//         const gjv = this.#rctViewport.left;
//         let rp = 0;
//         if (scv > 0.0) {
//             const min = gjv - scv;
//             const max = gjv;
//             rp = gjv - this.#scrollX;
//             if (rp < min) rp = min;
//             else if (rp > max) rp = max;
//             this.#rctBody.x = rp;
//         }
//         else {
//             rp = (this.#rctViewport.right - (this.#rctViewport.width / 2)) -
//                 (this.#rctBody.width / 2);
//             this.#rctBody.x = rp;
//         }
//     }

//     /**
//      * 스크롤 X축 설정하기
//      * @param {number} val
//      * @returns
//      */
//     fn_setScrollX(val) {
//         const min = 0.0;
//         const max = this.fn_getScrollWidth();
//         if (min === max) return;
//         let sp = val;
//         if (sp !== this.#scrollX) {
//             if (sp < min) sp = min;
//             else if (sp > max) sp = max;
//             this.#scrollX = sp;
//             this.#fn_calcRctBodyX();
//             this.#fn_updateScrollRatioX();
//         }
//     }


//     //////////////////////////////////////////////////////////////////////
//     /** @type {number} 스크롤 Y축 */
//     #scrollY = 0.0;

//     /**
//      * 스크롤 Y축 업데이트
//      * @param {boolean} br 기본계산(false는 비율계산)
//      */
//     #fn_updateScrollY(br=true) {
//         let sp = 0;
//         if (br === true) {
//             sp = this.#rctViewport.top - this.#rctBody.top;
//             if (sp < 0.0) sp = 0.0;
//             this.#scrollY = sp;
//         }
//         else {
//             const scv = this.fn_getScrollHeight();
//             const sr = this.fn_getScrollRatioY();
//             sp = scv * sr;
//             this.scrollY = sp;
//         }
//     }

//     /**
//      * 스크롤 Y축 가져오기
//      * @param {boolean} bu 업데이트 여부
//      * @returns {number}
//      */
//     fn_getScrollY(bu=false) {
//         if (bu === true) this.#fn_updateScrollY();
//         return this.#scrollY;
//     }

//     /**
//      * Body영역 Y축 계산하기
//      * @returns {void}
//      */
//     #fn_calcRctBodyY() {
//         const scv = this.fn_getScrollHeight();
//         const gjv = this.#rctViewport.top;
//         let rp = 0;
//         if (scv > 0.0) {
//             const min = gjv - scv;
//             const max = gjv;
//             rp = gjv - this.#scrollY;
//             if (rp < min) rp = min;
//             else if (rp > max) rp = max;
//             this.#rctBody.y = rp;
//         }
//         else {
//             rp = (this.#rctViewport.bottom - (this.#rctViewport.height / 2)) -
//                 (this.#rctBody.height / 2);
//             this.#rctBody.y = rp;
//         }
//     }

//     /**
//      * 스크롤 Y축 설정하기
//      * @param {number} val
//      * @returns
//      */
//     fn_setScrollY(val) {
//         const min = 0.0;
//         const max = this.fn_getScrollHeight();
//         if (min === max) return;
//         let sp = val;
//         if (sp !== this.#scrollY) {
//             if (sp < min) sp = min;
//             else if (sp > max) sp = max;
//             this.#scrollY = sp;
//             this.#fn_calcRctBodyY();
//             this.#fn_updateScrollRatioY();
//         }
//     }


//     //////////////////////////////////////////////////////////////////////
//     /** @type {number} 스크롤 X축 비율 */
//     #scrollRatioX = 0.0;

//     /**
//      * 스크롤 X축 비율 업데이트
//      * @returns {void}
//      */
//     #fn_updateScrollRatioX() {
//         const scv = this.fn_getScrollWidth(true);
//         if (scv > 0.0) {
//             let sp = this.#rctViewport.left - this.#rctBody.left;
//             if (sp < 0.0) sp = 0.0;
//             let sr = sp / scv;
//             if (sr < 0.0) sr = 0.0;
//             else if (sr > 1.0) sr = 1.0;
//             this.#scrollRatioX = sr;
//         }
//         else {
//             this.#scrollRatioX = 0.0;
//         }
//     }

//     /**
//      * 스크롤 X축 비율 가져오기
//      * @param {boolean} bu 업데이트 여부
//      * @returns {number}
//      */
//     fn_getScrollRatioX(bu=false) {
//         if (bu === true) this.#fn_updateScrollRatioX();
//         return this.#scrollRatioX;
//     }

//     /**
//      * 스크롤 X축 비율 설정하기
//      * @param {number} val
//      */
//     fn_setScrollRatioX(val) {
//         let sr = val;
//         if (sr !== this.#scrollRatioX) {
//             if (sr < 0.0) sr = 0.0;
//             else if (sr > 1.0) sr = 1.0;
//             this.#scrollRatioX = sr;
//             this.#fn_updateScrollX(false);
//         }
//     }


//     //////////////////////////////////////////////////////////////////////
//     /** @type {number} 스크롤 Y축 비율 */
//     #scrollRatioY = 0.0;

//     /**
//      * 스크롤 Y축 비율 업데이트
//      * @returns {void}
//      */
//     #fn_updateScrollRatioY() {
//         const scv = this.fn_getScrollHeight(true);
//         if (scv > 0.0) {
//             let sp = this.#rctViewport.top - this.#rctBody.top;
//             if (sp < 0.0) sp = 0.0;
//             let sr = sp / scv;
//             if (sr < 0.0) sr = 0.0;
//             else if (sr > 1.0) sr = 1.0;
//             this.#scrollRatioY = sr;
//         }
//         else {
//             this.#scrollRatioY = 0.0;
//         }
//     }

//     /**
//      * 스크롤 Y축 비율 가져오기
//      * @param {boolean} bu 업데이트 여부
//      * @returns {number}
//      */
//     fn_getScrollRatioY(bu=false) {
//         if (bu === true) this.#fn_updateScrollRatioY();
//         return this.#scrollRatioY;
//     }

//     /**
//      * 스크롤 X축 비율 설정하기
//      * @param {number} val
//      */
//     fn_setScrollRatioY(val) {
//         let sr = val;
//         if (sr !== this.#scrollRatioY) {
//             if (sr < 0.0) sr = 0.0;
//             else if (sr > 1.0) sr = 1.0;
//             this.#scrollRatioY = sr;
//             this.#fn_updateScrollY(false);
//         }
//     }


//     //////////////////////////////////////////////////////////////////////
//     static RN_VIEW_BOX = 'rctViewBox';
//     static RN_BODY = 'rctBody';

//     /**
//      * 엘리먼트에 변경된 Rect적용하기
//      * @param {string} rn RectName
//      * @param {HTMLElement} el Element
//      */
//     fn_applyRectToElement(rn, el) {
//         let rct = null;
//         if (rn === hfViewInfo.RN_VIEW_BOX) {
//             rct = this.#rctViewport;
//         }
//         else if (rn === hfViewInfo.RN_BODY) {
//             rct = this.#rctBody;
//         }

//         if (rct !== null) {
//             el.width = rct.width;
//             el.height = rct.height;
//             el.x = rct.left;
//             el.y = rct.top;
//         }
//     }


//     // //////////////////////////////////////////////////////////////////////
//     static #MIN_W = 10.0;

//     /**
//      * Viewport영역 넓이 가져오기
//      * @returns {number}
//      */
//     fn_getViewWidth() {
//         return this.#rctViewport.width;
//     }

//     /**
//      * Viewport영역 넓이 설정하기
//      * @param {number} val
//      */
//     fn_setViewWidth(val) {
//         if (val < hfViewInfo.#MIN_W) val = hfViewInfo.#MIN_W;
//         this.#rctViewport.width = val;
//         this.#fn_updateScrollWidth();
//         this.#fn_updateScrollX(false);
//         this.#fn_calcRctBodyX();
//     }

//     /**
//      * Body영역 넓이 가져오기
//      * @returns {number}
//      */
//     fn_getBodyWidth() {
//         return this.#rctBody.width;
//     }

//     /**
//      * Body영역 넓이 설정하기
//      * @param {number} val
//      */
//     fn_setBodyWidth(val) {
//         if (val < hfViewInfo.#MIN_W) val = hfViewInfo.#MIN_W;
//         this.#rctBody.width = val;
//         this.#fn_updateScrollWidth();
//         this.#fn_updateScrollX(false);
//         this.#fn_calcRctBodyX();
//     }


//     //////////////////////////////////////////////////////////////////////
//     static #MIN_H = 10.0;

//     /**
//      * Viewport영역 높이 가져오기
//      * @returns {number}
//      */
//     fn_getViewHeight() {
//         return this.#rctViewport.height;
//     }

//     /**
//      * Viewport영역 높이 설정하기
//      * @param {number} val
//      */
//     fn_setViewHeight(val) {
//         if (val < hfViewInfo.#MIN_H) val = hfViewInfo.#MIN_H;
//         this.#rctViewport.height = val;
//         this.#fn_updateScrollHeight();
//         this.#fn_updateScrollY(false);
//         this.#fn_calcRctBodyY();
//     }

//     /**
//      * Body영역 높이 가져오기
//      * @returns {number}
//      */
//     fn_getBodyHeight() {
//         return this.#rctBody.height;
//     }

//     /**
//      * Body영역 높이 설정하기
//      * @param {number} val
//      */
//     fn_setBodyHeight(val) {
//         if (val < hfViewInfo.#MIN_H) val = hfViewInfo.#MIN_H;
//         this.#rctBody.height = val;
//         this.#fn_updateScrollHeight();
//         this.#fn_updateScrollY(false);
//         this.#fn_calcRctBodyY();
//     }

// });
// //#endregion


// //#region '~~~~~~~~~~ 02) hfScrollController'
// const hfScrollController = Object.freeze(class extends EventTarget {
//     /**
//      * 생성자
//      * @param {String} dragTrackId
//      * @param {String} thumbId
//      */
//     constructor(dragTrackId='scrcDragTrack', thumbId='scrcThumb') {
//         super();

//         this.#elDragTrack = document.getElementById(dragTrackId);
//         this.#elThumb = document.getElementById(thumbId);

//         // this.#rctDragTrack.width = fn_getWidth(this.#elDragTrack);
//         // this.#rctDragTrack.height = fn_getHeight(this.#elDragTrack);
//         // this.#rctDragTrack.x = fn_getLeft(this.#elDragTrack);
//         // this.#rctDragTrack.y = fn_getTop(this.#elDragTrack);
//         this.#rctDragTrack = fn_getRect(this.#elDragTrack);

//         // this.#rctScrollArea.width = 0.0;
//         // this.#rctScrollArea.height = 0.0;
//         this.#rctScrollArea = new DOMRect(0.0, 0.0, 0.0, 0.0);

//         // this.#rctThumb.width = this.#rctDragTrack.width;
//         // this.#rctThumb.height = this.#rctDragTrack.height;
//         this.#rctThumb = new DOMRect(0.0, 0.0
//             , this.#rctDragTrack.width, this.#rctDragTrack.height);

//         this.#elDragTrack.addEventListener(hfEventTypes.MouseDown, this.#fn_mouseDown);
//     };

//     /** @type {HTMLDivElement} */
//     #elDragTrack = null;

//     /** @type {HTMLDivElement} */
//     #elThumb = null;


//     // #rctMargin = new DOMRect(4, 4, 4, 4);
//     /** @type {DOMRect} */
//     #rctDragTrack = null;

//     /** @type {DOMRect} */
//     #rctScrollArea = null;

//     /** @type {DOMRect} */
//     #rctThumb = null;


//     /** @type {number} */
//     #ssrx = 1.0;

//     /**
//      * 스크롤 사이즈 X비율
//      * @returns {number}
//      */
//     fn_getScrollSizeRatioX() {
//         return this.#ssrx;
//     }

//     /** @type {number} */
//     #ssry = 1.0;

//     /**
//      * 스크롤 사이즈 Y비율
//      * @returns {number}
//      */
//     fn_getScrollSizeRatioY() {
//         return this.#ssry;
//     }

//     /** @type {number} */
//     #prx = 0.0;

//     /** @type {number} */
//     #pry = 0.0;

//     /**
//      * 스크롤 사이즈 Y비율
//      * @returns {number}
//      */
//     fn_setScrollRatioY(val) {
//         if (val === this.#pry) return;
//         if (val < 0.0) val = 0.0;
//         else if (val > 1.0) val = 1.0;
//         this.#pry = val;
//         this.#fn_updateRects();
//         fn_applyRectToElement(this.#elThumb, this.#rctThumb);
//     }


//     // /** @type {boolean} */
//     // #enabled = true;

//     /** @type {boolean} */
//     #bmd = false;


//     /**
//      * 업데이트 Rects
//      */
//     #fn_updateRects() {
//         let w1 = this.#rctDragTrack.width * (1 - this.#ssrx);
//         let x1 = (this.#rctDragTrack.width / 2) - (w1 / 2);
//         // console.log(w1, x1);
//         this.#rctScrollArea.width = w1;
//         this.#rctScrollArea.x = x1;
//         // console.log(this.#rctScrollArea);

//         let w2 = this.#rctDragTrack.width * this.#ssrx;
//         let x2 = this.#rctScrollArea.width * this.#prx;
//         // console.log(w2, x2);
//         this.#rctThumb.width = w2;
//         this.#rctThumb.x = x2;
//         // console.log(this.#rctThumb);


//         let h1 = this.#rctDragTrack.height * (1 - this.#ssry);
//         let y1 = (this.#rctDragTrack.height / 2) - (h1 / 2);
//         // console.log(h1, y1);
//         this.#rctScrollArea.height = h1;
//         this.#rctScrollArea.y = y1;
//         // console.log(this.#rctScrollArea);

//         let h2 = this.#rctDragTrack.height * this.#ssry;
//         let y2 = this.#rctScrollArea.height * this.#pry;
//         // console.log(h2, y2);
//         this.#rctThumb.height = h2;
//         this.#rctThumb.y = y2;
//         // console.log(this.#rctThumb);

//         fn_applyRectToElement(this.#elThumb, this.#rctThumb);
//     };


//     /**
//      * 스크롤 사이즈 비율 설정
//      * @param {number} rx RatioX
//      * @param {number} ry RatioY
//      * @param {Event} e
//      */
//     fn_setScrollSizeRatio(rx, ry, e) {
//         if (rx < 0.0) rx = 0.0;
//         else if (rx > 1.0) rx = 1.0;

//         if (ry < 0.0) ry = 0.0;
//         else if (ry > 1.0) ry = 1.0;

//         if (rx !== this.#ssrx)
//             this.#ssrx = rx;
//         // console.log(this.#ssrx);
//         if (ry !== this.#ssry)
//             this.#ssry = ry;
//         // console.log(this.#ssry);

//         this.#fn_updateRects();
//     };


//     /**
//      * MouseMove 핸들러
//      * @param {Event} e
//      */
//     #fn_mouseMove = (e) => {
//         let tx = (e.clientX - this.#rctDragTrack.left) - this.#rctScrollArea.left;
//         let aw = this.#rctScrollArea.width;
//         if (tx < 0.0) tx = 0.0;
//         else if (tx > aw) tx = aw;
//         if (aw <= 0.0) this.#prx = 0.0;
//         else this.#prx = tx / aw;
//         // console.log(tx, aw, this.#prx);

//         this.#rctThumb.x = aw * this.#prx;
//         // console.log('this.#rctThumb.left:', this.#rctThumb.left);

//         let ty = (e.clientY - this.#rctDragTrack.top) - this.#rctScrollArea.top;
//         let ah = this.#rctScrollArea.height;
//         if (ty < 0.0) ty = 0.0;
//         else if (ty > ah) ty = ah;
//         if (ah <= 0.0) this.#pry = 0.0;
//         else this.#pry = ty / ah;
//         // console.log(ty, ah, this.#pry);

//         this.#rctThumb.y = ah * this.#pry;
//         // console.log('this.#rctThumb.top:', this.#rctThumb.top);

//         fn_applyRectToElement(this.#elThumb, this.#rctThumb);
//     };

//     /**
//      * MouseUp 핸들러
//      * @param {Event} e
//      */
//     #fn_mouseUp = (e) => {
//         if (this.#bmd === false) return;

//         window.removeEventListener(hfEventTypes.MouseMove, this.#fn_mouseMove);
//         window.removeEventListener(hfEventTypes.MouseUp, this.#fn_mouseUp);
//         window.removeEventListener(hfEventTypes.Blur, this.#fn_mouseUp);
//         this.#bmd = false;
//     };

//     /**
//      * MouseDown
//      * @param {Event} e
//      */
//     #fn_mouseDown = (e) => {
//         if (e.button === 0) {
//             if (this.#bmd === true) return;

//             window.addEventListener(hfEventTypes.MouseMove, this.#fn_mouseMove);
//             window.addEventListener(hfEventTypes.MouseUp, this.#fn_mouseUp);
//             window.addEventListener(hfEventTypes.Blur, this.#fn_mouseUp);
//             this.#bmd = true;

//             this.#fn_mouseMove(e);
//         }
//     };

// });
// //#endregion


// //#region '~~~~~~~~~~ 03) hfVScrollBar'
// const hfVScrollBar = Object.freeze(class extends EventTarget {
//     /**
//      * 생성자
//      * @param {string} id
//      */
//     constructor(id='vscrb') {
//         super();

//         this.#elTargetCont = document.getElementById(id);
//         this.#elTargetCont.setAttribute('style', `
// background-color: #000000;
// width: 30px; height: 300px;
// position: absolute; display: inline-block;
// left: 300px; top: 50px;
// overflow-x: hidden;
// overflow-y: hidden;
// font-size: 0px;
// cursor: grab;
//         `.trim());
//         this.#elTargetCont.innerHTML = `
// <div style="background-color: #4f4f4f;
//     position: relative;
//     width: 100%; height: 100%;
//     left: 0px; top: 0px;
//     pointer-events: none;">
// </div>
//         `.trim();

//         // console.log(this.#elTarget.children)
//         // console.log(this.#elTarget.childNodes)

//         this.#elThumb = this.#elTargetCont.children[0];
//         // console.log(this.#elThumb);

//         this.#rctDragTrack = fn_getRect(this.#elTargetCont);
//         this.#rctThumb = fn_getRect(this.#elThumb);

//         this.#rctScrollArea = new DOMRect(0.0, 0.0, 0.0, 0.0);


//         this.#elTargetCont.addEventListener(hfEventTypes.MouseDown, this.#fn_mouseDown);
//     };

//     /** @type {HTMLDivElement} */
//     #elTargetCont = null;

//     /** @type {HTMLDivElement} */
//     #elThumb = null;


//     /** @type {DOMRect} */
//     #rctDragTrack = null;

//     /** @type {DOMRect} */
//     #rctThumb = null;

//     /** @type {DOMRect} */
//     #rctScrollArea = null;


//     //////////////////////////////////////////////////////////////////////
//     /** @type {number} */
//     #ssry = 1.0;

//     /**
//      * 스크롤 사이즈 비율
//      * @returns {number}
//      */
//     fn_getScrollSizeRatio() {
//         return this.#ssry;
//     };

//     /**
//      * 스크롤 사이즈 비율 설정
//      * @param {number} ry RatioY
//      * @param {Event} e
//      */
//     fn_setScrollSizeRatio(ry, e) {
//         if (ry < 0.0) ry = 0.0;
//         else if (ry > 1.0) ry = 1.0;

//         if (ry !== this.#ssry)
//             this.#ssry = ry;
//         // console.log(this.#ssry);

//         this.#fn_updateRects();
//     };


//     /** @type {number} */
//     #pry = 0.0;

//     /**
//      * 스크롤 비율
//      * @returns {number}
//      */
//     fn_getScrollRatio() {
//         return this.#pry;
//     };

//     /**
//      * 스크롤 비율
//      * @returns {number}
//      */
//     fn_setScrollRatio(val) {
//         if (val !== this.#pry) {
//             if (val < 0.0) val = 0.0;
//             else if (val > 1.0) val = 1.0;
//             this.#pry = val;
//         }
//     };


//     /** @type {boolean} */
//     #bmd = false;

//     #mdy = NaN;


//     /**
//      * 업데이트 RECTs
//      */
//     #fn_updateRects() {
//         let h1 = this.#rctDragTrack.height * (1 - this.#ssry);
//         let y1 = (this.#rctDragTrack.height / 2) - (h1 / 2);
//         // console.log(h1, y1);
//         this.#rctScrollArea.height = h1;
//         this.#rctScrollArea.y = y1;
//         // console.log(this.#rctScrollArea);

//         let h2 = this.#rctDragTrack.height * this.#ssry;
//         let y2 = this.#rctScrollArea.height * this.#pry;
//         // console.log(h2, y2);
//         this.#rctThumb.height = h2;
//         this.#rctThumb.y = y2;
//         // console.log(this.#rctThumb);

//         fn_applyRectToElement(this.#elThumb, this.#rctThumb);
//     };


//     /**
//      * MouseUp 핸들러
//      * @param {Event} e
//      */
//     #fn_mouseUp = (e) => {
//         if (this.#bmd === false) return;

//         window.removeEventListener(hfEventTypes.MouseMove, this.#fn_mouseMove);
//         window.removeEventListener(hfEventTypes.MouseUp, this.#fn_mouseUp);
//         window.removeEventListener(hfEventTypes.Blur, this.#fn_mouseUp);
//         this.#bmd = false;
//     };


//     /**
//      * MouseMove 핸들러
//      * @param {Event} e
//      */
//     #fn_mouseMove = (e) => {
//         // let ty = (e.clientY - this.#rctDragTrack.top) - this.#rctScrollArea.top;
//         // let ah = this.#rctScrollArea.height;
//         // if (ty < 0.0) ty = 0.0;
//         // else if (ty > ah) ty = ah;
//         // if (ah <= 0.0) this.#pry = 0.0;
//         // else this.#pry = ty / ah;
//         // // console.log(ty, ah, this.#pry);

//         // this.#rctThumb.y = ah * this.#pry;
//         // // console.log('this.#rctThumb.top:', this.#rctThumb.top);

//         // fn_applyRectToElement(this.#elThumb, this.#rctThumb);

//         // this.dispatchEvent(new Event('scroll'));

//         // // console.log('>>>', this.#pry, this.#ssry);







//         //-------------------------------------------------------------
//         // console.log('>>> ', this.#rctThumb.height, this.#mdy);
//         // let txx = e.clientY+(this.#mdy+(this.#rctThumb.height/2));
//         // console.log(e.clientY);
//         // let txx = e.clientY/* + (this.#mdy / 2)*/;
//         // console.log(txx);
//         console.log(this.#rctDragTrack.top, this.#rctScrollArea.top);

//         // let ty = (txx - this.#rctDragTrack.top) - this.#rctScrollArea.top;
//         let ty = ((e.clientY-this.#mdy) - (this.#rctDragTrack.top+this.#mdy)) - (this.#rctScrollArea.top+this.#mdy);
//         // ty -= this.#mdy;
//         let ah = this.#rctScrollArea.height;
//         if (ty < 0.0) ty = 0.0;
//         else if (ty > ah) ty = ah;
//         if (ah <= 0.0) this.#pry = 0.0;
//         else this.#pry = ty / ah;
//         // console.log(ty, ah, this.#pry);

//         this.#rctThumb.y = (ah * this.#pry);
//         // console.log('무엇이 문제인가? ' + this.#mdy);
//         // console.log('this.#rctThumb.top:', this.#rctThumb.top);

//         fn_applyRectToElement(this.#elThumb, this.#rctThumb);

//         // this.dispatchEvent(new Event('scroll'));

//         // console.log('>>>', this.#pry, this.#ssry);
//     };

//     /**
//      * MouseDown
//      * @param {Event} e
//      */
//     #fn_mouseDown = (e) => {
//         // if (e.button === 0) {
//         //     if (this.#bmd === true) return;

//         //     window.addEventListener(hfEventTypes.MouseMove, this.#fn_mouseMove);
//         //     window.addEventListener(hfEventTypes.MouseUp, this.#fn_mouseUp);
//         //     window.addEventListener(hfEventTypes.Blur, this.#fn_mouseUp);
//         //     this.#bmd = true;

//         //     this.#fn_mouseMove(e);
//         // }



//         if (e.button === 0) {
//             //if (isNaN(this.#mdy)) {
//                 window.addEventListener(hfEventTypes.MouseMove, this.#fn_mouseMove);
//                 window.addEventListener(hfEventTypes.MouseUp, this.#fn_mouseUp);
//                 window.addEventListener(hfEventTypes.Blur, this.#fn_mouseUp);
//                 this.#bmd = true;
//                 // this.#mdy = e.offsetY;
//                 this.#mdy = this.#rctThumb.height - e.offsetY;
//                 // console.log(e.offsetY, e);
//                 // console.log(this.#mdy);
//                 // console.log(this.#rctThumb.height, e.offsetY
//                 //     , e.offsetY - this.#rctThumb.height);

//                 this.#fn_mouseMove(e);
//             //}
//         }
//     };
// });
// //#endregion


//#region '~~~~~~~~~~ 04) hfHScroller'
const hfHScroller = Object.freeze(class extends EventTarget {
    ////////////////////////////////////////////////////////////////////////////////////////////////////
    constructor(elId='hscr') {
        super();

        this.#elGround = document.getElementById(elId);
        this.#elGround.setAttribute('style', `
width: 200px; height: 30px;
background-color: #595959;
position: static; display: inline-block;
left: 100px; top: 100px;
overflow-x: hidden;
overflow-y: hidden;
font-size: 0px;
cursor: pointer;
        `.trim());
        this.#elGround.innerHTML = `
<div style="background-color: #748B96;
    position: relative;
    width: 100%; height: 100%;
    left: 0px; top: 0px;
    pointer-events: none;">
</div>
        `.trim();

        this.#elThumb = this.#elGround.children[0];

        this.#rctGround = fn_getRect(this.#elGround);
        this.#rctThumb = fn_getRect(this.#elThumb);
    }

    /** @type {string} */
    static #CBT_SCROLL = 'scroll';

    /** @type {number} */
    static #MINV = 30.0;

    /** @type {HTMLElement} */
    #elGround = null;
    /** @type {HTMLElement} */
    #elThumb = null;

    /** @type {DOMRect} */
    #rctGround = null;
    /** @type {DOMRect} */
    #rctThumb = null;

    /** @type {number} */
    #scrollSizeRatio = 1.0;
    /** @type {number} */
    #scrollPositionRatio = 0.0;

    /** @type {boolean} */
    #bmd = false;
    /** @type {number} */
    #mdp = NaN;


    ////////////////////////////////////////////////////////////////////////////////////////////////////
    /** @returns {void} */
    fn_applyGroundRect() {
        this.#elGround.width = this.#rctGround.width;
        this.#elGround.height = this.#rctGround.height;
        this.#elGround.x = this.#rctGround.left;
        this.#elGround.y = this.#rctGround.top;
    }

    /** @returns {void} */
    fn_applyThumbRect() {
        this.#elThumb.width = this.#rctThumb.width;
        this.#elThumb.height = this.#rctThumb.height;
        this.#elThumb.x = this.#rctThumb.left;
        this.#elThumb.y = this.#rctThumb.top;
    }

    /** @returns {void} */
    fn_applyAllRect() {
        this.fn_applyGroundRect();
        this.fn_applyThumbRect();
    }


    ////////////////////////////////////////////////////////////////////////////////////////////////////
    /** @returns {number} */
    #fn_getScrollSize() {
        let ss = this.#rctGround.width - this.#rctThumb.width;
        if (ss < 0.0) ss = 0.0;

        return ss;
    }


    ////////////////////////////////////////////////////////////////////////////////////////////////////
    /** @returns {number} */
    fn_getGroundWidth() {
        return this.#rctGround.width;
    }

    /** @returns {number} */
    fn_getGroundHeight() {
        return this.#rctGround.height;
    }

    /** @returns {number} */
    fn_getGroundLeft() {
        return this.#rctGround.left;
    }

    /** @returns {number} */
    fn_getGroundTop() {
        return this.#rctGround.top;
    }

    /**
     *
     * @param {number} val
     * @param {boolean} bApply
     * @returns {void}
     */
    fn_setGroundWidth(val, bApply=true) {
        if (val === this.#rctGround.width) return;

        if (val < hfHScroller.#MINV) val = hfHScroller.#MINV;
        this.#rctGround.width = val;

        let sz = this.#rctGround.width * this.#scrollSizeRatio;
        if (sz < hfHScroller.#MINV) sz = hfHScroller.#MINV;
        this.#rctThumb.width = sz;
        const sv = this.#fn_getScrollSize() * this.#scrollPositionRatio;
        this.#rctThumb.x = this.#rctGround.left + sv;

        if (bApply === true) {
            this.#elGround.width = this.#rctGround.width;
            this.#elThumb.width = this.#rctThumb.width;
            this.#elThumb.x = this.#rctThumb.left;
        }
    }

    /**
     *
     * @param {number} val
     * @param {boolean} bApply
     * @returns {void}
     */
    fn_setGroundHeight(val, bApply=true) {
        if (val === this.#rctGround.height) return;

        if (val < hfHScroller.#MINV) val = hfHScroller.#MINV;
        this.#rctGround.height = val;
        this.#rctThumb.height = val;
        this.#rctThumb.y = this.#rctGround.top;

        if (bApply === true) {
            this.#elGround.height = this.#rctGround.height;
            this.#elThumb.height = this.#rctThumb.height;
            this.#elThumb.y = this.#rctThumb.top;
        }
    }

    /**
     *
     * @param {number} val
     * @param {boolean} bApply
     * @returns {void}
     */
    fn_setGroundLeft(val, bApply=true) {
        if (val === this.#rctGround.left) return;

        this.#rctGround.x = val;
        const sv = this.#fn_getScrollSize() * this.#scrollPositionRatio;
        this.#rctThumb.x = this.#rctGround.left + sv;

        if (bApply === true) {
            this.#elGround.x = this.#rctGround.left;
            this.#elThumb.x = this.#rctThumb.left;
        }
    }

    /**
     *
     * @param {number} val
     * @param {boolean} bApply
     * @returns {void}
     */
    fn_setGroundTop(val, bApply=true) {
        if (val === this.#rctGround.top) return;

        this.#rctGround.y = val;
        this.#rctThumb.y = val;

        if (bApply === true) {
            this.#elGround.y = this.#rctGround.top;
            this.#elThumb.y = this.#rctThumb.top;
        }
    }


    ////////////////////////////////////////////////////////////////////////////////////////////////////
    /**
     *
     * @param {number} val
     * @param {boolean} bApply
     * @returns {void}
     */
    #fn_setThumbSize(val, bApply=true) {
        if (val === this.#rctThumb.width) return;

        const bv = hfHScroller.#MINV;
        const ev = this.#rctGround.width;

        let cv = val;
        if (cv < bv) cv = bv;
        else if (cv > ev) cv = ev;
        this.#rctThumb.width = cv;

        const sv = this.#fn_getScrollSize() * this.#scrollPositionRatio;
        this.#rctThumb.x = this.#rctGround.left + sv;

        if (bApply === true) {
            this.#elThumb.width = this.#rctThumb.width;
            this.#elThumb.x = this.#rctThumb.left;
        }
    }

    /**
     *
     * @param {number} val
     * @param {boolean} bApply
     * @returns {void}
     */
    #fn_setThumbPosition(val, bApply=true) {
        if (val === this.#rctThumb.left) return;

        const bv = this.#rctGround.left;
        const ev = this.#rctGround.right - this.#rctThumb.width;

        let cv = val;
        if (cv < bv) cv = bv;
        else if (cv > ev) cv = ev;
        this.#rctThumb.x = cv;

        let vr = (cv - bv) / (ev - bv);
        if (isFinite(vr) === true) {
            this.#scrollPositionRatio = vr;
            // console.log(this.#scrollPositionRatio);
        }

        if (bApply === true) {
            this.#elThumb.x = this.#rctThumb.left;
        }
    }


    ////////////////////////////////////////////////////////////////////////////////////////////////////
    /**
     *
     * @returns {number}
     */
    fn_getScrollSizeRatio() {
        return this.#scrollSizeRatio;
    }

    /**
     *
     * @param {number} val
     * @param {boolean} bApply
     * @returns {void}
     */
    fn_setScrollSizeRatio(val, bApply=true) {
        if (val < 0.0) val = 0.0;
        else if (val > 1.0) val = 1.0;
        this.#scrollSizeRatio = val;

        this.#fn_setThumbSize(this.#rctGround.width * this.#scrollSizeRatio, bApply);
    }


    ////////////////////////////////////////////////////////////////////////////////////////////////////
    /**
     *
     * @returns {number}
     */
    fn_getScrollPositionRatio() {
        return this.#scrollPositionRatio;
    }

    /**
     *
     * @param {number} val
     * @param {boolean} bApply
     * @returns {void}
     */
    fn_setScrollPositionRatio(val, bApply=true) {
        if (val === this.#scrollPositionRatio) return;

        if (val < 0.0) val = 0.0;
        else if (val > 1.0) val = 1.0;
        this.#scrollPositionRatio = val;
        // console.log(this.#scrollPositionRatio);

        const bv = this.#rctGround.left;
        const ev = this.#rctGround.right - this.#rctThumb.width;
        const sv = this.#fn_getScrollSize() * this.#scrollPositionRatio;

        let cv = bv + sv;
        if (cv < bv) cv = bv;
        else if (cv > ev) cv = ev;
        this.#rctThumb.x = cv;

        if (bApply === true) {
            this.#elThumb.x = this.#rctThumb.left;
        }
    }



    ////////////////////////////////////////////////////////////////////////////////////////////////////
    /**
     *
     * @param {MouseEvent} e
     * @returns {void}
     */
    #fn_mouseMove(e) {
        if (this.#bmd === false) return;

        const cv = e.clientX - this.#mdp;
        this.#fn_setThumbPosition(cv);

        this.dispatchEvent(new Event(hfEventTypes.MouseMove));
    }

    /**
     *
     * @param {MouseEvent} e
     * @returns {void}
     */
    #fn_mouseUp(e) {
        if (this.#bmd === false) return;

        window.removeEventListener(hfEventTypes.MouseMove, this.#fn_mouseMove);
        window.removeEventListener(hfEventTypes.MouseUp, this.#fn_mouseUp);
        window.removeEventListener(hfEventTypes.Blur, this.#fn_mouseUp);
        this.#bmd = false;
    }

    /**
     *
     * @param {MouseEvent} e
     * @returns {void}
     */
    #fn_mouseDown(e) {
        if (this.#bmd === true) return;

        window.addEventListener(hfEventTypes.MouseMove, this.#fn_mouseMove);
        window.addEventListener(hfEventTypes.MouseUp, this.#fn_mouseUp);
        window.addEventListener(hfEventTypes.Blur, this.#fn_mouseUp);
        this.#bmd = true;

        if (this.#rctThumb.contains(_owner.mouseX, _owner.mouseY)) {
            this.#mdp = e.clientY - this.#rctThumb.left;

            this.#fn_mouseMove(e);
        }
        else {
            const cv = _owner.mouseX - (_rctThumb.width / 2);
            fn_setThumbPosition(cv);
            _mdp = _owner.mouseX - _rctThumb.left;

            fn_callback(hfHScroller.CBT_SCROLL);
        }
    }

});
//#endregion