//#region '~~~~~~~~~~ 00) 공통 코드'
/**
 * 이벤트 타입들
 */
const hfEventTypes = Object.freeze({
    MouseMove: 'mousemove',
    Blur: 'blur',
    MouseUp: 'mouseup',
    MouseDown: 'mousedown',
    Scroll: 'scroll',
    Resize: 'resize',
    Click: 'click'
});


/**
 * Element 스타일 객체 반환
 * @param {CSSStyleDeclaration | HTMLElement} to
 * @param {boolean} bw writeable
 * @returns {CSSStyleDeclaration}
 */
const fn_getStyles = (to, bw=false) => {
    if (to instanceof CSSStyleDeclaration)
        return to;
    else if (to instanceof HTMLElement) {
        if (bw === true)
            return to.style;
        else
            return getComputedStyle(to);
    }
    else return null;
};

/**
 * 넘버인지 확인후 반환
 * @param {number | string} tv
 * @param {number} dv
 * @returns {number}
 */
const fn_checkNumber = (tv, dv=0) => {
    let rv = NaN;
    if (typeof tv === 'number')
        rv = tv;
    else if (typeof tv === 'string')
        rv = parseFloat(tv);

    if (isFinite(rv) === true)
        return rv;
    else
        return dv;
};


/**
 * Element left(Number) 가져오기
 * @param {CSSStyleDeclaration | HTMLElement} to
 * @returns {number}
 */
const fn_getLeft = (to) => {
    const sts = fn_getStyles(to);
    if (sts !== null) {
        let tv = sts.getPropertyValue('left');
        return fn_checkNumber(tv);
    }
    else return 0.0;
};

/**
 * Element left(Number) 설정하기
 * @param {CSSStyleDeclaration | HTMLElement} to
 * @param {number} tv
 */
const fn_setLeft = (to, tv) => {
    const sts = fn_getStyles(to, true);
    if (sts !== null) {
        tv = fn_checkNumber(tv);
        sts.setProperty('left', `${tv}px`);
    }
};


/**
 * Element top(Number) 반환
 * @param {CSSStyleDeclaration | HTMLElement} to
 * @returns {number}
 */
const fn_getTop = (to) => {
    const sts = fn_getStyles(to);
    if (sts !== null) {
        let tv = sts.getPropertyValue('top');
        return fn_checkNumber(tv);
    }
    else return 0.0;
};

/**
 * Element top(Number) 설정
 * @param {CSSStyleDeclaration | HTMLElement} to
 * @param {number} tv
 */
const fn_setTop = (to, tv) => {
    const sts = fn_getStyles(to, true);
    if (sts !== null) {
        tv = fn_checkNumber(tv);
        sts.setProperty('top', `${tv}px`);
    }
};


/**
 * Element width(Number) 반환
 * @param {CSSStyleDeclaration | HTMLElement} to
 * @returns {number}
 */
const fn_getWidth = (to) => {
    const sts = fn_getStyles(to);
    if (sts !== null) {
        let tv = sts.getPropertyValue('width');
        return fn_checkNumber(tv);
    }
    else return 0.0;
};

/**
 * Element width(Number) 설정
 * @param {CSSStyleDeclaration | HTMLElement} to
 * @param {number} tv
 */
const fn_setWidth = (to, tv) => {
    const sts = fn_getStyles(to, true);
    if (sts !== null) {
        tv = fn_checkNumber(tv);
        sts.setProperty('width', `${tv}px`);
    }
};


/**
 * Element height(Number) 반환
 * @param {CSSStyleDeclaration | HTMLElement} to
 * @returns {number}
 */
const fn_getHeight = (to) => {
    const sts = fn_getStyles(to);
    if (sts !== null) {
        let tv = sts.getPropertyValue('height');
        return fn_checkNumber(tv);
    }
    else return 0.0;
};

/**
 * Element height(Number) 설정
 * @param {CSSStyleDeclaration | HTMLElement} to
 * @param {number} tv
 */
const fn_setHeight = (to, tv) => {
    const sts = fn_getStyles(to, true);
    if (sts !== null) {
        tv = fn_checkNumber(tv);
        sts.setProperty('height', `${tv}px`);
    }
};


/**
 * Element Rect 반환
 * @param {CSSStyleDeclaration | HTMLElement} to
 * @returns {DOMRect}
 */
const fn_getRect = (to) => {
    const sts = fn_getStyles(to);
    if (sts !== null) {
        let tx = fn_getLeft(sts);
        let ty = fn_getTop(sts);
        let tw = fn_getWidth(sts);
        let th = fn_getHeight(sts);
        let rct = new DOMRect(tx, ty, tw, th);
        return rct;
    }
    else return null;
};


/**
 * Element Rect 반환
 * @param {CSSStyleDeclaration | HTMLElement} to
 * @param {DOMRect} rct
 * @returns {DOMRect}
 */
const fn_updateRect = (to, rct) => {
    const sts = fn_getStyles(to);
    if (sts !== null) {
        let tw = fn_getWidth(sts);
        let th = fn_getHeight(sts);
        let tx = fn_getLeft(sts);
        let ty = fn_getTop(sts);
        rct.width = tw;
        rct.height = th;
    }
};


/**
 * Rect에 좌표(tx, ty)가 포함되는지 여부
 * @param {DOMRect} rct
 * @param {number} tx
 * @param {number} ty
 * @returns {boolean}
 */
const fn_containsRect = (rct, tx, ty) => {
    const rb = ((rct.left <= tx) && (rct.right >= tx)) &&
        ((rct.top <= ty) && (rct.bottom >= ty));
    return rb;
};


/**
 * Element에 Rect 적용하기
 * @param {CSSStyleDeclaration | HTMLElement} to
 * @param {DOMRect} rct
 */
const fn_applyRectToElement = (to, rct) => {
    const sts = fn_getStyles(to, true);
    if ((sts !== null) && (rct instanceof DOMRect)) {
        fn_setLeft(sts, rct.left);
        fn_setTop(sts, rct.top);
        fn_setWidth(sts, rct.width);
        fn_setHeight(sts, rct.height);
    }
};
//#endregion



//#region '~~~~~~~~~~ 01) hfHScroller'
const hfHScroller = Object.freeze(class extends EventTarget {
    ////////////////////////////////////////////////////////////////////////////////////////////////////
    constructor(elId='hscr') {
        super();

        this.#elGround = document.getElementById(elId);
        this.#elGround.setAttribute('style', `
width: 100%; height: 20px;
background-color: #595959;
position: static; display: inline-block;
overflow-x: hidden; overflow-y: hidden;
font-size: 0px; cursor: pointer;
        `.trim());
        this.#elGround.innerHTML = `
<div style="background-color: #748B96;
    position: relative;
    width: 100%; height: 100%;
    left: 0px; top: 0px;
    pointer-events: none; overflow: visible;
    box-sizing: border-box; font-size: 0px;
    border: 3px solid #595959;">
    <span style="
        position: relative;
        display: inline-block;
        width: auto; height: auto;
        left: 50%; top: 50%;
        transform: translate(-50%, -50%);
        user-select: none; white-space: nowrap;
        font-size: 11px; color: #ffffff66;"></span>
</div>
        `.trim();

        this.#elThumb = this.#elGround.children[0];
        this.#elSpan = this.#elThumb.children[0];
        this.#elSpan.innerText = '';

        this.#rctGround = fn_getRect(this.#elGround);
        this.#rctThumb = fn_getRect(this.#elThumb);

        this.#elGround.addEventListener(hfEventTypes.MouseDown, this.#fn_mouseDown);

        window.addEventListener(hfEventTypes.Resize, this.#fn_resize);
        // this.#fn_resize(null);
    }

    /** @type {number} */
    static #MINV = 30.0;

    /** @type {HTMLElement} */
    #elGround = null;
    /** @type {HTMLElement} */
    #elThumb = null;
    /** @type {HTMLElement} */
    #elSpan = null;

    /** @type {DOMRect} */
    #rctGround = null;
    /** @type {DOMRect} */
    #rctThumb = null;

    /** @type {number} */
    #scrollSizeRatio = 1.0;
    /** @type {number} */
    #scrollPositionRatio = 0.0;

    /** @type {boolean} */
    #bmd = false;
    /** @type {number} */
    #mdp = NaN;


    ////////////////////////////////////////////////////////////////////////////////////////////////////
    /** @returns {void} */
    #fn_printSpanLog() {
        if (true) {
            const ssr = this.#scrollSizeRatio.toFixed(3);
            const spr = this.#scrollPositionRatio.toFixed(3);
            this.#elSpan.innerText = `SSR: ${ssr}, SPR: ${spr}`;
        }
    }

    /** @returns {number} */
    #fn_getScrollSize() {
        let ss = this.#rctGround.width - this.#rctThumb.width;
        if (ss < 0.0) ss = 0.0;

        return ss;
    }


    ////////////////////////////////////////////////////////////////////////////////////////////////////
    /**
     * Thumb 사이즈 설정
     * @param {number} val
     * @param {boolean} bApply
     * @returns {void}
     */
    #fn_setThumbSize(val, bApply=true) {
        if (val === this.#rctThumb.width) return;

        const bv = hfHScroller.#MINV;
        const ev = this.#rctGround.width;
        let cv = val;
        if (cv < bv) cv = bv;
        else if (cv > ev) cv = ev;
        this.#rctThumb.width = cv;

        const sv = this.#fn_getScrollSize() * this.#scrollPositionRatio;
        this.#rctThumb.x = sv;

        if (bApply === true) {
            fn_setWidth(this.#elThumb, this.#rctThumb.width);
            fn_setLeft(this.#elThumb, this.#rctThumb.left);
        }
    }

    /**
     * Thumb 포지션 설정
     * @param {number} val
     * @param {boolean} bApply
     * @returns {void}
     */
    #fn_setThumbPosition(val, bApply=true) {
        if (val === this.#rctThumb.left) return;

        const bv = 0.0;
        const ev = this.#fn_getScrollSize();
        let cv = val;
        if (cv < bv) cv = bv;
        else if (cv > ev) cv = ev;
        this.#rctThumb.x = cv;

        let vr = (cv - bv) / (ev - bv);
        if (isFinite(vr) === true) {
            this.#scrollPositionRatio = vr;
        }

        if (bApply === true) {
            fn_setLeft(this.#elThumb, this.#rctThumb.left);
        }
    }


    ////////////////////////////////////////////////////////////////////////////////////////////////////
    /**
     * 스크롤 사이즈 비율 반환
     * @returns {number}
     */
    fn_getScrollSizeRatio() {
        return this.#scrollSizeRatio;
    }

    /**
     * 스크롤 사이즈 비율 설정
     * @param {number} val
     * @param {boolean} bApply
     * @returns {void}
     */
    fn_setScrollSizeRatio(val, bApply=true) {
        if (val < 0.0) val = 0.0;
        else if (val > 1.0) val = 1.0;
        this.#scrollSizeRatio = val;

        const sz = this.#rctGround.width * this.#scrollSizeRatio;
        this.#fn_setThumbSize(sz, bApply);

        this.#fn_printSpanLog();
    }


    ////////////////////////////////////////////////////////////////////////////////////////////////////
    /**
     * 스크롤 포지션 비율 반환
     * @returns {number}
     */
    fn_getScrollPositionRatio() {
        return this.#scrollPositionRatio;
    }

    /**
     * 스크롤 포지션 비율 설정
     * @param {number} val
     * @param {boolean} bApply
     * @returns {void}
     */
    fn_setScrollPositionRatio(val, bApply=true) {
        if (val === this.#scrollPositionRatio) return;

        if (val < 0.0) val = 0.0;
        else if (val > 1.0) val = 1.0;
        this.#scrollPositionRatio = val;

        const bv = 0.0;
        const ev = this.#fn_getScrollSize();
        let cv = ev * this.#scrollPositionRatio;
        if (cv < bv) cv = bv;
        else if (cv > ev) cv = ev;
        this.#rctThumb.x = cv;

        this.#fn_printSpanLog();

        if (bApply === true) {
            fn_setLeft(this.#elThumb, this.#rctThumb.left);
        }
    }


    ////////////////////////////////////////////////////////////////////////////////////////////////////
    /**
     * 리사이즈 후 업데이트
     * @returns {void}
     */
    #fn_updateAfterResized(bApply=true) {
        const bv = hfHScroller.#MINV;
        const ev = this.#rctGround.width;
        let cv = ev * this.#scrollSizeRatio;
        if (cv < bv) cv = bv;
        else if (cv > ev) cv = ev;
        this.#rctThumb.width = cv;

        const cp = this.#fn_getScrollSize() * this.#scrollPositionRatio;
        this.#rctThumb.x = cp;

        if (bApply === true) {
            fn_setWidth(this.#elThumb, this.#rctThumb.width);
            fn_setLeft(this.#elThumb, this.#rctThumb.left);
        }

        this.#fn_printSpanLog();
    }



    ////////////////////////////////////////////////////////////////////////////////////////////////////
    /**
     * MOUSE_MOVE
     * @param {MouseEvent} e
     * @returns {void}
     */
    #fn_mouseMove = (e) => {
        if (this.#bmd === false) return;

        const cv = e.clientX - this.#mdp;
        this.#fn_setThumbPosition(cv);

        this.dispatchEvent(new Event(hfEventTypes.Scroll));

        this.#fn_printSpanLog();
    }

    /**
     * MOUSE_UP
     * @param {MouseEvent} e
     * @returns {void}
     */
    #fn_mouseUp = (e) => {
        if (this.#bmd === false) return;

        window.removeEventListener(hfEventTypes.MouseMove, this.#fn_mouseMove);
        window.removeEventListener(hfEventTypes.MouseUp, this.#fn_mouseUp);
        window.removeEventListener(hfEventTypes.Blur, this.#fn_mouseUp);
        this.#bmd = false;
    }

    /**
     * MOUSE_DOWN
     * @param {MouseEvent} e
     * @returns {void}
     */
    #fn_mouseDown = (e) => {
        if (this.#bmd === true) return;

        window.addEventListener(hfEventTypes.MouseMove, this.#fn_mouseMove);
        window.addEventListener(hfEventTypes.MouseUp, this.#fn_mouseUp);
        window.addEventListener(hfEventTypes.Blur, this.#fn_mouseUp);
        this.#bmd = true;

        if (fn_containsRect(this.#rctThumb, e.offsetX, e.offsetY) === true) {
            this.#mdp = e.clientX - this.#rctThumb.left;

            this.#fn_mouseMove(e);
        }
        else {
            const cv = e.clientX - (this.#rctThumb.width / 2);
            this.#fn_setThumbPosition(cv);
            this.#mdp = e.clientX - this.#rctThumb.left;

            this.dispatchEvent(new Event(hfEventTypes.Scroll));
        }
    }

    /**
     * RESIZE
     * @param {Event} e
     * @returns {void}
     */
    #fn_resize = (e) => {
        fn_updateRect(this.#elGround, this.#rctGround);
        fn_updateRect(this.#rctThumb, this.#rctThumb);

        this.#fn_updateAfterResized();
    }

});
//#endregion