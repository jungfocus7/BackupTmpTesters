import { fn_getRect } from "./hfStyleFunctions.js";

const hfViewBox = Object.freeze(class {
    //////////////////////////////////////////////////////////////////////
    /**
     * 생성자
     * @param {DOMRect} rctViewport Viewport영역
     * @param {DOMRect} rctBody Body영역
     */
    constructor(rctViewport, rctBody) {
        // const elViewport = document.getElementById(enmViewport);
        // const elBody = document.getElementById(enmBody);
        // console.log(elViewport, elBody);

        this.#rctViewport = rctViewport;
        this.#rctBody = rctBody;
        this.#rctBody.x = this.#rctViewport.left;
        this.#rctBody.y = this.#rctViewport.top;
        console.log(this.#rctViewport, this.#rctBody);

        this.#fn_updateScrollWidth();
        this.#fn_updateScrollHeight();
    }

    /** @type {DOMRect} Viewport영역 */
    #rctViewport = null;

    /** @type {DOMRect} Body영역 */
    #rctBody = null;


    //////////////////////////////////////////////////////////////////////
    /** @type {number} 스크롤 넓이 */
    #scrollWidth = 0.0;

    /**
     * 스크롤 넓이 업데이트
     * @returns {void}
     */
    #fn_updateScrollWidth() {
        let scv = this.#rctBody.width - this.#rctViewport.width;
        if (scv < 0.0) scv = 0.0;
        console.log('이것이 문제인가? >>> ', scv);
        console.log(this.#rctBody.width, this.#rctViewport.width);
        this.#scrollWidth = scv;
    };

    /**
     * 스크롤 넓이 가져오기
     * @param {boolean} bu 업데이트 여부
     * @returns {number}
     */
    fn_getScrollWidth(bu=false) {
        if (bu === true) this.#fn_updateScrollWidth();
        return this.#scrollWidth;
    }


    //////////////////////////////////////////////////////////////////////
    /** @type {number} 스크롤 Y축 */
    #scrollHeight = 0.0;

    /**
     * 스크롤 높이 업데이트
     * @returns {void}
     */
    #fn_updateScrollHeight() {
        let scv = this.#rctBody.height - this.#rctViewport.height;
        if (scv < 0.0) scv = 0.0;
        this.#scrollHeight = scv;
    }

    /**
     * 스크롤 높이 가져오기
     * @param {boolean} bu 업데이트 여부
     * @returns {number}
     */
    fn_getScrollHeight(bu=false) {
        if (bu === true) this.#fn_updateScrollHeight();
        return this.#scrollHeight;
    }


    //////////////////////////////////////////////////////////////////////
    /** @type {number} 스크롤 X축 */
    #scrollX = 0.0;

    /**
     * 스크롤 X축 업데이트
     * @param {boolean} br 기본계산(false는 비율계산)
     */
    #fn_updateScrollX(br=true) {
        let sp = 0;
        if (br === true) {
            sp = this.#rctViewport.left - this.#rctBody.left;
            if (sp < 0.0) sp = 0.0;
            this.#scrollX = sp;
        }
        else {
            const scv = this.fn_getScrollWidth();
            const sr = this.fn_getScrollRatioX();
            sp = scv * sr;
            this.#scrollX = sp;
        }
    }

    /**
     * 스크롤 X축 가져오기
     * @param {boolean} bu 업데이트 여부
     * @returns {number}
     */
    fn_getScrollX(bu=false) {
        if (bu === true) this.#fn_updateScrollX();
        return this.#scrollX;
    }

    /**
     * Body영역 X축 계산하기
     * @returns {void}
     */
    #fn_calcRctBodyX() {
        const scv = this.fn_getScrollWidth();
        const gjv = this.#rctViewport.left;
        let rp = 0;
        if (scv > 0.0) {
            const min = gjv - scv;
            const max = gjv;
            rp = gjv - this.#scrollX;
            if (rp < min) rp = min;
            else if (rp > max) rp = max;
            this.#rctBody.x = rp;
        }
        else {
            rp = (this.#rctViewport.right - (this.#rctViewport.width / 2)) -
                (this.#rctBody.width / 2);
            this.#rctBody.x = rp;
        }
    }

    /**
     * 스크롤 X축 설정하기
     * @param {number} val
     * @returns
     */
    fn_setScrollX(val) {
        const min = 0.0;
        const max = this.fn_getScrollWidth();
        if (min === max) return;
        let sp = val;
        if (sp !== this.#scrollX) {
            if (sp < min) sp = min;
            else if (sp > max) sp = max;
            this.#scrollX = sp;
            this.#fn_calcRctBodyX();
            this.#fn_updateScrollRatioX();
        }
    }


    //////////////////////////////////////////////////////////////////////
    /** @type {number} 스크롤 Y축 */
    #scrollY = 0.0;

    /**
     * 스크롤 Y축 업데이트
     * @param {boolean} br 기본계산(false는 비율계산)
     */
    #fn_updateScrollY(br=true) {
        let sp = 0;
        if (br === true) {
            sp = this.#rctViewport.top - this.#rctBody.top;
            if (sp < 0.0) sp = 0.0;
            this.#scrollY = sp;
        }
        else {
            const scv = this.fn_getScrollHeight();
            const sr = this.fn_getScrollRatioY();
            sp = scv * sr;
            this.scrollY = sp;
        }
    }

    /**
     * 스크롤 Y축 가져오기
     * @param {boolean} bu 업데이트 여부
     * @returns {number}
     */
    fn_getScrollY(bu=false) {
        if (bu === true) this.#fn_updateScrollY();
        return this.#scrollY;
    }

    /**
     * Body영역 Y축 계산하기
     * @returns {void}
     */
    #fn_calcRctBodyY() {
        const scv = this.fn_getScrollHeight();
        const gjv = this.#rctViewport.top;
        let rp = 0;
        if (scv > 0.0) {
            const min = gjv - scv;
            const max = gjv;
            rp = gjv - this.#scrollY;
            if (rp < min) rp = min;
            else if (rp > max) rp = max;
            this.#rctBody.y = rp;
        }
        else {
            rp = (this.#rctViewport.bottom - (this.#rctViewport.height / 2)) -
                (this.#rctBody.height / 2);
            this.#rctBody.y = rp;
        }
    }

    /**
     * 스크롤 Y축 설정하기
     * @param {number} val
     * @returns
     */
    fn_setScrollY(val) {
        const min = 0.0;
        const max = this.fn_getScrollHeight();
        if (min === max) return;
        let sp = val;
        if (sp !== this.#scrollY) {
            if (sp < min) sp = min;
            else if (sp > max) sp = max;
            this.#scrollY = sp;
            this.#fn_calcRctBodyY();
            this.#fn_updateScrollRatioY();
        }
    }


    //////////////////////////////////////////////////////////////////////
    /** @type {number} 스크롤 X축 비율 */
    #scrollRatioX = 0.0;

    /**
     * 스크롤 X축 비율 업데이트
     * @returns {void}
     */
    #fn_updateScrollRatioX() {
        const scv = this.fn_getScrollWidth(true);
        if (scv > 0.0) {
            let sp = this.#rctViewport.left - this.#rctBody.left;
            if (sp < 0.0) sp = 0.0;
            let sr = sp / scv;
            if (sr < 0.0) sr = 0.0;
            else if (sr > 1.0) sr = 1.0;
            this.#scrollRatioX = sr;
        }
        else {
            this.#scrollRatioX = 0.0;
        }
    }

    /**
     * 스크롤 X축 비율 가져오기
     * @param {boolean} bu 업데이트 여부
     * @returns {number}
     */
    fn_getScrollRatioX(bu=false) {
        if (bu === true) this.#fn_updateScrollRatioX();
        return this.#scrollRatioX;
    }

    /**
     * 스크롤 X축 비율 설정하기
     * @param {number} val
     */
    fn_setScrollRatioX(val) {
        let sr = val;
        if (sr !== this.#scrollRatioX) {
            if (sr < 0.0) sr = 0.0;
            else if (sr > 1.0) sr = 1.0;
            this.#scrollRatioX = sr;
            this.#fn_updateScrollX(false);
        }
    }


    //////////////////////////////////////////////////////////////////////
    /** @type {number} 스크롤 Y축 비율 */
    #scrollRatioY = 0.0;

    /**
     * 스크롤 Y축 비율 업데이트
     * @returns {void}
     */
    #fn_updateScrollRatioY() {
        const scv = this.fn_getScrollHeight(true);
        if (scv > 0.0) {
            let sp = this.#rctViewport.top - this.#rctBody.top;
            if (sp < 0.0) sp = 0.0;
            let sr = sp / scv;
            if (sr < 0.0) sr = 0.0;
            else if (sr > 1.0) sr = 1.0;
            this.#scrollRatioY = sr;
        }
        else {
            this.#scrollRatioY = 0.0;
        }
    }

    /**
     * 스크롤 Y축 비율 가져오기
     * @param {boolean} bu 업데이트 여부
     * @returns {number}
     */
    fn_getScrollRatioY(bu=false) {
        if (bu === true) this.#fn_updateScrollRatioY();
        return this.#scrollRatioY;
    }

    /**
     * 스크롤 X축 비율 설정하기
     * @param {number} val
     */
    fn_setScrollRatioY(val) {
        let sr = val;
        if (sr !== this.#scrollRatioY) {
            if (sr < 0.0) sr = 0.0;
            else if (sr > 1.0) sr = 1.0;
            this.#scrollRatioY = sr;
            this.#fn_updateScrollY(false);
        }
    }


    //////////////////////////////////////////////////////////////////////
    static RN_VIEW_BOX = 'rctViewBox';
    static RN_BODY = 'rctBody';

    /**
     * 엘리먼트에 변경된 Rect적용하기
     * @param {string} rn RectName
     * @param {HTMLElement} el Element
     */
    fn_applyRectToElement(rn, el) {
        let rct = null;
        if (rn === hfViewBox.RN_VIEW_BOX) {
            rct = this.#rctViewport;
        }
        else if (rn === hfViewBox.RN_BODY) {
            rct = this.#rctBody;
        }

        if (rct !== null) {
            el.width = rct.width;
            el.height = rct.height;
            el.x = rct.left;
            el.y = rct.top;
        }
    }


    // //////////////////////////////////////////////////////////////////////
    static #MIN_W = 10.0;

    /**
     * Viewport영역 넓이 가져오기
     * @returns {number}
     */
    fn_getViewWidth() {
        return this.#rctViewport.width;
    }

    /**
     * Viewport영역 넓이 설정하기
     * @param {number} val
     */
    fn_setViewWidth(val) {
        if (val < hfViewBox.#MIN_W) val = hfViewBox.#MIN_W;
        this.#rctViewport.width = val;
        this.#fn_updateScrollWidth();
        this.#fn_updateScrollX(false);
        this.#fn_calcRctBodyX();
    }

    /**
     * Body영역 넓이 가져오기
     * @returns {number}
     */
    fn_getBodyWidth() {
        return this.#rctBody.width;
    }

    /**
     * Body영역 넓이 설정하기
     * @param {number} val
     */
    fn_setBodyWidth(val) {
        if (val < hfViewBox.#MIN_W) val = hfViewBox.#MIN_W;
        this.#rctBody.width = val;
        this.#fn_updateScrollWidth();
        this.#fn_updateScrollX(false);
        this.#fn_calcRctBodyX();
    }


    //////////////////////////////////////////////////////////////////////
    static #MIN_H = 10.0;

    /**
     * Viewport영역 높이 가져오기
     * @returns {number}
     */
    fn_getViewHeight() {
        return this.#rctViewport.height;
    }

    /**
     * Viewport영역 높이 설정하기
     * @param {number} val
     */
    fn_setViewHeight(val) {
        if (val < hfViewBox.#MIN_H) val = hfViewBox.#MIN_H;
        this.#rctViewport.height = val;
        this.#fn_updateScrollHeight();
        this.#fn_updateScrollY(false);
        this.#fn_calcRctBodyY();
    }

    /**
     * Body영역 높이 가져오기
     * @returns {number}
     */
    fn_getBodyHeight() {
        return this.#rctBody.height;
    }

    /**
     * Body영역 높이 설정하기
     * @param {number} val
     */
    fn_setBodyHeight(val) {
        if (val < hfViewBox.#MIN_H) val = hfViewBox.#MIN_H;
        this.#rctBody.height = val;
        this.#fn_updateScrollHeight();
        this.#fn_updateScrollY(false);
        this.#fn_calcRctBodyY();
    }

});


export { hfViewBox };