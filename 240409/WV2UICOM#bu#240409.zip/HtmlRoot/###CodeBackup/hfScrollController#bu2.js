//#region '~~~~~~~~~~ 00) 공통 코드'
/**
 * 이벤트 타입들
 */
const hfEventTypes = Object.freeze({
    MouseMove: 'mousemove',
    Blur: 'blur',
    MouseUp: 'mouseup',
    MouseDown: 'mousedown',
    Resize: 'resize',
    Scroll: 'scroll',
    Click: 'click',
    Resize: 'resize'
});


/**
 * Element 스타일 객체 반환
 * @param {CSSStyleDeclaration | HTMLElement} to
 * @param {Boolean} bw writeable
 * @returns CSSStyleDeclaration
 */
const fn_getStyles = (to, bw=false) => {
    if (to instanceof CSSStyleDeclaration)
        return to;
    else if (to instanceof HTMLElement) {
        if (bw === true)
            return to.style;
        else
            return getComputedStyle(to);
    }
    else return null;
};

/**
 * 넘버인지 확인후 반환
 * @param {Number} tv
 * @param {Number} dv
 * @returns Number
 */
const fn_checkNumber = (tv, dv=0) => {
    if (typeof tv === 'number') {
        if (isNaN(tv))
            return dv;
        else
            return tv;
    }
    else return dv;
};


/**
 * Element left(Number) 가져오기
 * @param {CSSStyleDeclaration | HTMLElement} to
 * @returns Number
 */
const fn_getLeft = (to) => {
    const sts = fn_getStyles(to);
    if (sts !== null) {
        let tv = sts.getPropertyValue('left');
        return fn_checkNumber(parseFloat(tv));
    }
};

/**
 * Element left(Number) 설정하기
 * @param {CSSStyleDeclaration | HTMLElement} to
 * @param {Number} tv
 */
const fn_setLeft = (to, tv) => {
    const sts = fn_getStyles(to, true);
    if (sts !== null) {
        tv = fn_checkNumber(tv);
        sts.setProperty('left', `${tv}px`);
    }
};


/**
 * Element top(Number) 반환
 * @param {CSSStyleDeclaration | HTMLElement} to
 * @returns Number
 */
const fn_getTop = (to) => {
    const sts = fn_getStyles(to);
    if (sts !== null) {
        let tv = sts.getPropertyValue('top');
        return fn_checkNumber(parseFloat(tv));
    }
};

/**
 * Element top(Number) 설정
 * @param {CSSStyleDeclaration | HTMLElement} to
 * @param {Number} tv
 */
const fn_setTop = (to, tv) => {
    const sts = fn_getStyles(to, true);
    if (sts !== null) {
        tv = fn_checkNumber(tv);
        sts.setProperty('top', `${tv}px`);
    }
};


/**
 * Element width(Number) 반환
 * @param {CSSStyleDeclaration | HTMLElement} to
 * @returns Number
 */
const fn_getWidth = (to) => {
    const sts = fn_getStyles(to);
    if (sts !== null) {
        let tv = sts.getPropertyValue('width');
        return fn_checkNumber(parseFloat(tv));
    }
};

/**
 * Element width(Number) 설정
 * @param {CSSStyleDeclaration | HTMLElement} to
 * @param {Number} tv
 */
const fn_setWidth = (to, tv) => {
    const sts = fn_getStyles(to, true);
    if (sts !== null) {
        tv = fn_checkNumber(tv);
        sts.setProperty('width', `${tv}px`);
    }
};


/**
 * Element height(Number) 반환
 * @param {CSSStyleDeclaration | HTMLElement} to
 * @returns Number
 */
const fn_getHeight = (to) => {
    const sts = fn_getStyles(to);
    if (sts !== null) {
        let tv = sts.getPropertyValue('height');
        return fn_checkNumber(parseFloat(tv));
    }
};

/**
 * Element height(Number) 설정
 * @param {CSSStyleDeclaration | HTMLElement} to
 * @param {Number} tv
 */
const fn_setHeight = (to, tv) => {
    const sts = fn_getStyles(to, true);
    if (sts !== null) {
        tv = fn_checkNumber(tv);
        sts.setProperty('height', `${tv}px`);
    }
};


/**
 * Element Rect 반환
 * @param {CSSStyleDeclaration | HTMLElement} to
 * @returns DOMRect
 */
const fn_getRect = (to) => {
    const sts = fn_getStyles(to);
    if (sts !== null) {
        let tx = fn_getLeft(sts);
        let ty = fn_getTop(sts);
        let tw = fn_getWidth(sts);
        let th = fn_getHeight(sts);
        let rct = new DOMRect(tx, ty, tw, th);
        return rct;
    }
    else null;
};


/**
 * Rect에 좌표(tx, ty)가 포함되는지 여부
 * @param {DOMRect} rct
 * @param {number} tx
 * @param {number} ty
 * @returns {boolean}
 */
const fn_containsRect = (rct, tx, ty) => {
    const rb = ((rct.left <= tx) && (rct.right >= tx)) &&
        ((rct.top <= ty) && (rct.bottom >= ty));
    return rb;
};


/**
 * Element에 Rect 적용하기
 * @param {CSSStyleDeclaration | HTMLElement} to
 * @param {DOMRect} rct
 */
const fn_applyRectToElement = (to, rct) => {
    const sts = fn_getStyles(to, true);
    if ((sts !== null) && (rct instanceof DOMRect)) {
        fn_setLeft(sts, rct.left);
        fn_setTop(sts, rct.top);
        fn_setWidth(sts, rct.width);
        fn_setHeight(sts, rct.height);
    }
};
//#endregion



//#region '~~~~~~~~~~ 01) hfHScroller'
const hfHScroller = Object.freeze(class extends EventTarget {
    ////////////////////////////////////////////////////////////////////////////////////////////////////
    constructor(elId='hscr') {
        super();

        this.#elGround = document.getElementById(elId);
        this.#elGround.setAttribute('style', `
width: 100%; height: 20px;
background-color: #595959;
position: static; display: inline-block;
left: 100px; top: 100px;
overflow-x: hidden;
overflow-y: hidden;
font-size: 0px;
cursor: pointer;
        `.trim());
        this.#elGround.innerHTML = `
<div style="background-color: #748B96;
    position: relative;
    width: 100%; height: 100%;
    left: 0px; top: 0px;
    pointer-events: none;
    box-sizing: border-box;
    border: 3px solid #595959;">
</div>
        `.trim();

        this.#elThumb = this.#elGround.children[0];

        this.#rctGround = fn_getRect(this.#elGround);
        this.#rctThumb = fn_getRect(this.#elThumb);

        this.#elGround.addEventListener(hfEventTypes.MouseDown, this.#fn_mouseDown);

        window.addEventListener(hfEventTypes.Resize, this.#fn_resize);
        // this.#fn_resize(null);
    }

    /** @type {string} */
    static #CBT_SCROLL = 'scroll';

    /** @type {number} */
    static #MINV = 30.0;

    /** @type {HTMLElement} */
    #elGround = null;
    /** @type {HTMLElement} */
    #elThumb = null;

    /** @type {DOMRect} */
    #rctGround = null;
    /** @type {DOMRect} */
    #rctThumb = null;

    /** @type {number} */
    #scrollSizeRatio = 1.0;
    /** @type {number} */
    #scrollPositionRatio = 0.0;

    /** @type {boolean} */
    #bmd = false;
    /** @type {number} */
    #mdp = NaN;


    ////////////////////////////////////////////////////////////////////////////////////////////////////
    /** @returns {void} */
    fn_applyGroundRect() {
        this.#elGround.width = this.#rctGround.width;
        this.#elGround.height = this.#rctGround.height;
        this.#elGround.x = this.#rctGround.left;
        this.#elGround.y = this.#rctGround.top;
    }

    /** @returns {void} */
    fn_applyThumbRect() {
        this.#elThumb.width = this.#rctThumb.width;
        this.#elThumb.height = this.#rctThumb.height;
        this.#elThumb.x = this.#rctThumb.left;
        this.#elThumb.y = this.#rctThumb.top;
    }

    /** @returns {void} */
    fn_applyAllRect() {
        this.fn_applyGroundRect();
        this.fn_applyThumbRect();
    }


    ////////////////////////////////////////////////////////////////////////////////////////////////////
    /** @returns {number} */
    #fn_getScrollSize() {
        let ss = this.#rctGround.width - this.#rctThumb.width;
        if (ss < 0.0) ss = 0.0;

        return ss;
    }


    ////////////////////////////////////////////////////////////////////////////////////////////////////
    /** @returns {number} */
    fn_getGroundWidth() {
        return this.#rctGround.width;
    }

    /** @returns {number} */
    fn_getGroundHeight() {
        return this.#rctGround.height;
    }

    /** @returns {number} */
    fn_getGroundLeft() {
        return this.#rctGround.left;
    }

    /** @returns {number} */
    fn_getGroundTop() {
        return this.#rctGround.top;
    }

    /**
     *
     * @param {number} val
     * @param {boolean} bApply
     * @returns {void}
     */
    fn_setGroundWidth(val, bApply=true) {
        if (val === this.#rctGround.width) return;

        if (val < hfHScroller.#MINV) val = hfHScroller.#MINV;
        this.#rctGround.width = val;

        let sz = this.#rctGround.width * this.#scrollSizeRatio;
        if (sz < hfHScroller.#MINV) sz = hfHScroller.#MINV;
        this.#rctThumb.width = sz;
        const sv = this.#fn_getScrollSize() * this.#scrollPositionRatio;
        this.#rctThumb.x = sv;

        if (bApply === true) {
            fn_setWidth(this.#elGround, this.#rctGround.width);
            fn_setWidth(this.#elThumb, this.#rctThumb.width);
            fn_setLeft(this.#elThumb, this.#rctThumb.left);
        }
    }

    /**
     *
     * @param {number} val
     * @param {boolean} bApply
     * @returns {void}
     */
    fn_setGroundHeight(val, bApply=true) {
        if (val === this.#rctGround.height) return;

        if (val < hfHScroller.#MINV) val = hfHScroller.#MINV;
        this.#rctGround.height = val;
        this.#rctThumb.height = val;
        this.#rctThumb.y = this.#rctGround.top;

        if (bApply === true) {
            fn_setHeight(this.#elGround, this.#rctGround.height);
            fn_setHeight(this.#elThumb, this.#rctThumb.height);
            fn_setTop(this.#elThumb, this.#rctThumb.top);
        }
    }

    /**
     *
     * @param {number} val
     * @param {boolean} bApply
     * @returns {void}
     */
    fn_setGroundLeft(val, bApply=true) {
        if (val === this.#rctGround.left) return;

        this.#rctGround.x = val;
        const sv = this.#fn_getScrollSize() * this.#scrollPositionRatio;
        this.#rctThumb.x = sv;

        if (bApply === true) {
            fn_setLeft(this.#elGround, this.#rctGround.left);
            fn_setLeft(this.#elThumb, this.#rctThumb.left);
        }
    }

    /**
     *
     * @param {number} val
     * @param {boolean} bApply
     * @returns {void}
     */
    fn_setGroundTop(val, bApply=true) {
        if (val === this.#rctGround.top) return;

        this.#rctGround.y = val;
        this.#rctThumb.y = val;

        if (bApply === true) {
            fn_setTop(this.#elGround, this.#rctGround.top);
            fn_setTop(this.#elThumb, this.#rctThumb.top);
        }
    }


    ////////////////////////////////////////////////////////////////////////////////////////////////////
    /**
     *
     * @param {number} val
     * @param {boolean} bApply
     * @returns {void}
     */
    #fn_setThumbSize(val, bApply=true) {
        if (val === this.#rctThumb.width) return;

        const bv = hfHScroller.#MINV;
        const ev = this.#rctGround.width;

        let cv = val;
        if (cv < bv) cv = bv;
        else if (cv > ev) cv = ev;
        this.#rctThumb.width = cv;

        const sv = this.#fn_getScrollSize() * this.#scrollPositionRatio;
        this.#rctThumb.x = sv;

        if (bApply === true) {
            fn_setWidth(this.#elThumb, this.#rctThumb.width);
            fn_setLeft(this.#elThumb, this.#rctThumb.left);
        }
    }

    /**
     *
     * @param {number} val
     * @param {boolean} bApply
     * @returns {void}
     */
    #fn_setThumbPosition(val, bApply=true) {
        if (val === this.#rctThumb.left) return;

        const bv = 0.0;
        const ev = this.#fn_getScrollSize();

        let cv = val;
        if (cv < bv) cv = bv;
        else if (cv > ev) cv = ev;
        this.#rctThumb.x = cv;

        let vr = (cv - bv) / (ev - bv);
        if (isFinite(vr) === true) {
            this.#scrollPositionRatio = vr;
        }

        if (bApply === true) {
            fn_setLeft(this.#elThumb, this.#rctThumb.left);
        }
    }

    /**
     *
     * @param {boolean} bApply
     * @returns {void}
     */
    #fn_updateThumbPosition(bApply=true) {
        const bv = hfHScroller.#MINV;
        const ev = this.#rctGround.width;

        let sz = ev * this.#scrollSizeRatio;
        if (sz < bv) sz = bv;
        else if (sz > ev) sz = ev;
        this.#rctThumb.width = sz;

        const sv = this.#fn_getScrollSize() * this.#scrollPositionRatio;
        this.#rctThumb.x = sv;

        if (bApply === true) {
            fn_setWidth(this.#elThumb, this.#rctThumb.width);
            fn_setLeft(this.#elThumb, this.#rctThumb.left);
        }
    }


    ////////////////////////////////////////////////////////////////////////////////////////////////////
    /**
     *
     * @returns {number}
     */
    fn_getScrollSizeRatio() {
        return this.#scrollSizeRatio;
    }

    /**
     *
     * @param {number} val
     * @param {boolean} bApply
     * @returns {void}
     */
    fn_setScrollSizeRatio(val, bApply=true) {
        if (val < 0.0) val = 0.0;
        else if (val > 1.0) val = 1.0;
        this.#scrollSizeRatio = val;

        this.#fn_setThumbSize(this.#rctGround.width * this.#scrollSizeRatio, bApply);
    }


    ////////////////////////////////////////////////////////////////////////////////////////////////////
    /**
     *
     * @returns {number}
     */
    fn_getScrollPositionRatio() {
        return this.#scrollPositionRatio;
    }

    /**
     *
     * @param {number} val
     * @param {boolean} bApply
     * @returns {void}
     */
    fn_setScrollPositionRatio(val, bApply=true) {
        if (val === this.#scrollPositionRatio) return;

        if (val < 0.0) val = 0.0;
        else if (val > 1.0) val = 1.0;
        this.#scrollPositionRatio = val;
        // console.log(this.#scrollPositionRatio);

        const bv = this.#rctGround.left;
        const ev = this.#rctGround.right - this.#rctThumb.width;
        const sv = this.#fn_getScrollSize() * this.#scrollPositionRatio;

        let cv = bv + sv;
        if (cv < bv) cv = bv;
        else if (cv > ev) cv = ev;
        this.#rctThumb.x = cv;

        if (bApply === true) {
            fn_setLeft(this.#elThumb, this.#rctThumb.left);
        }
    }



    ////////////////////////////////////////////////////////////////////////////////////////////////////
    /**
     *
     * @param {MouseEvent} e
     * @returns {void}
     */
    #fn_mouseMove = (e) => {
        if (this.#bmd === false) return;

        const cv = e.clientX - this.#mdp;
        this.#fn_setThumbPosition(cv);

        this.dispatchEvent(new Event(hfEventTypes.Scroll));
    }

    /**
     *
     * @param {MouseEvent} e
     * @returns {void}
     */
    #fn_mouseUp = (e) => {
        if (this.#bmd === false) return;

        window.removeEventListener(hfEventTypes.MouseMove, this.#fn_mouseMove);
        window.removeEventListener(hfEventTypes.MouseUp, this.#fn_mouseUp);
        window.removeEventListener(hfEventTypes.Blur, this.#fn_mouseUp);
        this.#bmd = false;
    }

    /**
     *
     * @param {MouseEvent} e
     * @returns {void}
     */
    #fn_mouseDown = (e) => {
        if (this.#bmd === true) return;

        window.addEventListener(hfEventTypes.MouseMove, this.#fn_mouseMove);
        window.addEventListener(hfEventTypes.MouseUp, this.#fn_mouseUp);
        window.addEventListener(hfEventTypes.Blur, this.#fn_mouseUp);
        this.#bmd = true;

        if (fn_containsRect(this.#rctThumb, e.clientX, e.clientY) === true) {
            this.#mdp = e.clientX - this.#rctThumb.left;

            this.#fn_mouseMove(e);
        }
        else {
            const cv = e.clientX - (this.#rctThumb.width / 2);
            this.#fn_setThumbPosition(cv);
            this.#mdp = e.clientX - this.#rctThumb.left;

            this.dispatchEvent(new Event(hfEventTypes.Scroll));
        }
    }

    /**
     *
     * @param {Event} e
     * @returns {void}
     */
    #fn_resize = (e) => {
        console.log(this.#rctGround, this.#rctThumb);
        this.#rctGround = fn_getRect(this.#elGround);
        this.#rctThumb = fn_getRect(this.#elThumb);
        console.log(this.#rctGround, this.#rctThumb);


        this.#fn_setThumbSize(this.#rctGround.width * this.#scrollSizeRatio, true);
    }

});
//#endregion