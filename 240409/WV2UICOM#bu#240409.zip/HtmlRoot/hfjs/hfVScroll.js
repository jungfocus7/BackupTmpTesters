import { hfEventTypes } from "./hfEventTypes.js";
import {
    fn_setHeight,
    fn_setTop,
    fn_getRect,
    fn_updateRect,
    fn_containsRect,
 } from "./hfStyleFunctions.js";



const hfVScroll = Object.freeze(class extends EventTarget {
    ////////////////////////////////////////////////////////////////////////////////////////////////////
    constructor(elId='vscr') {
        super();

        this.#elGround = document.getElementById(elId);
        this.#elGround.setAttribute('style', `
width: 20px; height: 100%;
background-color: #595959;
position: static; display: inline-block;
overflow-x: hidden; overflow-y: hidden;
font-size: 0px; cursor: pointer;
        `.trim());
        this.#elGround.innerHTML = `
<div style="background-color: #748B96;
    position: relative;
    width: 100%; height: 100%;
    left: 0px; top: 0px;
    pointer-events: none; overflow: visible;
    box-sizing: border-box; font-size: 0px;
    border: 3px solid #595959;">
    <span style="
        position: relative;
        display: inline-block;
        width: auto; height: auto;
        left: 50%; top: 50%;
        transform: translate(-50%, -50%) rotate(-90deg);
        user-select: none; white-space: nowrap;
        font-size: 11px; color: #ffffff66;"></span>
</div>
        `.trim();

        this.#elThumb = this.#elGround.children[0];
        this.#elSpan = this.#elThumb.children[0];
        this.#elSpan.innerText = '';

        this.#rctGround = fn_getRect(this.#elGround);
        this.#rctThumb = fn_getRect(this.#elThumb);

        this.#elGround.addEventListener(hfEventTypes.MouseDown, this.#fn_mouseDown);

        window.addEventListener(hfEventTypes.Resize, this.#fn_resize);
        // this.#fn_resize(null);
    }

    /** @type {number} */
    static #MINV = 30.0;

    /** @type {HTMLElement} */
    #elGround = null;
    /** @type {HTMLElement} */
    #elThumb = null;
    /** @type {HTMLElement} */
    #elSpan = null;

    /** @type {DOMRect} */
    #rctGround = null;
    /** @type {DOMRect} */
    #rctThumb = null;

    /** @type {number} */
    #scrollSizeRatio = 1.0;
    /** @type {number} */
    #scrollPositionRatio = 0.0;

    /** @type {boolean} */
    #bmd = false;
    /** @type {number} */
    #mdp = NaN;


    ////////////////////////////////////////////////////////////////////////////////////////////////////
    /** @returns {void} */
    #fn_printSpanLog() {
        if (true) {
            const ssr = (100 * this.#scrollSizeRatio).toFixed(1);
            const spr = (100 * this.#scrollPositionRatio).toFixed(1);
            // this.#elSpan.innerText = `SSR: ${ssr}, SPR: ${spr}`;
			this.#elSpan.innerText = `${ssr}% / ${spr}%`;
        }
    }

    /** @returns {number} */
    #fn_getScrollSize() {
        let ss = this.#rctGround.height - this.#rctThumb.height;
        if (ss < 0.0) ss = 0.0;

        return ss;
    }


    ////////////////////////////////////////////////////////////////////////////////////////////////////
    /**
     * Thumb 사이즈 설정
     * @param {number} val
     * @param {boolean} bApply
     * @returns {void}
     */
    #fn_setThumbSize(val, bApply=true) {
        if (val === this.#rctThumb.height) return;

        const bv = hfVScroll.#MINV;
        const ev = this.#rctGround.height;
        let cv = val;
        if (cv < bv) cv = bv;
        else if (cv > ev) cv = ev;
        this.#rctThumb.height = cv;

        const sv = this.#fn_getScrollSize() * this.#scrollPositionRatio;
        this.#rctThumb.y = sv;

        if (bApply === true) {
            fn_setHeight(this.#elThumb, this.#rctThumb.height);
            fn_setTop(this.#elThumb, this.#rctThumb.top);
        }
    }

    /**
     * Thumb 포지션 설정
     * @param {number} val
     * @param {boolean} bApply
     * @returns {void}
     */
    #fn_setThumbPosition(val, bApply=true) {
        if (val === this.#rctThumb.top) return;

        const bv = 0.0;
        const ev = this.#fn_getScrollSize();
        let cv = val;
        if (cv < bv) cv = bv;
        else if (cv > ev) cv = ev;
        this.#rctThumb.y = cv;

        let vr = (cv - bv) / (ev - bv);
        if (isFinite(vr) === true) {
            this.#scrollPositionRatio = vr;
        }

        if (bApply === true) {
            fn_setTop(this.#elThumb, this.#rctThumb.top);
        }
    }


    ////////////////////////////////////////////////////////////////////////////////////////////////////
    /**
     * 스크롤 사이즈 비율 반환
     * @returns {number}
     */
    fn_getScrollSizeRatio() {
        return this.#scrollSizeRatio;
    }

    /**
     * 스크롤 사이즈 비율 설정
     * @param {number} val
     * @param {boolean} bApply
     * @returns {void}
     */
    fn_setScrollSizeRatio(val, bApply=true) {
        if (val < 0.0) val = 0.0;
        else if (val > 1.0) val = 1.0;
        this.#scrollSizeRatio = val;

        const sz = this.#rctGround.height * this.#scrollSizeRatio;
        this.#fn_setThumbSize(sz, bApply);

        this.#fn_printSpanLog();
    }


    ////////////////////////////////////////////////////////////////////////////////////////////////////
    /**
     * 스크롤 포지션 비율 반환
     * @returns {number}
     */
    fn_getScrollPositionRatio() {
        return this.#scrollPositionRatio;
    }

    /**
     * 스크롤 포지션 비율 설정
     * @param {number} val
     * @param {boolean} bApply
     * @returns {void}
     */
    fn_setScrollPositionRatio(val, bApply=true) {
        if (val === this.#scrollPositionRatio) return;

        if (val < 0.0) val = 0.0;
        else if (val > 1.0) val = 1.0;
        this.#scrollPositionRatio = val;

        const bv = 0.0;
        const ev = this.#fn_getScrollSize();
        let cv = ev * this.#scrollPositionRatio;
        if (cv < bv) cv = bv;
        else if (cv > ev) cv = ev;
        this.#rctThumb.y = cv;

        this.#fn_printSpanLog();

        if (bApply === true) {
            fn_setTop(this.#elThumb, this.#rctThumb.top);
        }
    }


    ////////////////////////////////////////////////////////////////////////////////////////////////////
    /**
     * 리사이즈 후 업데이트
     * @returns {void}
     */
    #fn_updateAfterResized(bApply=true) {
        const bv = hfVScroll.#MINV;
        const ev = this.#rctGround.height;
        let cv = ev * this.#scrollSizeRatio;
        if (cv < bv) cv = bv;
        else if (cv > ev) cv = ev;
        this.#rctThumb.height = cv;

        const cp = this.#fn_getScrollSize() * this.#scrollPositionRatio;
        this.#rctThumb.y = cp;

        if (bApply === true) {
            fn_setHeight(this.#elThumb, this.#rctThumb.height);
            fn_setTop(this.#elThumb, this.#rctThumb.top);
        }

        this.#fn_printSpanLog();
    }



    ////////////////////////////////////////////////////////////////////////////////////////////////////
    /**
     * MOUSE_MOVE
     * @param {MouseEvent} e
     * @returns {void}
     */
    #fn_mouseMove = (e) => {
        if (this.#bmd === false) return;

        const cv = e.clientY - this.#mdp;
        this.#fn_setThumbPosition(cv);
        this.#fn_printSpanLog();

        this.dispatchEvent(new Event(hfEventTypes.Scroll));
    }

    /**
     * MOUSE_UP
     * @param {MouseEvent} e
     * @returns {void}
     */
    #fn_mouseUp = (e) => {
        if (this.#bmd === false) return;

        window.removeEventListener(hfEventTypes.MouseMove, this.#fn_mouseMove);
        window.removeEventListener(hfEventTypes.MouseUp, this.#fn_mouseUp);
        window.removeEventListener(hfEventTypes.Blur, this.#fn_mouseUp);
        this.#bmd = false;
    }

    /**
     * MOUSE_DOWN
     * @param {MouseEvent} e
     * @returns {void}
     */
    #fn_mouseDown = (e) => {
        if (this.#bmd === true) return;

        window.addEventListener(hfEventTypes.MouseMove, this.#fn_mouseMove);
        window.addEventListener(hfEventTypes.MouseUp, this.#fn_mouseUp);
        window.addEventListener(hfEventTypes.Blur, this.#fn_mouseUp);
        this.#bmd = true;

        if (fn_containsRect(this.#rctThumb, e.offsetX, e.offsetY) === true) {
            this.#mdp = e.clientY - this.#rctThumb.top;

            this.#fn_mouseMove(e);
        }
        else {
            const cv = e.clientY - (this.#rctThumb.height / 2);
            this.#fn_setThumbPosition(cv);
            this.#fn_printSpanLog();
            this.#mdp = e.clientY - this.#rctThumb.top;

            this.dispatchEvent(new Event(hfEventTypes.Scroll));
        }
    }

    /**
     * RESIZE
     * @param {Event} e
     * @returns {void}
     */
    #fn_resize = (e) => {
        fn_updateRect(this.#elGround, this.#rctGround);
        fn_updateRect(this.#rctThumb, this.#rctThumb);

        this.#fn_updateAfterResized();
    }

});



export { hfVScroll };
