export default {
	input: './hfjs/#exports.js',
	output: {
		file: './hfjs/bundle.js',
		format: 'es'
	}
};



// export default {
// 	input: './main.js',
// 	output: {
// 		file: 'bundle.js',
// 		format: 'es'
// 	}
// };



// // rollup.config.mjs
// import json from '@rollup/plugin-json';

// export default {
// 	input: './src/main.js',
// 	output: {
// 		file: 'bundle.js',
// 		format: 'es'
// 	},
// 	plugins: [json()]
// };