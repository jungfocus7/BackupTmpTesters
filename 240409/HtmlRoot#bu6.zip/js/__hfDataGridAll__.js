const _MouseMove = 'mousemove';
const _Blur = 'blur';
const _MouseUp = 'mouseup';
const _MouseDown = 'mousedown';
const _Resize = 'resize';
const _Scroll = 'scroll';



/**
 * 드래그 라운드
 */
class hfDragRound {
    constructor(dgrid, cbf) {
        this.#m_dgrid = dgrid;
        this.#m_cbf = cbf;

        window.addEventListener(_MouseDown, this.#fn_MouseDown);
        window.addEventListener(_Resize, this.#fn_Resize);
        this.#m_dgrid.addEventListener(_Scroll, this.#fn_Scroll);

        Object.freeze(this);
    }

    #m_dgrid = null;    //Grid DIV
    #m_cbf = null;      //Callback Function

    #m_bmd = false;     //Bool MouseDown
    #m_dx = 0;          //MouseDown X
    #m_dy = 0;          //MouseDown Y
    #m_sl = 0;          //Scroll Left
    #m_st = 0;          //Scroll Top


    #fn_MouseMove = (e) => {
        // console.log(_MouseMove, e);
        if (this.#m_bmd === false) return;

        let lx = this.#m_dx - e.x;
        let ly = this.#m_dy - e.y;
        // console.log(lx, ly);
        let sl = this.#m_sl + lx;
        let st = this.#m_st + ly;
        // console.log(sl, st);
        this.#m_dgrid.scroll(sl, st);

        this.#m_cbf?.(e);
    };


    #fn_MouseUp = (e) => {
        // console.log(_MouseUp, e);
        if (this.#m_bmd === false) return;

        window.removeEventListener(_MouseMove, this.#fn_MouseMove);
        window.removeEventListener(_MouseUp, this.#fn_MouseUp);
        window.removeEventListener(_Blur, this.#fn_MouseUp);
        this.#m_bmd = false;

        // let sl = this.#m_dgrid.scrollLeft;
        // let st = this.#m_dgrid.scrollTop;
        // console.log(sl, st);

        this.#m_cbf?.(e);
    };


    #fn_MouseDown = (e) => {
        // console.log(_MouseDown, e);
        if (e.button === 0) {
            if (this.#m_bmd === true) return;

            window.addEventListener(_MouseMove, this.#fn_MouseMove);
            window.addEventListener(_MouseUp, this.#fn_MouseUp);
            window.addEventListener(_Blur, this.#fn_MouseUp);
            this.#m_bmd = true;

            this.#m_dx = e.x;
            this.#m_dy = e.y;
            // console.log(this.#m_dx, this.#m_dy);
            this.#m_sl = this.#m_dgrid.scrollLeft;
            this.#m_st = this.#m_dgrid.scrollTop;
            // console.log(this.#m_sl, this.#m_st);

            this.#m_cbf?.(e);
            this.#fn_MouseMove(e);
        }
    };


    #fn_Resize = (e) => {
        if (e !== null)
            this.#m_cbf?.(e);
    };


    #fn_Scroll = (e) => {
        if (e !== null)
            this.#m_cbf?.(e);
    };



    Dispose = () => {
        if (this.#m_dgrid === null) return;

        this.#fn_MouseUp();

        window.removeEventListener(_MouseDown, this.#fn_MouseDown);
        window.removeEventListener(_Resize, this.#fn_Resize);

        this.#m_dgrid.removeEventListener(_Scroll, this.#fn_Scroll);
        this.#m_dgrid = null;

        this.#m_cbf = null;
    };

}

export {
    _MouseMove, _Blur, _MouseUp, _MouseDown, _Resize, _Scroll,
    hfDragRound
};




/**
 * 데이터그리드 컬럼아이템
 */
class hfColumnItem {
    constructor(colName, propName, width, height) {
        this.#colName = colName;
        this.#propName = propName;
        this.#width = width;
        this.#height = height;

        Object.freeze(this);
    }

    #colName = '';
    GetColumnName = () => {
        return this.#colName;
    };
    SetColumnName = (tv) => {
        this.#colName = tv;
    };

    #propName = '';
    GetPropName = () => {
        return this.#propName;
    };
    SetPropName = (tv) => {
        this.#propName = tv;
    };

    #width = 70;
    GetWidth = () => {
        return this.#width;
    };
    SetWidth = (tv) => {
        this.#width = tv;
    };

    #height = 30;
    GetHeight = () => {
        return this.#height;
    };
    SetHeight = (tv) => {
        this.#height = tv;
    };

}



/**
 * 데이터그리드 로우아이템
 */
class hfRowItem {
    constructor(colArr) {
        this.#colArr = colArr;
        this.#cl = this.#colArr.length;
        this.#arr = new Array(this.#cl);
        Object.freeze(this);
    }

    #colArr = null;
    #cl = 0;

    #arr = null;
    GetArr(tp) {
        return this.#arr;
    }
    GetValue(tp) {
        return this.#arr[tp];
    }
    SetValue(tp, tv) {
        this.#arr[tp] = tv;
    }

}


/**
 * 데이터그리드 객체
 */
class hfDataGrid {
    constructor(dgrid) {
        this.#dgrid = dgrid;
        this.#dgbg = document.querySelector('#d_gbg');
        // console.log(this.#m_dgrid);
        // console.log(this.#m_dgbg);
        this.#drr = new hfDragRound(this.#dgrid, this.#fn_drcb);
        Object.freeze(this);
    }

    #dgrid = null;
    #dgbg = null;
    #drr = null;

    #colArr = [];
    #rowArr = [];

    #raw = 70;
    #rah = 30;


    AddColumn = (colName, propName, width, height) => {
        let ci = new hfColumnItem(colName, propName, width, height);
        this.#colArr.push(ci);
        return ci;
    };


    AddRow = () => {
        const ri = new hfRowItem(this.#colArr);
        this.#rowArr.push(ri);
        return ri;
    };


    Render = () => {
        let tw = 0;
        let th = 0;

        for (let ci of this.#colArr) {
            tw += ci.GetWidth();
            if (th === 0)
                th = ci.GetHeight();
        }

        this.#raw = tw;
        this.#rah = th * this.#rowArr.length;
        // console.log(this.#raw, this.#rah);

        // const st1 = getComputedStyle(this.#dgbg);
        const st1 = this.#dgbg.style;
        st1.width = `${this.#raw}px`;
        st1.height = `${this.#rah}px`;
        // console.log(st1);
    };



    #fn_drcb = (e) => {
        // console.log(e.type);
    };



    Dispose = () => {
        if (this.#dgrid === null) return;

        this.#dgrid = null;
        this.#dgbg = null;
        this.#drr.Dispose();
        this.#drr = null;
    };

}
// console.log(hfDataGrid);


export { hfDataGrid, hfColumnItem, hfRowItem };
