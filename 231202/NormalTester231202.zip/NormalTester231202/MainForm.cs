﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;




namespace NormalTester231202
{
    public sealed partial class MainForm : Form
    {
        public MainForm()
        {
            InitializeComponent();
            Load += prLoad;
        }


        private void prLoad(object sender, EventArgs e)
        {
            m_txb31.Text = "'name'|'pook61'|'1'|'outterworld'|3|넣는골로 아는데 아닌가|123123|'9923'";
            m_txb31.PreviewKeyDown += delegate (object tsd, PreviewKeyDownEventArgs tea)
            {
                //if (tea.KeyData == (Keys.Control | Keys.W))
                if (tea.KeyData == Keys.F2)
                {
                    prChkWake();
                }
            };
            m_txb31.Click += delegate
            {
            };
        }



        private void prChkWake()
        {
            string txt = m_txb31.Text;
            if (string.IsNullOrWhiteSpace(txt)) return;

            int tsi = 0, tei = txt.Length - 1;
            int ti = m_txb31.SelectionStart;

            int ts = ti, te = ti;
            int i = 0;

            for (i = ti - 1; i >= tsi; --i)
            {
                char tc = txt[i];
                if (tc == '|') break;
                ts = i;
            }

            for (i = ti; i <= tei; ++i)
            {
                char tc = txt[i];
                if (tc == '|')
                {
                    te = i - 1;
                    break;
                }
                te = i;
            }

            if (ts < tsi) ts = tsi;
            if (te > tei) te = tei;

            if (ts <= te)
            {
                //Debug.WriteLine($"{txt[ts]}, {txt[te]}");
                if ((txt[ts] == '\'') && (txt[te] == '\''))
                {
                    ++ts; --te;
                }

                int tl = (te - ts) + 1;
                if (tl > 0)
                {
                    //Debug.WriteLine($"{ts}, {tl}");
                    m_txb31.Select(ts, tl);
                }
            }
        }


        //private void prChkWake()
        //{
        //    string txt = m_txb31.Text;
        //    if (string.IsNullOrWhiteSpace(txt)) return;

        //    int tsi = 0, tei = txt.Length;
        //    int ti = m_txb31.SelectionStart;
        //    if ((ti < 0) || (ti >= tei)) return;

        //    //const char dc1 = '\'';
        //    const char dc2 = '|';
        //    bool bx = true;

        //    int i = 0, ts = ti, te = ti;
        //    for (i = ti; i >= tsi; --i)
        //    {
        //        char tc = txt[i];
        //        if (tc == dc2)
        //        {
        //            if (bx)
        //            {
        //                bx = false;
        //                continue;
        //            }
        //            else break;
        //        }
        //        ts = i;
        //    }

        //    for (i = ti; i < tei; ++i)
        //    {
        //        char tc = txt[i];
        //        if (tc == dc2)
        //        {
        //            if (bx == false)
        //            {
        //                --te;
        //                break;
        //            }
        //            else continue;
        //        }
        //        te = i;
        //    }


        //    if (ts > te) return;
        //    else if (ts == te)
        //    {
        //        ti = ts;
        //        char tc = txt[ti];
        //        if (tc == dc2)
        //        {
        //            if (ti > 0)
        //            {
        //                tc = txt[--ti];
        //                if (tc != dc2)
        //                    m_txb31.Select(ti, 1);
        //            }
        //        }
        //        else
        //        {
        //            m_txb31.Select(ti, 1);
        //        }
        //    }
        //    else if (ts < te)
        //    {
        //        m_txb31.Select(ts, (te - ts) + 1);
        //    }
        //}


        //private void prChkWake()
        //{
        //    string txt = m_txb31.Text;
        //    if (string.IsNullOrWhiteSpace(txt)) return;

        //    int tsi = 0, tei = txt.Length;
        //    int ti = m_txb31.SelectionStart;
        //    if ((ti < 0) || (ti >= tei)) return;

        //    const char dc1 = '\'';
        //    const char dc2 = '|';

        //    int i = 0, ts = ti, te = ti;
        //    for (i = ti; i >= tsi; --i)
        //    {
        //        char tc = txt[i];
        //        if ((tc == dc1) || (tc == dc2)) break;
        //        ts = i;
        //    }
        //    for (i = ti; i < tei; ++i)
        //    {
        //        char tc = txt[i];
        //        if ((tc == dc1) || (tc == dc2)) break;
        //        te = i;
        //    }

        //    if (ts > te) return;
        //    else if (ts == te)
        //    {
        //        char tc = txt[ts];
        //        if ((tc == dc1) || (tc == dc2)) return;
        //        else m_txb31.Select(ts, 1);
        //    }
        //    else if (ts < te)
        //    {
        //        m_txb31.Select(ts, (te - ts) + 1);
        //    }
        //}

    }
}
